# Folder Reorg Directive — utils/scripts/project-collection

## Objective

Remove `clean-up/` as a parent folder. Promote its contents into a cleaner, scope-based structure directly under `project-collection/`.

---

## Current Structure (Before)

```
utils/scripts/project-collection/
├── clean-up/
│   ├── collection/
│   │   ├── ado-collection-metrics.ps1
│   │   ├── azdo_query_scripts.ps1
│   │   ├── collection-usage-report.ps1
│   │   ├── Collection-Usage-Report-v1.ps1
│   │   ├── get-collection-audit.ps1
│   │   ├── get-collection-pool-agents.ps1
│   │   ├── get-dormant-projects.ps1
│   │   ├── git-repo-user-list.ps1
│   │   └── regenerate-projects-json.ps1
│   ├── config/
│   │   └── defaults.json
│   ├── pipeline/
│   │   ├── get-yaml.ps1
│   │   ├── pipeline-pools.ps1
│   │   └── scan-pipeline-yaml.ps1
│   ├── create-draft-emails.ps1
│   ├── DecommissionEmailTemplate.json
│   ├── export-and-delete-ado-projects.ps1
│   ├── ExportAndDelete-ProjectsToProcess.json
│   └── get-project-admins.ps1
└── process-templates/
    └── WorkItems/
        └── Bug/
            ├── bug-process-cli-rest.ps1
            ├── bug-process-execute.ps1
            ├── bug-process-helpers.ps1
            ├── bug-process-rest-v1..ps1
            ├── bug-process-verification.ps1
            └── vs-code.ps1
```

---

## Target Structure (After)

```
utils/scripts/project-collection/
├── collection/
│   ├── ado-collection-metrics.ps1
│   ├── azdo_query_scripts.ps1
│   ├── collection-usage-report.ps1
│   ├── Collection-Usage-Report-v1.ps1
│   ├── get-collection-audit.ps1
│   ├── get-collection-pool-agents.ps1
│   ├── get-dormant-projects.ps1
│   ├── get-project-admins.ps1
│   ├── git-repo-user-list.ps1
│   └── regenerate-projects-json.ps1
├── config/
│   └── defaults.json
├── export/
│   ├── create-draft-emails.ps1
│   ├── DecommissionEmailTemplate.json
│   ├── export-and-delete-ado-projects.ps1
│   └── ExportAndDelete-ProjectsToProcess.json
├── pipeline/
│   ├── get-yaml.ps1
│   ├── pipeline-pools.ps1
│   └── scan-pipeline-yaml.ps1
└── process-templates/
    └── WorkItems/
        └── Bug/
            ├── bug-process-cli-rest.ps1
            ├── bug-process-execute.ps1
            ├── bug-process-helpers.ps1
            ├── bug-process-rest-v1..ps1
            ├── bug-process-verification.ps1
            └── vs-code.ps1
```

---

## Move Instructions

| From | To |
|------|----|
| `clean-up/collection/*` | `collection/` |
| `clean-up/get-project-admins.ps1` | `collection/get-project-admins.ps1` |
| `clean-up/config/` | `config/` |
| `clean-up/pipeline/` | `pipeline/` |
| `clean-up/export-and-delete-ado-projects.ps1` | `export/export-and-delete-ado-projects.ps1` |
| `clean-up/ExportAndDelete-ProjectsToProcess.json` | `export/ExportAndDelete-ProjectsToProcess.json` |
| `clean-up/DecommissionEmailTemplate.json` | `export/DecommissionEmailTemplate.json` |
| `clean-up/create-draft-emails.ps1` | `export/create-draft-emails.ps1` |

---

## After Moves Are Complete

- Delete `clean-up/` — it should be empty at that point
- Do not modify any file contents — moves only
- Do not touch `process-templates/` — it stays as-is

---

## Guardrails

- Do not modify any script contents during this reorg
- Do not rename any files — folder structure only
- Confirm each move before proceeding to the next
- If any file is missing from expected location, stop and report — do not guess
