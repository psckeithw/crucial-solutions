# Agent Instructions — Unified Platform Operations / Azure DevOps Export Effort

## Supreme Directive
Maintain a safe, export-first workflow for Azure DevOps project automation. Always prioritize data integrity, clear diagnostics, and session reliability. Never weaken safety gates or persist sensitive values. Apply cohesion — if a thing is part of a thing, it lives with the thing. Never scatter related files across unrelated folders.

## Primary Objective
Maintain and improve the project work item export workflow centered on:
- `utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1`

Default operating mode must remain export-first and safe.

## Current Baseline (Already Done)
- PAT retrieval in runtime flow prefers `AZDO_PAT` Process scope for current session reliability.
- Authentication preflight exists and should fail fast with clear messages.
- Project resolution works for exact project names.
- Export workflow works for project names containing spaces (e.g. project names with spaces).
- Runtime artifacts are ignored via `.gitignore`; `test-output` is treated as generated output.
- Folder structure reorg completed — `clean-up/` removed, replaced with:
  - `utils/scripts/project-collection/collection/`
  - `utils/scripts/project-collection/export/`
  - `utils/scripts/project-collection/export/email/`
  - `utils/scripts/project-collection/pipeline/`
  - `utils/scripts/project-collection/config/`
- Docs normalized for this effort:
  - `README.md`
  - `utils/docs/analysis.md`
  - `utils/docs/ARCHITECTURE.md`
  - `utils/docs/SCRIPT-PATTERNS.md`
  - `utils/docs/SCRIPT-REFERENCE.md`

## Todo — Next Work Priority
1. Align PAT retrieval order in `utils/modules/AzDO-Helpers.psm1` so `Get-AdoPat` prefers Process → User → Machine.
2. Add focused regression coverage for:
   - Auth preflight behavior
   - PAT precedence behavior
   - WIQL export for project names with spaces
3. Improve run summary diagnostics — concise error reason per failed project, mask sensitive values.
4. Optionally reintroduce bounded concurrency only if state/function scope is stable and validated.

## First Actions for New Session
- Read `README.md`, `TODO.md`, and `utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1`.
- Confirm `git diff` before any edits.
- Complete one priority item at a time — update `TODO.md` after each.

## Review Checkpoint
Before finalizing any completed item — before updating `TODO.md` and before committing — changes should be reviewed by counsel (Claude). Present a concise summary of what changed and why. Do not self-approve significant rewrites, new functions, or anything touching delete logic or PAT handling.

## Guardrails
- Never weaken delete safety gates.
- Never persist PAT values in files, logs, manifests, or state.
- Keep docs scoped to this effort — do not add unrelated platform content.
- Preserve useful forward-looking context; do not delete helpful documentation.
- Apply cohesion — if a thing is part of a thing, it lives with the thing. Never scatter related files across unrelated folders.
- Complete one task at a time — confirm before moving to the next.
