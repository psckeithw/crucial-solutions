# Niche Sandbox — Export-and-Delete Effort

## Current Effort Scope

This effort manages Azure DevOps project work item export (and optional guarded deletion) using:

- `utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1`

The current operating mode is **export-first** with deletion disabled unless explicitly and safely enabled.

## Effort Documents

- `README.md` (primary operational guide)
- `analysis.md` (current-state analysis and scope boundaries)
- `TODO.md` (active backlog for this effort)
- `utils/docs/REVIEW-LATEST.md` (latest status snapshot)
- `utils/docs/PROJECT-REVIEW.md` (effort review summary)
- `utils/docs/IMPLEMENTATION-PLAN-ExportAndDelete-AdoProjects.md` (deep implementation reference)

## What the Script Does

- Exports project work items to CSV (and optional XLSX).
- Writes run metadata and state for resumable execution.
- Supports processing one or more exact project names.
- Uses safe delete gates (`-ConfirmDelete` and `-Force`) when deletion is intentionally requested.

## Standard Usage

Set PAT for the active shell session:

```powershell
$env:AZDO_PAT = 'YOUR_PAT'
```

Run export-only for one project:

```powershell
pwsh -File ".\utils\scripts\project-collection\export\export-and-delete-ado-projects.ps1" `
	-OrganizationUrl "https://aha-bt.visualstudio.com/Niche%20Sandbox" `
	-ProjectsToProcess "Niche Sandbox" `
	-ExportOnly
```

Run export-only for multiple projects:

```powershell
pwsh -File ".\utils\scripts\project-collection\export\export-and-delete-ado-projects.ps1" `
	-ProjectsToProcess "ProjectA;ProjectB;ProjectC" `
	-ExportOnly
```

## Output Layout


Default output root: `test-output/`

Each project export is written to a single folder named after the project, with all artifact files prefixed by the project name:

```
test-output/<ProjectName>/
	<ProjectName>-workitems.csv
	<ProjectName>-workitems.xlsx (if -UseImportExcel)
	<ProjectName>-metadata.json
	<ProjectName>-workitem_fields.json
	<ProjectName>-pipeline_pool_usage.json
	<ProjectName>-manifest.json
	<ProjectName>-state.json
	<ProjectName>-log.txt
```

There are no longer any _manifests, _state, _logs, or summary files in the root.

## Source Control Hygiene

Generated runtime artifacts are ignored by git. See:
- `.gitignore` rules for `test-output/**` and `output/`

`test-output/list_projects.ps1` is intentionally retained.

## PAT Handling and Security

- PAT values are session-scoped and intended for in-memory use.
- Do not store PAT values in scripts, config, logs, or committed output.
- Any plain-text PAT values observed during local console use should be treated as temporary and revoked.

Required PAT scopes for this effort:

- `vso.work`
- `vso.project`
- `vso.project_delete` (only when delete mode is intentionally used)
