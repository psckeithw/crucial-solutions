# Niche Sandbox Distribution Package - File Manifest

This file is the **source of truth** for the distribution package. All sync and publish scripts read from this manifest.

## Package Info
- **Version:** 1.0.0
- **Last Updated:** 2026-02-24

## Root Files
```
README.md
tree.flat.distributed.json
```

## Documentation (utils/docs/md/)
```
utils/docs/md/ARCHITECTURE.md
utils/docs/md/SCRIPT-REFERENCE.md
utils/docs/md/SCRIPT-PATTERNS.md
```

## Dashboard Files (utils/docs/summaries/)
```
utils/docs/summaries/Dashboard.html
utils/docs/summaries/dashboard-config.js
utils/docs/summaries/dashboard2.html
utils/docs/summaries/agent-comparison-dashboard.html
utils/docs/summaries/ExportAndDelete-Summary.html
utils/docs/summaries/Collection-Summary.html
utils/docs/summaries/Pipeline-Summary.html
utils/docs/summaries/WorkItems-Summary.html
utils/docs/summaries/Reporting-Summary.html
```

## Modules (utils/modules/)
```
utils/modules/AzDO-Helpers.psm1
```

## Scripts (utils/scripts/project-collection/)

### Configuration
```
utils/scripts/project-collection/config/defaults.json
```

### Collection Scripts
```
utils/scripts/project-collection/collection/ado-collection-metrics.ps1
utils/scripts/project-collection/collection/collection-usage-report.ps1
utils/scripts/project-collection/collection/get-collection-audit.ps1
utils/scripts/project-collection/collection/get-dormant-projects.ps1
utils/scripts/project-collection/collection/get-project-admins.ps1
utils/scripts/project-collection/collection/git-repo-user-list.ps1
```

### Pipeline Scripts
```
utils/scripts/project-collection/pipeline/get-yaml.ps1
utils/scripts/project-collection/pipeline/pipeline-pools.ps1
utils/scripts/project-collection/pipeline/scan-pipeline-yaml.ps1
```

### Export Scripts
```
utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1
```

### Reporting Scripts
```
utils/scripts/project-collection/reporting/azure-devops-metrics-snapshot.ps1
utils/scripts/project-collection/reporting/snapshot-compare.ps1
utils/scripts/project-collection/reporting/snapshot-get.ps1
```

## Package Management Scripts
```
create-pr.ps1
push-to-main.ps1
sync-from-source.ps1
```

## Total Files: 33
