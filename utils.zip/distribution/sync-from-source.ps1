<#
.SYNOPSIS
    Syncs distribution package files from source repository

.DESCRIPTION
    This script copies files from the source repository to the distribution folder
    based on the file list. It ensures the distribution package stays in sync
    with the development branch.

.EXAMPLE
    .\sync-from-source.ps1

.PARAMETER SourcePath
    Path to the source Niche Sandbox repository (dev branch)
#>

param(
    [Parameter(Mandatory=$false)]
    [string]$SourcePath = $null
)

# If no SourcePath provided, try to determine it
if ([string]::IsNullOrEmpty($SourcePath)) {
    # Check if running from distribution folder
    if ($PSScriptRoot -match 'distribution[/\\]?$') {
        $SourcePath = $PSScriptRoot -replace '[\\/]distribution[\\/]?$', ''
    } elseif ($PSScriptRoot) {
        $SourcePath = $PSScriptRoot
    } else {
        # Fallback to current directory
        $SourcePath = Get-Location
    }
}

$ErrorActionPreference = "Stop"

# Files to sync
$SyncFiles = @(
    # Root
    "README.md",
    "tree.flat.distributed.json",
    
    # Manifest and scripts (in distribution folder)
    "distribution/MANIFEST.md",
    "distribution/sync-from-source.ps1",
    "distribution/push-to-main.ps1",
    "distribution/create-pr.ps1",
    
    # Documentation (root)
    "utils/docs/ARCHITECTURE.md",
    "utils/docs/SCRIPT-REFERENCE.md",
    "utils/docs/SCRIPT-PATTERNS.md",
    
    # Dashboard Summaries
    "utils/docs/summaries/Dashboard.html",
    "utils/docs/summaries/dashboard-config.js",
    "utils/docs/summaries/dashboard2.html",
    "utils/docs/summaries/agent-comparison-dashboard.html",
    "utils/docs/summaries/ExportAndDelete-Summary.html",
    "utils/docs/summaries/Collection-Summary.html",
    "utils/docs/summaries/Pipeline-Summary.html",
    "utils/docs/summaries/WorkItems-Summary.html",
    "utils/docs/summaries/Reporting-Summary.html",
    
    # Modules
    "utils/modules/AzDO-Helpers.psm1",
    
    # Collection Scripts
    "utils/scripts/project-collection/collection/get-collection-audit.ps1",
    "utils/scripts/project-collection/collection/get-dormant-projects.ps1",
    "utils/scripts/project-collection/collection/ado-collection-metrics.ps1",
    "utils/scripts/project-collection/collection/collection-usage-report.ps1",
    "utils/scripts/project-collection/collection/git-repo-user-list.ps1",
    "utils/scripts/project-collection/collection/get-project-admins.ps1",
    
    # Pipeline Scripts
    "utils/scripts/project-collection/pipeline/scan-pipeline-yaml.ps1",
    "utils/scripts/project-collection/pipeline/pipeline-pools.ps1",
    "utils/scripts/project-collection/pipeline/get-yaml.ps1",
    
    # Export Scripts
    "utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1",
    
    # Reporting Scripts
    "utils/scripts/project-collection/reporting/snapshot-get.ps1",
    "utils/scripts/project-collection/reporting/snapshot-compare.ps1",
    "utils/scripts/project-collection/reporting/azure-devops-metrics-snapshot.ps1",
    
    # Config
    "utils/scripts/project-collection/config/defaults.json"
)

$DistributionPath = $PSScriptRoot

# If SourcePath is the same as DistributionPath, we need to find the parent
if ($SourcePath -eq $DistributionPath) {
    $SourcePath = Split-Path $SourcePath -Parent
}

Write-Host "Syncing distribution package from source..." -ForegroundColor Cyan
Write-Host "Source: $SourcePath" -ForegroundColor Gray
Write-Host "Target: $DistributionPath" -ForegroundColor Gray
Write-Host ""

$syncedCount = 0
$skippedCount = 0

foreach ($file in $SyncFiles) {
    $sourceFile = Join-Path $SourcePath $file
    $destFile = Join-Path $DistributionPath $file
    
    if (Test-Path $sourceFile) {
        $destDir = Split-Path $destFile -Parent
        if (-not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        
        Copy-Item -Path $sourceFile -Destination $destFile -Force
        Write-Host "[SYNC] $file" -ForegroundColor Green
        $syncedCount++
    } else {
        Write-Host "[SKIP] $file (not found in source)" -ForegroundColor Yellow
        $skippedCount++
    }
}

Write-Host ""
Write-Host "Sync complete!" -ForegroundColor Cyan
Write-Host "  Files synced: $syncedCount" -ForegroundColor Green
Write-Host "  Files skipped: $skippedCount" -ForegroundColor Yellow
Write-Host ""
Write-Host "Run 'git add -A' and commit to update the distribution repository." -ForegroundColor Gray
