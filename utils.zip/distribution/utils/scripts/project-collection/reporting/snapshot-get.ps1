# Azure DevOps Metrics Snapshot
# Pulls current and 6-month-old metrics for all monitored projects
# Outputs: *old.csv (6 months ago) and *new.csv (today)

param(
    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = "C:\code\Niche Sandbox\utils\scripts\project-collection\output"
)

# Projects to monitor
$MonitoredProjects = @(
    # 'Azure Cloud Infrastructure',
    # 'Azure Cloud Remediation',
    # 'BT-Finance',
    # 'CDO',
    # 'CN Redesign'
    # 'CampaignAnalytics',
    # 'Copyright Website',
    # 'Cybersec Team',
    # 'DataWarehouse-OSO',
    # 'Dig Ops Support',
    # 'Digital Multimedia',
    # 'Digital Program Operations',
    # 'Direct Response Monthly Campaigns',
    # 'ECC Sales DB Process Improvement Project',
    # 'Fit Challenge',
    # 'Front-End',
    # 'Fundraising Systems Development',
    # 'HC Redesign',
    # 'HR Systems',
    # 'Heartitude',
    # 'IPAD Heart Check Re-write',
    # 'Instructor Network',
    # 'Liive',
    # 'Living Guidelines Implementation',
    # 'MS Dynamics',
    'Niche Sandbox',
    # 'OSO DataStore',
    # 'OneHeart Datawarehouse',
    # 'Oracle Integration Cloud (OIC)',
    # 'PHD DOTNET',
    # 'ProfessionalHeartDaily',
    # 'Quality Initiatives',
    # 'Rewards Redemption',
    # 'Salesforce Program',
    # 'SalesforceCSP',
    'School Management Tool'
    # 'SharePoint',
    # 'Shared Requirements',
    # 'SingleSignOn',
    # 'Sitecore',
    # 'Social Events',
    # 'WordPress',
    # 'Youth Market',
)

# Date ranges
$today = Get-Date
$sixMonthsAgo = $today.AddMonths(-6)

Write-Host "Current date: $($today.ToString('yyyy-MM-dd'))"
Write-Host "6 months ago: $($sixMonthsAgo.ToString('yyyy-MM-dd'))"
Write-Host "Projects: $($MonitoredProjects.Count)"
Write-Host ""

# Ensure output folder exists
if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder | Out-Null
}


# Use only the $MonitoredProjects array for processing
$projectsToProcess = @()
foreach ($projName in $MonitoredProjects) {
    $projectsToProcess += [PSCustomObject]@{ name = $projName; id = $projName }
}

Write-Host "Processing $($projectsToProcess.Count) projects.."

$oldResults = @()
$newResults = @()
$counter = 0

foreach ($project in $projectsToProcess) {
    $counter++
    Write-Progress -Activity "Collecting Metrics" -Status "$counter of $($projectsToProcess.Count) - $($project.name)" `
        -PercentComplete (($counter / $projectsToProcess.Count) * 100)

    try {
        $oldReport = [PSCustomObject]@{
            ProjectName           = $project.name
            Commits_6mo           = 0
            Builds_6mo            = 0
            'BuildSuccessRate_%'  = 0
            ActiveUsers           = 0
            RepoSize_MB           = 0
            PipelineMinutes       = 0
        }

        $newReport = [PSCustomObject]@{
            ProjectName           = $project.name
            Commits_6mo           = 0
            Builds_6mo            = 0
            'BuildSuccessRate_%'  = 0
            ActiveUsers           = 0
            RepoSize_MB           = 0
            PipelineMinutes       = 0
        }

        # === REPOS & COMMITS ===
        try {
            $repos = az repos list --project $project.id 2>$null | ConvertFrom-Json
            if ($repos) {
                $oldCommits = 0
                $newCommits = 0
                $oldContributors = @{}
                $newContributors = @{}
                $totalRepoSize = 0

                foreach ($repo in $repos) {
                    # Get current repo size
                    try {
                        $repoDetails = az devops invoke --area git --resource repositories `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters api-version=7.1 -o json 2>$null | ConvertFrom-Json
                        if ($repoDetails.size) { $totalRepoSize += $repoDetails.size }
                    } catch {}

                    # Get commits - OLD (6 months ago to 1 month ago)
                    try {
                        $oldFromDate = $sixMonthsAgo.ToString('MM/dd/yyyy')
                        $oldToDate = $sixMonthsAgo.AddMonths(1).ToString('MM/dd/yyyy')
                        $oldCommitsJson = az devops invoke --area git --resource commits `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters "searchCriteria.fromDate=$oldFromDate" "searchCriteria.toDate=$oldToDate" "api-version=7.1" `
                            -o json 2>$null | ConvertFrom-Json
                        
                        if ($oldCommitsJson.value) {
                            $oldCommits += $oldCommitsJson.value.Count
                            foreach ($commit in $oldCommitsJson.value) {
                                if ($commit.author.email) { $oldContributors[$commit.author.email] = $true }
                            }
                        }
                    } catch {}

                    # Get commits - NEW (last 30 days)
                    try {
                        $newFromDate = $today.AddDays(-30).ToString('MM/dd/yyyy')
                        $newToDate = $today.ToString('MM/dd/yyyy')
                        $newCommitsJson = az devops invoke --area git --resource commits `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters "searchCriteria.fromDate=$newFromDate" "searchCriteria.toDate=$newToDate" "api-version=7.1" `
                            -o json 2>$null | ConvertFrom-Json
                        
                        if ($newCommitsJson.value) {
                            $newCommits += $newCommitsJson.value.Count
                            foreach ($commit in $newCommitsJson.value) {
                                if ($commit.author.email) { $newContributors[$commit.author.email] = $true }
                            }
                        }
                    } catch {}
                }
                
                $oldReport.Commits_6mo = $oldCommits
                $newReport.Commits_6mo = $newCommits
                $oldReport.ActiveUsers = $oldContributors.Count
                $newReport.ActiveUsers = $newContributors.Count
                $newReport.RepoSize_MB = [math]::Round($totalRepoSize / 1MB, 2)
                $oldReport.RepoSize_MB = $newReport.RepoSize_MB  # Assume repo size similar 6mo ago
            }
        } catch {}

        # === PIPELINES & BUILDS ===
        try {
            $oldBuilds = 0
            $oldSucceeded = 0
            $oldMinutes = 0
            $newBuilds = 0
            $newSucceeded = 0
            $newMinutes = 0

            $builds = az pipelines runs list --project $project.id --top 1000 2>$null | ConvertFrom-Json
            if ($builds) {
                foreach ($build in $builds) {
                    if ($build.finishTime) {
                        $finishTime = [DateTime]$build.finishTime
                        
                        # OLD: 6 months ago to 1 month ago
                        if ($finishTime -ge $sixMonthsAgo -and $finishTime -lt $sixMonthsAgo.AddMonths(1)) {
                            $oldBuilds++
                            if ($build.result -eq 'succeeded') { $oldSucceeded++ }
                            if ($build.startTime) {
                                $duration = ($finishTime - [DateTime]$build.startTime).TotalMinutes
                                $oldMinutes += $duration
                            }
                        }
                        
                        # NEW: Last 30 days
                        if ($finishTime -ge $today.AddDays(-30)) {
                            $newBuilds++
                            if ($build.result -eq 'succeeded') { $newSucceeded++ }
                            if ($build.startTime) {
                                $duration = ($finishTime - [DateTime]$build.startTime).TotalMinutes
                                $newMinutes += $duration
                            }
                        }
                    }
                }
            }

            $oldReport.Builds_6mo = $oldBuilds
            $newReport.Builds_6mo = $newBuilds
            $oldReport.PipelineMinutes = [math]::Round($oldMinutes, 0)
            $newReport.PipelineMinutes = [math]::Round($newMinutes, 0)
            
            if ($oldBuilds -gt 0) {
                $oldReport.'BuildSuccessRate_%' = [math]::Round(($oldSucceeded / $oldBuilds) * 100, 1)
            }
            if ($newBuilds -gt 0) {
                $newReport.'BuildSuccessRate_%' = [math]::Round(($newSucceeded / $newBuilds) * 100, 1)
            }
        } catch {}

        $oldResults += $oldReport
        $newResults += $newReport

    } catch {
        Write-Host "ERROR: $($project.name) - $($_.Exception.Message)"
        continue
    }
}

Write-Progress -Activity "Collecting Metrics" -Completed

# Export results
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$previousPath = Join-Path $OutputFolder "metrics-previous-$timestamp.csv"
$currentPath  = Join-Path $OutputFolder "metrics-current-$timestamp.csv"

$oldResults | Export-Csv -Path $previousPath -NoTypeInformation
$newResults | Export-Csv -Path $currentPath -NoTypeInformation
Write-Host "Previous metrics: $previousPath"
Write-Host "Current metrics:  $currentPath"