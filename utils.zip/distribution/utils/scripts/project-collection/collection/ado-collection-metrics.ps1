# ADO Collection Metrics Export Script
# Purpose: Extract usage and cost proxy metrics for all projects in collection
# Output: CSV file with KPI data (last 6 months)

param(
    [string]$Organization = "YOUR_ORG",
    [string]$OutputFile = "ADO_Metrics_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
)

# Set up Azure CLI
$env:AZURE_DEVOPS_EXT_PAT = $env:AZURE_DEVOPS_PAT  # Ensure PAT is in environment variable

# Function to get all projects
function Get-ADOProjects {
    $projects = az devops project list --organization "https://dev.azure.com/$Organization" --query "value[].{name:name, id:id}" -o json | ConvertFrom-Json
    return $projects
}

# Function to get Git repo metrics
function Get-GitMetrics {
    param([string]$ProjectName, [int]$DaysBack = 180)
    
    $cutoffDate = (Get-Date).AddDays(-$DaysBack).ToString('yyyy-MM-dd')
    
    try {
        # Get repos in project
        $repos = az repos list --project "$ProjectName" --organization "https://dev.azure.com/$Organization" --query "value[].{name:name, id:id, size:size}" -o json | ConvertFrom-Json
        
        if (-not $repos) { return $null }
        
        $totalCommits = 0
        $totalSize = 0
        $activeUsers = @()
        $lastCommitDate = $null
        
        foreach ($repo in $repos) {
            # Get commits in last 6 months
            $commits = az repos ref list --project "$ProjectName" --repository $repo.id --filter "heads" --organization "https://dev.azure.com/$Organization" -o json 2>$null | ConvertFrom-Json
            
            if ($commits) {
                foreach ($ref in $commits) {
                    $refCommits = az repos commit list --project "$ProjectName" --repository $repo.id --branch $ref.name --skip-first 0 --organization "https://dev.azure.com/$Organization" --query "value[?commitDate >= '$cutoffDate']" -o json 2>$null | ConvertFrom-Json
                    
                    if ($refCommits) {
                        $totalCommits += $refCommits.Count
                        
                        # Collect unique authors
                        foreach ($commit in $refCommits) {
                            if ($commit.author.name) {
                                $activeUsers += $commit.author.name
                            }
                            
                            # Track latest commit
                            if ($commit.commitDate -gt $lastCommitDate) {
                                $lastCommitDate = $commit.commitDate
                            }
                        }
                    }
                }
            }
            
            # Add repo size
            $totalSize += $repo.size
        }
        
        $uniqueUsers = @($activeUsers | Select-Object -Unique).Count
        
        return @{
            Commits = $totalCommits
            RepoSize_MB = [math]::Round($totalSize / 1MB, 2)
            ActiveUsers = $uniqueUsers
            LastCommit = if ($lastCommitDate) { $lastCommitDate } else { "Never" }
        }
    }
    catch {
        Write-Host "Error getting Git metrics for $ProjectName : $_" -ForegroundColor Yellow
        return $null
    }
}

# Function to get Pipeline metrics
function Get-PipelineMetrics {
    param([string]$ProjectName, [int]$DaysBack = 180)
    
    try {
        $pipelines = az pipelines list --project "$ProjectName" --organization "https://dev.azure.com/$Organization" --query "value[].id" -o json | ConvertFrom-Json
        
        if (-not $pipelines) { return $null }
        
        $totalBuilds = 0
        $successfulBuilds = 0
        $totalMinutes = 0
        $lastBuildDate = $null
        
        foreach ($pipelineId in $pipelines) {
            # Get builds from last 6 months
            $builds = az pipelines runs list --project "$ProjectName" --pipeline-ids $pipelineId --organization "https://dev.azure.com/$Organization" --query "value[?finishedDate != null]" -o json 2>$null | ConvertFrom-Json
            
            if ($builds) {
                foreach ($build in $builds) {
                    if ([datetime]$build.finishedDate -gt (Get-Date).AddDays(-$DaysBack)) {
                        $totalBuilds++
                        
                        if ($build.result -eq "succeeded") {
                            $successfulBuilds++
                        }
                        
                        # Calculate pipeline minutes
                        if ($build.finishedDate -and $build.startTime) {
                            $duration = [datetime]$build.finishedDate - [datetime]$build.startTime
                            $totalMinutes += $duration.TotalMinutes
                        }
                        
                        # Track latest build
                        if ($build.finishedDate -gt $lastBuildDate) {
                            $lastBuildDate = $build.finishedDate
                        }
                    }
                }
            }
        }
        
        $successRate = if ($totalBuilds -gt 0) { [math]::Round(($successfulBuilds / $totalBuilds) * 100, 1) } else { 0 }
        
        return @{
            Builds = $totalBuilds
            SuccessRate = $successRate
            PipelineMinutes = [math]::Round($totalMinutes, 0)
            LastBuild = if ($lastBuildDate) { $lastBuildDate } else { "Never" }
        }
    }
    catch {
        Write-Host "Error getting Pipeline metrics for $ProjectName : $_" -ForegroundColor Yellow
        return $null
    }
}

# Function to get Project owner
function Get-ProjectOwner {
    param([string]$ProjectName)
    
    try {
        $project = az devops project show --project "$ProjectName" --organization "https://dev.azure.com/$Organization" -o json | ConvertFrom-Json
        return $project.description -split "`n" | Select-Object -First 1  # Placeholder; adjust based on your setup
    }
    catch {
        return "Unknown"
    }
}

# Main execution
Write-Host "Starting ADO Metrics Collection for Organization: $Organization" -ForegroundColor Green
Write-Host "Data range: Last 6 months"
Write-Host ""

$results = @()
$projects = Get-ADOProjects

if (-not $projects) {
    Write-Host "No projects found or authentication failed." -ForegroundColor Red
    exit
}

Write-Host "Found $($projects.Count) projects. Processing..." -ForegroundColor Cyan
$counter = 0

foreach ($project in $projects) {
    $counter++
    $percentComplete = [math]::Round(($counter / $projects.Count) * 100, 0)
    Write-Host "[$counter/$($projects.Count) - $percentComplete%] Processing: $($project.name)" -ForegroundColor Cyan
    
    $gitMetrics = Get-GitMetrics -ProjectName $project.name
    $pipelineMetrics = Get-PipelineMetrics -ProjectName $project.name
    $owner = Get-ProjectOwner -ProjectName $project.name
    
    # Determine status
    $lastActivity = $null
    if ($gitMetrics.LastCommit -and $gitMetrics.LastCommit -ne "Never") {
        $lastActivity = [datetime]$gitMetrics.LastCommit
    }
    if ($pipelineMetrics.LastBuild -and $pipelineMetrics.LastBuild -ne "Never") {
        if ($lastActivity -eq $null -or [datetime]$pipelineMetrics.LastBuild -gt $lastActivity) {
            $lastActivity = [datetime]$pipelineMetrics.LastBuild
        }
    }
    
    $daysSinceActivity = if ($lastActivity) { [math]::Round(((Get-Date) - $lastActivity).TotalDays, 0) } else { 999 }
    
    if ($daysSinceActivity -gt 365) {
        $status = "Inactive"
    }
    elseif ($daysSinceActivity -gt 180) {
        $status = "Dormant"
    }
    else {
        $status = "Active"
    }
    
    $result = [PSCustomObject]@{
        ProjectName = $project.name
        Commits_6mo = if ($gitMetrics) { $gitMetrics.Commits } else { 0 }
        Builds_6mo = if ($pipelineMetrics) { $pipelineMetrics.Builds } else { 0 }
        BuildSuccessRate_pct = if ($pipelineMetrics) { $pipelineMetrics.SuccessRate } else { 0 }
        ActiveUsers = if ($gitMetrics) { $gitMetrics.ActiveUsers } else { 0 }
        RepoSize_MB = if ($gitMetrics) { $gitMetrics.RepoSize_MB } else { 0 }
        PipelineMinutes = if ($pipelineMetrics) { $pipelineMetrics.PipelineMinutes } else { 0 }
        LastCommit = if ($gitMetrics) { $gitMetrics.LastCommit } else { "Never" }
        LastBuild = if ($pipelineMetrics) { $pipelineMetrics.LastBuild } else { "Never" }
        DaysSinceActivity = $daysSinceActivity
        Owner = $owner
        Status = $status
    }
    
    $results += $result
}

# Export to CSV
$results | Export-Csv -Path $OutputFile -NoTypeInformation -Force

Write-Host ""
Write-Host "Export complete. Results saved to: $OutputFile" -ForegroundColor Green
Write-Host "Total projects processed: $($results.Count)" -ForegroundColor Green
Write-Host "Active projects: $($results | Where-Object { $_.Status -eq 'Active' } | Measure-Object | Select-Object -ExpandProperty Count)" -ForegroundColor Green
Write-Host "Inactive projects: $($results | Where-Object { $_.Status -eq 'Inactive' } | Measure-Object | Select-Object -ExpandProperty Count)" -ForegroundColor Yellow