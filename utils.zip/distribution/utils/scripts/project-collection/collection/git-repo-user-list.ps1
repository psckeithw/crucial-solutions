<#
.SYNOPSIS
    Get list of users and their permissions for an Azure DevOps repository

.DESCRIPTION
    This script retrieves all users with access to a specific Azure DevOps repository
    and displays their permission levels.

.PARAMETER RepoUrl
    The URL of the Azure DevOps repository
    Example: https://dev.azure.com/organization/project/_git/reponame

.PARAMETER PAT
    Personal Access Token for authentication (optional - will use environment variable if not provided)

.EXAMPLE
    .\git-repo-user-list.ps1 -RepoUrl "https://dev.azure.com/myorg/myproject/_git/myrepo"

.EXAMPLE
    .\git-repo-user-list.ps1 -RepoUrl "https://dev.azure.com/myorg/myproject/_git/myrepo" -PAT "your-pat-token"
#>

param(
    [Parameter(Mandatory = $false)]
    [string]$RepoUrl = "https://aha-bt.visualstudio.com/Rewards%20Redemption/_git/Rewards%20Redemption",
    
    [Parameter(Mandatory = $false)]
    [string]$PAT = $env:AZURE_DEVOPS_PAT
)

function Parse-AzureDevOpsRepoUrl {
    param([string]$Url)
    
    # Support both old and new URL formats
    # New: https://dev.azure.com/{organization}/{project}/_git/{repository}
    # Old: https://{organization}.visualstudio.com/{project}/_git/{repository}
    
    if ($Url -match 'https?://dev\.azure\.com/([^/]+)/([^/]+)/_git/([^/]+)') {
        return @{
            Organization = $matches[1]
            Project = [System.Web.HttpUtility]::UrlDecode($matches[2])
            ProjectEncoded = $matches[2]
            Repository = [System.Web.HttpUtility]::UrlDecode($matches[3])
            RepositoryEncoded = $matches[3]
            BaseUrl = "https://dev.azure.com/$($matches[1])"
        }
    }
    elseif ($Url -match 'https?://([^\.]+)\.visualstudio\.com/([^/]+)/_git/([^/]+)') {
        return @{
            Organization = $matches[1]
            Project = [System.Web.HttpUtility]::UrlDecode($matches[2])
            ProjectEncoded = $matches[2]
            Repository = [System.Web.HttpUtility]::UrlDecode($matches[3])
            RepositoryEncoded = $matches[3]
            BaseUrl = "https://$($matches[1]).visualstudio.com"
        }
    }
    else {
        throw "Invalid Azure DevOps repository URL format"
    }
}

function Get-Base64AuthHeader {
    param([string]$PAT)
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
    return @{
        Authorization = "Basic $base64AuthInfo"
        "Content-Type" = "application/json"
    }
}

function Get-PermissionDisplayName {
    param([int]$Permission)
    
    $permissions = @()
    
    # Git repository permissions bit flags
    if ($Permission -band 2) { $permissions += "Read" }
    if ($Permission -band 4) { $permissions += "Contribute" }
    if ($Permission -band 8) { $permissions += "CreateBranch" }
    if ($Permission -band 16) { $permissions += "CreateTag" }
    if ($Permission -band 32) { $permissions += "ManageNotes" }
    if ($Permission -band 64) { $permissions += "PolicyExempt" }
    if ($Permission -band 128) { $permissions += "Administer" }
    if ($Permission -band 256) { $permissions += "CreateRepository" }
    if ($Permission -band 512) { $permissions += "DeleteRepository" }
    if ($Permission -band 1024) { $permissions += "RenameRepository" }
    if ($Permission -band 2048) { $permissions += "EditPolicies" }
    if ($Permission -band 4096) { $permissions += "RemoveOthersLocks" }
    if ($Permission -band 8192) { $permissions += "ManagePermissions" }
    if ($Permission -band 16384) { $permissions += "PullRequestContribute" }
    if ($Permission -band 32768) { $permissions += "PullRequestBypassPolicy" }
    
    if ($permissions.Count -eq 0) {
        return "None"
    }
    
    return ($permissions -join ", ")
}

# Main script execution
try {
    # Load System.Web assembly for URL encoding/decoding
    Add-Type -AssemblyName System.Web

    # Validate PAT
    if ([string]::IsNullOrWhiteSpace($PAT)) {
        throw "PAT is required. Provide via -PAT parameter or set AZURE_DEVOPS_PAT environment variable"
    }

    Write-Host "Repository URL: $RepoUrl" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "Parsing repository URL..." -ForegroundColor Cyan
    $repoInfo = Parse-AzureDevOpsRepoUrl -Url $RepoUrl
    
    Write-Host "Organization: $($repoInfo.Organization)" -ForegroundColor Green
    Write-Host "Project: $($repoInfo.Project)" -ForegroundColor Green
    Write-Host "Repository: $($repoInfo.Repository)" -ForegroundColor Green
    Write-Host ""

    $headers = Get-Base64AuthHeader -PAT $PAT

    # Get repository ID
    Write-Host "Fetching repository details..." -ForegroundColor Cyan
    $repoApiUrl = "$($repoInfo.BaseUrl)/$($repoInfo.ProjectEncoded)/_apis/git/repositories/$($repoInfo.RepositoryEncoded)?api-version=7.0"
    Write-Host "DEBUG - Repo API URL: $repoApiUrl" -ForegroundColor Yellow
    $repo = Invoke-RestMethod -Uri $repoApiUrl -Headers $headers -Method Get
    $repoId = $repo.id

    Write-Host "Repository ID: $repoId" -ForegroundColor Green
    Write-Host ""

    # Get Access Control Lists (ACLs) for the repository
    Write-Host "Fetching permissions..." -ForegroundColor Cyan
    
    # Git repositories use the security namespace for Git Repositories
    $gitSecurityNamespaceId = "2e9eb7ed-3c0a-47d4-87c1-0ffdd275fd87"
    
    # The token format for a repository is: repoV2/{ProjectId}/{RepoId}
    $projectApiUrl = "$($repoInfo.BaseUrl)/_apis/projects/$($repoInfo.ProjectEncoded)?api-version=7.0"
    Write-Host "DEBUG - Project API URL: $projectApiUrl" -ForegroundColor Yellow
    $project = Invoke-RestMethod -Uri $projectApiUrl -Headers $headers -Method Get
    $projectId = $project.id
    Write-Host "DEBUG - Project ID: $projectId" -ForegroundColor Yellow
    
    $token = "repoV2/$projectId/$repoId"
    Write-Host "DEBUG - Security token: $token" -ForegroundColor Yellow
    
    # Get ACLs
    $aclUrl = "$($repoInfo.BaseUrl)/_apis/accesscontrollists/$($gitSecurityNamespaceId)?token=$token&api-version=7.0"
    Write-Host "DEBUG - ACL URL: $aclUrl" -ForegroundColor Yellow
    $acls = Invoke-RestMethod -Uri $aclUrl -Headers $headers -Method Get

    # Also get project-level permissions to catch inherited access
    Write-Host "Also fetching project-level Git permissions for inherited access..." -ForegroundColor Cyan
    $projectToken = "repoV2/$projectId"
    $projectAclUrl = "$($repoInfo.BaseUrl)/_apis/accesscontrollists/$($gitSecurityNamespaceId)?token=$projectToken&api-version=7.0"
    Write-Host "DEBUG - Project ACL URL: $projectAclUrl" -ForegroundColor Yellow
    try {
        $projectAcls = Invoke-RestMethod -Uri $projectAclUrl -Headers $headers -Method Get
        # Merge project ACLs with repo ACLs
        if ($projectAcls.value) {
            $acls.value += $projectAcls.value
        }
    }
    catch {
        Write-Warning "Could not fetch project-level permissions: $($_.Exception.Message)"
    }

    if ($acls.count -eq 0 -and (-not $acls.value)) {
        Write-Host "No permissions found." -ForegroundColor Yellow
        exit
    }

    # Collect all unique identities
    $identityDescriptors = @()
    foreach ($acl in $acls.value) {
        foreach ($ace in $acl.acesDictionary.PSObject.Properties) {
            if ($ace.Name -notin $identityDescriptors) {
                $identityDescriptors += $ace.Name
            }
        }
    }

    if ($identityDescriptors.Count -eq 0) {
        Write-Host "No permissions found." -ForegroundColor Yellow
        exit
    }
    
    Write-Host "Found $($identityDescriptors.Count) unique identities in ACLs" -ForegroundColor Green
    Write-Host ""

    # Resolve identities
    Write-Host "Resolving $($identityDescriptors.Count) identities..." -ForegroundColor Cyan
    
    $results = @()
    
    foreach ($descriptor in $identityDescriptors) {
        try {
            # Get permissions for this identity first
            $permissions = @()
            $allow = 0
            $deny = 0
            
            foreach ($acl in $acls.value) {
                if ($acl.acesDictionary.PSObject.Properties.Name -contains $descriptor) {
                    $ace = $acl.acesDictionary.$descriptor
                    $allow = $ace.allow
                    $deny = $ace.deny
                    
                    # Effective permissions are allow & ~deny
                    $effective = $allow -band (-bnot $deny)
                    
                    if ($effective -gt 0) {
                        $permissions += Get-PermissionDisplayName -Permission $effective
                    }
                }
            }
            
            # Try different methods to resolve the identity
            $displayName = $null
            $email = "N/A"
            $isGroup = $false
            $identityType = "Unknown"
            $resolved = $false
            
            # Method 1: Standard identities API
            try {
                $identityUrl = "$($repoInfo.BaseUrl)/_apis/identities?descriptors=$descriptor&api-version=7.0"
                $identity = Invoke-RestMethod -Uri $identityUrl -Headers $headers -Method Get
                
                if ($identity.value.Count -gt 0) {
                    $id = $identity.value[0]
                    $displayName = if ($id.displayName) { $id.displayName } else { $id.providerDisplayName }
                    $isGroup = $id.PSObject.Properties.Name -contains 'isContainer' -and $id.isContainer
                    $email = if ($id.PSObject.Properties.Name -contains 'mailAddress') { $id.mailAddress } else { "N/A" }
                    $identityType = if ($isGroup) { "Group" } else { "AAD User" }
                    $resolved = $true
                }
            }
            catch {
                # Method 2: Try parsing the descriptor
                Write-Host "  - Trying alternate resolution for: $descriptor" -ForegroundColor Yellow
                
                # Extract email from claims-based descriptor
                if ($descriptor -match '\\([^\\]+@[^\\]+)$') {
                    $email = $matches[1]
                    $displayName = $email
                    $identityType = "AAD User (Unresolved - Possibly Deleted)"
                    $resolved = $true
                }
                elseif ($descriptor -match 'ServiceIdentity;[^:]+:([^:]+):') {
                    # Service identity (like Build service)
                    $displayName = "$($matches[1]) Service Account"
                    $identityType = "Service Account"
                    $resolved = $true
                }
                elseif ($descriptor -match 'TeamFoundation\.Identity;(S-1-9-.+)$') {
                    # Try to resolve TFS identity via subject descriptor
                    $sid = $matches[1]
                    try {
                        # Try graph API with subject query
                        $subjectDescriptor = "Microsoft.TeamFoundation.Identity;$sid"
                        $graphUrl = "$($repoInfo.BaseUrl)/_apis/graph/descriptors/$([System.Web.HttpUtility]::UrlEncode($subjectDescriptor))?api-version=7.0-preview.1"
                        $graphResult = Invoke-RestMethod -Uri $graphUrl -Headers $headers -Method Get
                        
                        if ($graphResult.value) {
                            $displayName = $graphResult.value
                            $identityType = "Group/Identity"
                            $resolved = $true
                        }
                    }
                    catch {
                        # Couldn't resolve via graph, use generic name
                        $displayName = "TFS Identity (SID: $sid)"
                        $identityType = "Group/Identity (Unresolved)"
                        $resolved = $true
                    }
                }
                elseif ($descriptor -match '\\([^\\]+)$') {
                    # Could be username or group
                    $displayName = $matches[1]
                    $email = "N/A"
                    $identityType = "Unresolved"
                    $resolved = $true
                }
                else {
                    # Show the descriptor itself
                    $displayName = $descriptor
                    $email = "N/A"
                    $identityType = "Unresolved Identity"
                    $resolved = $true
                }
            }
            
            # Add to results if we have permissions or resolved something
            if ($permissions.Count -gt 0 -or $resolved) {
                $results += [PSCustomObject]@{
                    DisplayName = $displayName
                    Type = $identityType
                    Email = $email
                    Permissions = if ($permissions.Count -gt 0) { ($permissions | Select-Object -Unique) -join "; " } else { "None/Inherited" }
                    Descriptor = $descriptor
                }
            }
        }
        catch {
            Write-Warning "Failed to process identity: $descriptor - $($_.Exception.Message)"
            # Still add it to show we found something
            $results += [PSCustomObject]@{
                DisplayName = $descriptor
                Type = "Error"
                Email = "N/A"
                Permissions = "Failed to resolve"
                Descriptor = $descriptor
            }
        }
    }

    # Display results
    Write-Host ""
    Write-Host "=== Repository Permissions ===" -ForegroundColor Cyan
    Write-Host ""
    
    $results | Sort-Object Type, DisplayName | Format-Table -AutoSize -Property DisplayName, Type, Email, Permissions
    
    Write-Host ""
    Write-Host "Total: $($results.Count) identities" -ForegroundColor Green
    $userCount = $results | Where-Object { $_.Type -like "*User*" } | Measure-Object | Select-Object -ExpandProperty Count
    $groupCount = $results | Where-Object { $_.Type -eq 'Group' -or $_.Type -like "*Group/Identity*" } | Measure-Object | Select-Object -ExpandProperty Count
    $unresolvedCount = $results | Where-Object { $_.Type -like "*Unresolved*" -or $_.Type -like "*Deleted*" } | Measure-Object | Select-Object -ExpandProperty Count
    Write-Host "  - Users: $userCount" -ForegroundColor Green
    Write-Host "  - Groups: $groupCount" -ForegroundColor Green
    if ($unresolvedCount -gt 0) {
        Write-Host "  - Unresolved/Deleted: $unresolvedCount" -ForegroundColor Yellow
    }
    
    # Option to expand group memberships
    $groupsToExpand = $results | Where-Object { $_.Type -eq 'Group' -or $_.Type -like "*Group/Identity*" }
    if ($groupsToExpand.Count -gt 0) {
        Write-Host ""
        $expand = Read-Host "Would you like to expand group memberships to see individual users? (Y/N)"
        if ($expand -eq 'Y' -or $expand -eq 'y') {
            Write-Host ""
            Write-Host "=== Expanding Group Memberships ===" -ForegroundColor Cyan
            
            foreach ($group in $groupsToExpand) {
                Write-Host ""
                Write-Host "Group: $($group.DisplayName)" -ForegroundColor Yellow
                
                try {
                    # Try to get group members
                    $membersUrl = "$($repoInfo.BaseUrl)/_apis/graph/groups/$([System.Web.HttpUtility]::UrlEncode($group.Descriptor))/members?api-version=7.0-preview.1"
                    $members = Invoke-RestMethod -Uri $membersUrl -Headers $headers -Method Get
                    
                    if ($members.value.Count -gt 0) {
                        foreach ($member in $members.value) {
                            $memberName = if ($member.displayName) { $member.displayName } else { $member.principalName }
                            $memberEmail = if ($member.mailAddress) { $member.mailAddress } else { "N/A" }
                            Write-Host "  - $memberName ($memberEmail)" -ForegroundColor Gray
                        }
                    }
                    else {
                        Write-Host "  (No members found or unable to retrieve)" -ForegroundColor Gray
                    }
                }
                catch {
                    Write-Host "  (Unable to expand: $($_.Exception.Message))" -ForegroundColor Gray
                }
            }
        }
    }

    # Export option
    $export = Read-Host "`nWould you like to export to CSV? (Y/N)"
    if ($export -eq 'Y' -or $export -eq 'y') {
        $csvPath = Join-Path $PSScriptRoot "repo-permissions-export-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
        $results | Export-Csv -Path $csvPath -NoTypeInformation
        Write-Host "Exported to: $csvPath" -ForegroundColor Green
    }
}
catch {
    Write-Error "Error: $($_.Exception.Message)"
    Write-Host "Stack Trace: $($_.ScriptStackTrace)" -ForegroundColor Red
    exit 1
}
