#Requires -Version 7.0
<#
.SYNOPSIS
    Performs a comprehensive audit of Azure DevOps collection activity.
.DESCRIPTION
    Analyzes all projects in an organization for activity across repos, pipelines,
    work items, pull requests, and releases. Outputs detailed activity report.
.PARAMETER Org
    Azure DevOps organization name.
.PARAMETER PatEnvVar
    Environment variable name containing the PAT.
.PARAMETER ProjectName
    Optional: specific project to analyze.
.PARAMETER Days
    Dormancy threshold in days.
.PARAMETER OutputFolder
    Folder for CSV output.
.PARAMETER PromptIfMissing
    Prompt for PAT if not found in environment variable.
.EXAMPLE
    .\get-collection-audit.ps1
.EXAMPLE
    .\get-collection-audit.ps1 -ProjectName "MyProject" -Days 180
#>
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Org = 'aha-bt',

    [Parameter()]
    [string]$PatEnvVar = 'AZDO_PAT',

    [Parameter()]
    [string]$ProjectName,

    [Parameter()]
    [int]$Days = 90,

    [Parameter()]
    [string]$OutputFolder = './output',

    [Parameter()]
    [switch]$PromptIfMissing
)

# Load configuration
$configPath = Join-Path $PSScriptRoot '..\config\defaults.json'
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
    if (-not $PSBoundParameters.ContainsKey('Org')) { $Org = $config.organization }
    if (-not $PSBoundParameters.ContainsKey('PatEnvVar')) { $PatEnvVar = $config.patEnvVar }
    if (-not $PSBoundParameters.ContainsKey('Days')) { $Days = $config.defaults.daysDormant }
}

# Import module (robust path resolution)
$modulePath = Join-Path $PSScriptRoot '..\..\..\modules\AzDO-Helpers.psm1'
if (-not (Get-Module -ListAvailable -Name AzDO-Helpers)) {
    Import-Module $modulePath -Force
}

# Get authentication (use testPat from config if present, otherwise env var or prompt)
if ($config.testPat -and $config.testPat -ne "REVOKED_OR_FAKE_PAT_VALUE") {
    $pat = $config.testPat
} else {
    $pat = Get-AdoPat -EnvVarName $PatEnvVar -PromptIfMissing:$PromptIfMissing
}
$headers = Get-AdoHeaders -Pat $pat

# Get projects
Write-Host "Fetching projects..." -ForegroundColor Cyan
$projects = Get-AdoProjects -Org $Org -Headers $headers

# Filter by project name if specified
if ($ProjectName) {
    $projects = $projects | Where-Object { $_.name -like "*$ProjectName*" }
    if ($projects.Count -eq 0) {
        Write-Host "No projects found matching: $ProjectName" -ForegroundColor Red
        exit
    }
    Write-Host "Filtered to project(s) matching: $ProjectName" -ForegroundColor Yellow
}

$totalProjects = $projects.Count
$counter = 0
$results = @()

Write-Host "`nAnalyzing $totalProjects projects for comprehensive activity...`n" -ForegroundColor Cyan

foreach ($project in $projects) {
    $counter++
    $percent = [math]::Round(($counter / $totalProjects) * 100)
    Write-Progress -Activity "Scanning Projects" -Status "$counter of $totalProjects - $($project.name)" -PercentComplete $percent

    # Initialize activity record
    $activity = @{
        ProjectName = $project.name
        ProjectId = $project.id
        LastProjectUpdate = [DateTime]$project.lastUpdateTime
        MostRecentActivity = $null
        LastCommitDate = $null
        LastPipelineRun = $null
        LastWorkItemUpdate = $null
        LastPullRequest = $null
        LastReleaseDate = $null
        WorkItemCount = 0
        RepoCount = 0
        PipelineCount = 0
        ReleaseCount = 0
    }

    $dates = @([DateTime]$project.lastUpdateTime)

    # Repos -> latest commit
    try {
        $repos = Get-AdoRepos -Org $Org -Project $project.id -Headers $headers
        if ($repos -and $repos.Count -gt 0) {
            $activity.RepoCount = $repos.Count
            foreach ($repo in $repos | Select-Object -First $config.defaults.topRepos) {
                try {
                    $commits = Get-AdoRepoCommits -Org $Org -Project $project.id -RepoId $repo.id -Headers $headers -Top 1
                    if ($commits -and $commits.Count -gt 0) {
                        $commitDate = [DateTime]$commits[0].author.date
                        $dates += $commitDate
                        if (-not $activity.LastCommitDate -or $commitDate -gt $activity.LastCommitDate) {
                            $activity.LastCommitDate = $commitDate
                        }
                    }
                }
                catch { }
            }
        }
    }
    catch { }

    # Pipelines -> recent runs
    try {
        $pipelines = Get-AdoPipelines -Org $Org -Project $project.name -Headers $headers
        if ($pipelines) {
            $activity.PipelineCount = $pipelines.Count
        }

        $builds = Get-AdoPipelineRuns -Org $Org -Project $project.name -Headers $headers -Top $config.defaults.topPipelines

        if ($builds -and $builds.Count -gt 0) {
            foreach ($build in $builds) {
                if ($build.finishTime) {
                    $finishTime = [DateTime]$build.finishTime
                    $dates += $finishTime
                    if (-not $activity.LastPipelineRun -or $finishTime -gt $activity.LastPipelineRun) {
                        $activity.LastPipelineRun = $finishTime
                    }
                }
            }
        }
    }
    catch { }

    # Work Items
    try {
        $wiqlQuery = "SELECT [System.Id], [System.ChangedDate] FROM WorkItems WHERE [System.TeamProject] = '$($project.name)' ORDER BY [System.ChangedDate] DESC"
        $workItems = Get-AdoWorkItems -Org $Org -Project $project.name -Headers $headers -WiqlQuery $wiqlQuery

        if ($workItems -and $workItems.Count -gt 0) {
            $activity.WorkItemCount = $workItems.Count

            foreach ($wi in $workItems | Select-Object -First $config.defaults.topWorkItems) {
                try {
                    $wiDetail = Invoke-AdoApi -Org $Org -Project $project.name -Method Get -ApiPath "_apis/wit/workitems/$($wi.id)" -Headers $headers
                    if ($wiDetail -and $wiDetail.fields.'System.ChangedDate') {
                        $changedDate = [DateTime]$wiDetail.fields.'System.ChangedDate'
                        $dates += $changedDate
                        if (-not $activity.LastWorkItemUpdate -or $changedDate -gt $activity.LastWorkItemUpdate) {
                            $activity.LastWorkItemUpdate = $changedDate
                        }
                    }
                }
                catch { }
            }
        }
    }
    catch { }

    # Pull Requests
    try {
        $prs = Get-AdoPullRequests -Org $Org -Project $project.name -Headers $headers -Top $config.defaults.topPipelines
        if ($prs -and $prs.Count -gt 0) {
            foreach ($pr in $prs) {
                if ($pr.closedDate) {
                    $prDate = [DateTime]$pr.closedDate
                    $dates += $prDate
                    if (-not $activity.LastPullRequest -or $prDate -gt $activity.LastPullRequest) {
                        $activity.LastPullRequest = $prDate
                    }
                }
                elseif ($pr.creationDate) {
                    $prDate = [DateTime]$pr.creationDate
                    $dates += $prDate
                    if (-not $activity.LastPullRequest -or $prDate -gt $activity.LastPullRequest) {
                        $activity.LastPullRequest = $prDate
                    }
                }
            }
        }
    }
    catch { }

    # Releases
    try {
        $releases = Get-AdoReleases -Org $Org -Project $project.name -Headers $headers -Top $config.defaults.topPipelines
        if ($releases -and $releases.Count -gt 0) {
            $activity.ReleaseCount = $releases.Count
            foreach ($release in $releases) {
                if ($release.createdOn) {
                    $releaseDate = [DateTime]$release.createdOn
                    $dates += $releaseDate
                    if (-not $activity.LastReleaseDate -or $releaseDate -gt $activity.LastReleaseDate) {
                        $activity.LastReleaseDate = $releaseDate
                    }
                }
            }
        }
    }
    catch { }

    # Compute most recent activity
    if ($dates.Count -gt 0) {
        $activity.MostRecentActivity = ($dates | Measure-Object -Maximum).Maximum
    }

    $results += [PSCustomObject]$activity
}

Write-Progress -Activity "Scanning Projects" -Completed
Write-Host "`n=== ANALYSIS COMPLETE ===`n" -ForegroundColor Green

# Export results
if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outputPath = Join-Path $OutputFolder "CollectionAudit-$timestamp.csv"

$results | Select-Object `
    ProjectName,
    @{ Name = 'MostRecentActivity'; Expression = { if ($_.MostRecentActivity) { $_.MostRecentActivity.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' } } },
    @{ Name = 'LastWorkItemUpdate'; Expression = { if ($_.LastWorkItemUpdate) { $_.LastWorkItemUpdate.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' } } },
    @{ Name = 'LastCommitDate'; Expression = { if ($_.LastCommitDate) { $_.LastCommitDate.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' } } },
    @{ Name = 'LastPipelineRun'; Expression = { if ($_.LastPipelineRun) { $_.LastPipelineRun.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' } } },
    @{ Name = 'LastReleaseDate'; Expression = { if ($_.LastReleaseDate) { $_.LastReleaseDate.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' } } },
    @{ Name = 'DaysSinceActivity'; Expression = { if ($_.MostRecentActivity) { (New-TimeSpan -Start $_.MostRecentActivity -End (Get-Date)).Days } else { 'N/A' } } },
    WorkItemCount, RepoCount, PipelineCount, ReleaseCount |
    Export-Csv -Path $outputPath -NoTypeInformation

Write-Host "Results exported to: $outputPath" -ForegroundColor Green
Write-Host "Opening file..." -ForegroundColor Gray
Invoke-Item $outputPath
