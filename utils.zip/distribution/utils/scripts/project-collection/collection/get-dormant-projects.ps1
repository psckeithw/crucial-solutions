#Requires -Version 7.0
<#
.SYNOPSIS
    Identifies dormant Azure DevOps projects.
.DESCRIPTION
    Finds projects with no activity (commits, pipelines, work items) for a specified
    number of days.
.PARAMETER Org
    Azure DevOps organization name.
.PARAMETER PatEnvVar
    Environment variable name containing the PAT.
.PARAMETER Days
    Number of days of inactivity to flag as dormant.
.PARAMETER ProjectName
    Optional: specific project to check.
.PARAMETER OutputFolder
    Folder for CSV output.
.PARAMETER PromptIfMissing
    Prompt for PAT if not found in environment variable.
.EXAMPLE
    .\get-dormant-projects.ps1
.EXAMPLE
    .\get-dormant-projects.ps1 -Days 180
#>
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Org = 'aha-bt',

    [Parameter()]
    [string]$PatEnvVar = 'AZDO_PAT',

    [Parameter()]
    [int]$Days = 90,

    [Parameter()]
    [string]$ProjectName,

    [Parameter()]
    [string]$OutputFolder = './output',

    [Parameter()]
    [switch]$PromptIfMissing
)

# Load configuration
$configPath = Join-Path $PSScriptRoot '..\config\defaults.json'
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
    if (-not $PSBoundParameters.ContainsKey('Org')) { $Org = $config.organization }
    if (-not $PSBoundParameters.ContainsKey('PatEnvVar')) { $PatEnvVar = $config.patEnvVar }
    if (-not $PSBoundParameters.ContainsKey('Days')) { $Days = $config.defaults.daysDormant }
}

# Import module (robust path resolution)
$modulePath = Join-Path $PSScriptRoot '..\..\..\modules\AzDO-Helpers.psm1'
if (-not (Get-Module -ListAvailable -Name AzDO-Helpers)) {
    Import-Module $modulePath -Force
}

# Get authentication (use testPat from config if present, otherwise env var or prompt)
if ($config.testPat -and $config.testPat -ne "REVOKED_OR_FAKE_PAT_VALUE") {
    $pat = $config.testPat
} else {
    $pat = Get-AdoPat -EnvVarName $PatEnvVar -PromptIfMissing:$PromptIfMissing
}
$headers = Get-AdoHeaders -Pat $pat

# Cutoff date
$cutoffDate = (Get-Date).AddDays(-$Days)

# Get projects
Write-Host "Fetching projects..." -ForegroundColor Cyan
$projects = Get-AdoProjects -Org $Org -Headers $headers

# Filter by project name if specified
if ($ProjectName) {
    $projects = $projects | Where-Object { $_.name -like "*$ProjectName*" }
    if ($projects.Count -eq 0) {
        Write-Host "No projects found matching: $ProjectName" -ForegroundColor Red
        exit
    }
    Write-Host "Filtered to project(s) matching: $ProjectName" -ForegroundColor Yellow
}

$totalProjects = $projects.Count
$counter = 0
$results = @()

Write-Host "`nAnalyzing $totalProjects projects for dormancy (>$Days days)...`n" -ForegroundColor Cyan

foreach ($project in $projects) {
    $counter++
    $percent = [math]::Round(($counter / $totalProjects) * 100)
    Write-Progress -Activity "Scanning Projects" -Status "$counter of $totalProjects - $($project.name)" -PercentComplete $percent

    $activity = @{
        ProjectName = $project.name
        ProjectId = $project.id
        LastProjectUpdate = [DateTime]$project.lastUpdateTime
        MostRecentActivity = $null
    }

    $dates = @([DateTime]$project.lastUpdateTime)

    # Repos -> latest commit
    try {
        $repos = Get-AdoRepos -Org $Org -Project $project.id -Headers $headers
        if ($repos -and $repos.Count -gt 0) {
            foreach ($repo in $repos | Select-Object -First $config.defaults.topRepos) {
                try {
                    $commits = Get-AdoRepoCommits -Org $Org -Project $project.id -RepoId $repo.id -Headers $headers -Top 1
                    if ($commits -and $commits.Count -gt 0) {
                        $dates += [DateTime]$commits[0].author.date
                    }
                }
                catch { }
            }
        }
    }
    catch { }

    # Pipelines -> recent runs
    try {
        $builds = Get-AdoPipelineRuns -Org $Org -Project $project.name -Headers $headers -Top $config.defaults.topPipelines
        if ($builds -and $builds.Count -gt 0) {
            foreach ($build in $builds) {
                if ($build.finishTime) {
                    $dates += [DateTime]$build.finishTime
                }
            }
        }
    }
    catch { }

    # Compute most recent activity
    if ($dates.Count -gt 0) {
        $activity.MostRecentActivity = ($dates | Measure-Object -Maximum).Maximum
    }

    $results += [PSCustomObject]$activity
}

Write-Progress -Activity "Scanning Projects" -Completed
Write-Host "`n=== ANALYSIS COMPLETE ===`n" -ForegroundColor Green

# Filter to dormant projects
$dormantProjects = $results |
    Where-Object { $_.MostRecentActivity -lt $cutoffDate } |
    Sort-Object MostRecentActivity

Write-Host "Projects with NO activity in last $Days days: $($dormantProjects.Count)" -ForegroundColor Yellow
Write-Host "Cutoff date: $($cutoffDate.ToString('yyyy-MM-dd'))`n" -ForegroundColor Gray

# Export results
if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outputPath = Join-Path $OutputFolder "DormantProjects-$timestamp.csv"

$dormantProjects | Select-Object `
    ProjectName,
    @{ Name = 'LastActivity'; Expression = { $_.MostRecentActivity.ToString('yyyy-MM-dd') } },
    @{ Name = 'DaysDormant'; Expression = { (New-TimeSpan -Start $_.MostRecentActivity -End (Get-Date)).Days } } |
    Export-Csv -Path $outputPath -NoTypeInformation

Write-Host "Results exported to: $outputPath" -ForegroundColor Green
Write-Host "Opening file..." -ForegroundColor Gray
Invoke-Item $outputPath
