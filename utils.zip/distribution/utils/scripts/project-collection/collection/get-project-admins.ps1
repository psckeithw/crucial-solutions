<#
.SYNOPSIS
    Retrieves all Project Administrator users for specified Azure DevOps projects.

.DESCRIPTION
    Uses the Azure DevOps Graph API to find all users (not groups) that have Project Administrator
    permissions on the specified projects. Handles nested group membership recursively.

.PARAMETER Organization
    The Azure DevOps organization name (e.g., "myorg" from "https://dev.azure.com/myorg")

.PARAMETER PAT
    Personal Access Token with appropriate permissions (must have Graph API access)

.PARAMETER ProjectNames
    Array of project names to query. Defaults to "The Best Team Project" and "Rapid Deployment Project"

.PARAMETER OutputJson
    Optional path to save results as JSON file (matching project-admins.json format)

.EXAMPLE
    .\Get-ProjectAdmins.ps1 -Organization "myorg" -PAT "xxxxx"

.EXAMPLE
    .\Get-ProjectAdmins.ps1 -Organization "myorg" -PAT "xxxxx" -ProjectNames "Project A", "Project B" -Verbose

.EXAMPLE
    .\Get-ProjectAdmins.ps1 -Organization "myorg" -PAT "xxxxx" -OutputJson "project-admins.json"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, HelpMessage = "Azure DevOps Organization name")]
    [string]$Organization,

    [Parameter(Mandatory = $true, HelpMessage = "Personal Access Token")]
    [string]$PAT,

    [Parameter(Mandatory = $false, HelpMessage = "Project names to query")]
    [string[]]$ProjectNames = $null,

    [Parameter(Mandatory = $false, HelpMessage = "Output results to JSON file")]
    [string]$OutputJson
)

#region Helper Functions

# Global array of users to always ignore
$Global:AlwaysIgnoreUsers = @(
    "A-Aaron.Peters",
    "A-Augie.Hidalgo",
    "A-Cesar.Ramirez",
    "A-Corey.Clements",
    "A-David.Summers",
    "A-John.Jordan",
    "A-Muhammad.Arsalan",
    "A-Shelly.Parker",
    "A-T-Tony.Ehiguese",
    "Mary.Ellen.Joseph",
    "Ed.Ernest",
    "Keith.Watson",
    "David.Summers"
)

function Invoke-AzDoApi {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        [string]$Method = "GET",

        [Parameter(Mandatory = $false)]
        [hashtable]$Headers = @{}
    )

    try {
        Write-Verbose "Calling: $Method $Uri"
        $response = Invoke-RestMethod -Uri $Uri -Method $Method -Headers $Headers -ContentType "application/json"
        Write-Verbose "Response received successfully"
        return $response
    }
    catch {
        $statusCode = $_.Exception.Response.StatusCode.value__
        $statusDescription = $_.Exception.Response.StatusDescription
        $errorMessage = $_.Exception.Message
        Write-Error "API Call Failed: $statusCode $statusDescription - $errorMessage"
        Write-Verbose "Failed URI: $Uri"
        throw
    }
}

function Get-ProjectId {
    # FIX 2: Fetch all projects and filter client-side — ?name= parameter is ignored by Azure DevOps API
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [hashtable]$Headers,

        [Parameter(Mandatory = $true)]
        [string]$Organization
    )

    $uri = "https://dev.azure.com/$($Organization)/_apis/projects?api-version=7.1&`$top=500"

    Write-Verbose "Looking up project ID for: $ProjectName"

    try {
        $response = Invoke-AzDoApi -Uri $uri -Headers $Headers

        $project = $response.value | Where-Object { $_.name -eq $ProjectName }

        if ($null -eq $project) {
            Write-Warning "Project '$ProjectName' not found. Skipping..."
            return $null
        }

        if (($project | Measure-Object).Count -gt 1) {
            Write-Warning "Multiple projects found matching '$ProjectName'. Using first match."
            $project = $project[0]
        }

        Write-Verbose "Found project '$($project.name)' with ID: $($project.id)"

        return @{
            Id   = $project.id
            Name = $project.name
        }
    }
    catch {
        Write-Warning "Failed to get project ID for '$ProjectName': $_"
        return $null
    }
}

function Get-ProjectScopeDescriptor {
    # FIX 1: Use $() subexpression syntax in URI — backtick before ? is unreliable
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProjectId,

        [Parameter(Mandatory = $true)]
        [hashtable]$Headers,

        [Parameter(Mandatory = $true)]
        [string]$Organization
    )

    $uri = "https://vssps.dev.azure.com/$($Organization)/_apis/graph/descriptors/$($ProjectId)?api-version=7.1-preview.1"

    Write-Verbose "Getting project scope descriptor for project ID: $ProjectId"

    try {
        $response = Invoke-AzDoApi -Uri $uri -Headers $Headers
        $scopeDescriptor = $response.value
        Write-Verbose "Project scope descriptor: $scopeDescriptor"
        return $scopeDescriptor
    }
    catch {
        Write-Warning "Failed to get project scope descriptor: $_"
        throw
    }
}

function Get-ProjectAdministratorsGroup {
    # FIX 1: Use $() subexpression syntax in URI
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ScopeDescriptor,

        [Parameter(Mandatory = $true)]
        [hashtable]$Headers,

        [Parameter(Mandatory = $true)]
        [string]$Organization
    )

    $uri = "https://vssps.dev.azure.com/$($Organization)/_apis/graph/groups?scopeDescriptor=$($ScopeDescriptor)&api-version=7.1-preview.1"

    Write-Verbose "Getting project groups with scope: $ScopeDescriptor"

    try {
        $response = Invoke-AzDoApi -Uri $uri -Headers $Headers

        $adminGroup = $response.value | Where-Object { $_.displayName -eq "Project Administrators" }

        if (-not $adminGroup) {
            Write-Warning "Project Administrators group not found"
            return $null
        }

        Write-Verbose "Found Project Administrators group with descriptor: $($adminGroup.descriptor)"
        return $adminGroup.descriptor
    }
    catch {
        Write-Warning "Failed to get project groups: $_"
        throw
    }
}

function Get-GroupMembers {
    # FIX 1: Use $() subexpression syntax in URI
    # FIX 4: Pagination via X-MS-ContinuationToken response header
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$GroupDescriptor,

        [Parameter(Mandatory = $true)]
        [hashtable]$Headers,

        [Parameter(Mandatory = $true)]
        [string]$Organization
    )

    $baseUri = "https://vssps.dev.azure.com/$($Organization)/_apis/graph/memberships/$($GroupDescriptor)?direction=down&api-version=7.1-preview.1"

    Write-Verbose "Getting members for group: $GroupDescriptor"

    $allMembers = [System.Collections.Generic.List[object]]::new()
    $continuationToken = $null
    $pageCount = 0

    do {
        $pageCount++
        Write-Verbose "Fetching page $pageCount"

        $uri = $baseUri
        if ($continuationToken) {
            $uri = "$baseUri&continuationToken=$($continuationToken)"
        }

        try {
            $responseHeaders = @{}
            $response = Invoke-RestMethod -Uri $uri -Method GET -Headers $Headers -ContentType "application/json" -ResponseHeadersVariable responseHeaders

            if ($response.value) {
                foreach ($member in $response.value) {
                    $allMembers.Add($member)
                }
            }

            if ($responseHeaders.ContainsKey("X-MS-ContinuationToken")) {
                $continuationToken = $responseHeaders["X-MS-ContinuationToken"][0]
                Write-Verbose "Continuation token found, fetching next page"
            }
            else {
                $continuationToken = $null
                Write-Verbose "No continuation token — pagination complete"
            }
        }
        catch {
            Write-Warning "Failed to get group memberships on page $pageCount`: $_"
            throw
        }

    } while ($continuationToken)

    Write-Verbose "Found $($allMembers.Count) total members across $pageCount page(s)"
    return $allMembers.ToArray()
}

function Get-GroupMemberDetails {
    # FIX 1: Use $() subexpression syntax in URI
    # FIX 3: Determine subjectKind from descriptor prefix — no speculative API calls
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$MemberDescriptor,

        [Parameter(Mandatory = $true)]
        [hashtable]$Headers,

        [Parameter(Mandatory = $true)]
        [string]$Organization
    )


    # Ignore Azure AD groups (aadgp prefix)
    if ($MemberDescriptor -match '^aadgp\.') {
        Write-Verbose "Ignoring Azure AD group descriptor: $MemberDescriptor"
        return $null
    }
    if ($MemberDescriptor -match '^(aad\.|msa\.)') {
        $subjectKind = "user"
    }
    elseif ($MemberDescriptor -match '^vssgp\.') {
        $subjectKind = "group"
    }
    else {
        Write-Warning "Unknown descriptor format, skipping: $MemberDescriptor"
        return $null
    }

    if ($subjectKind -eq "user") {
        $uri = "https://vssps.dev.azure.com/$($Organization)/_apis/graph/users/$($MemberDescriptor)?api-version=7.1-preview.1"
        try {
            $response = Invoke-AzDoApi -Uri $uri -Headers $Headers
            return @{
                DisplayName   = $response.displayName
                MailAddress   = $response.mailAddress
                PrincipalName = $response.principalName
                SubjectKind   = "user"
                Descriptor    = $MemberDescriptor
            }
        }
        catch {
            Write-Warning "Failed to get user details for: $MemberDescriptor"
            return $null
        }
    }
    else {
        $uri = "https://vssps.dev.azure.com/$($Organization)/_apis/graph/groups/$($MemberDescriptor)?api-version=7.1-preview.1"
        try {
            $response = Invoke-AzDoApi -Uri $uri -Headers $Headers
            return @{
                DisplayName   = $response.displayName
                MailAddress   = $response.mailAddress
                PrincipalName = $response.principalName
                SubjectKind   = "group"
                Descriptor    = $MemberDescriptor
            }
        }
        catch {
            Write-Warning "Failed to get group details for: $MemberDescriptor"
            return $null
        }
    }
}

function Get-ProjectAdmins {
    # FIX 5: Deduplicate by mailAddress
    # FIX 6: VisitedGroups default is $null, initialized inside function to avoid shared-instance bug
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$GroupDescriptor,

        [Parameter(Mandatory = $true)]
        [hashtable]$Headers,

        [Parameter(Mandatory = $true)]
        [string]$Organization,

        [Parameter(Mandatory = $false)]
        [System.Collections.ArrayList]$VisitedGroups = $null
    )

    # FIX 6: Initialize here, not in parameter default, to avoid shared instance across calls
    if ($null -eq $VisitedGroups) {
        $VisitedGroups = [System.Collections.ArrayList]::new()
    }

    if ($VisitedGroups -contains $GroupDescriptor) {
        Write-Verbose "Already visited group: $GroupDescriptor, skipping..."
        return @()
    }

    [void]$VisitedGroups.Add($GroupDescriptor)

    $admins = [System.Collections.Generic.List[object]]::new()

    $members = Get-GroupMembers -GroupDescriptor $GroupDescriptor -Headers $Headers -Organization $Organization

    foreach ($member in $members) {
        Write-Verbose "Processing member: $($member.memberDescriptor)"

        $memberDetails = Get-GroupMemberDetails -MemberDescriptor $member.memberDescriptor -Headers $Headers -Organization $Organization

        if ($null -eq $memberDetails) {
            continue
        }

        # Exclude always-ignore users by DisplayName or email username (before @), case-insensitive
        $ignoreMatch = $false
        if ($memberDetails.DisplayName -and ($Global:AlwaysIgnoreUsers -contains $memberDetails.DisplayName)) {
            $ignoreMatch = $true
        } elseif ($memberDetails.MailAddress) {
            $emailUser = $memberDetails.MailAddress.Split('@')[0]
            foreach ($ignore in $Global:AlwaysIgnoreUsers) {
                if ($emailUser -and ($emailUser -ieq $ignore)) {
                    $ignoreMatch = $true
                    break
                }
            }
        }
        if ($ignoreMatch) {
            Write-Verbose "Skipping always-ignored user: $($memberDetails.DisplayName) <$($memberDetails.MailAddress)>"
            continue
        }

        if ($memberDetails.SubjectKind -eq "user") {
            # FIX 5: Skip duplicates
            $alreadyAdded = $admins | Where-Object { $_.MailAddress -eq $memberDetails.MailAddress }
            if (-not $alreadyAdded) {
                Write-Verbose "Found admin user: $($memberDetails.DisplayName) ($($memberDetails.MailAddress))"
                $admins.Add($memberDetails)
            }
            else {
                Write-Verbose "Skipping duplicate: $($memberDetails.DisplayName)"
            }
        }
        elseif ($memberDetails.SubjectKind -eq "group") {
            Write-Verbose "Found nested group: $($memberDetails.DisplayName), recursing..."
            $nestedAdmins = Get-ProjectAdmins -GroupDescriptor $member.memberDescriptor -Headers $Headers -Organization $Organization -VisitedGroups $VisitedGroups
            foreach ($nestedAdmin in $nestedAdmins) {
                # Exclude always-ignore users in nested groups by DisplayName or email username
                $nestedIgnoreMatch = $false
                if ($nestedAdmin.DisplayName -and ($Global:AlwaysIgnoreUsers -contains $nestedAdmin.DisplayName)) {
                    $nestedIgnoreMatch = $true
                } elseif ($nestedAdmin.MailAddress) {
                    $nestedEmailUser = $nestedAdmin.MailAddress.Split('@')[0]
                    foreach ($ignore in $Global:AlwaysIgnoreUsers) {
                        if ($nestedEmailUser -and ($nestedEmailUser -ieq $ignore)) {
                            $nestedIgnoreMatch = $true
                            break
                        }
                    }
                }
                if ($nestedIgnoreMatch) {
                    Write-Verbose "Skipping always-ignored user (nested): $($nestedAdmin.DisplayName) <$($nestedAdmin.MailAddress)>"
                    continue
                }
                $alreadyAdded = $admins | Where-Object { $_.MailAddress -eq $nestedAdmin.MailAddress }
                if (-not $alreadyAdded) {
                    $admins.Add($nestedAdmin)
                }
            }
        }
        else {
            Write-Verbose "Unknown subject kind for member: $($member.memberDescriptor)"
        }
    }

    return $admins.ToArray()
}

#endregion

#region Main Script

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Azure DevOps Project Admin Retrieval" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Validate organization name
if ($Organization -match '^https?://') {
    Write-Error "Please provide just the organization name, not the full URL. Example: 'myorg' from 'https://dev.azure.com/myorg'"
    exit 1
}

# FIX AUTH: Use ${} to avoid PowerShell misreading :$PAT as a drive/scope reference
$base64Auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":${PAT}"))
$headers = @{
    Authorization = "Basic $base64Auth"
    Accept        = "application/json"
}

Write-Host "Organization: $Organization" -ForegroundColor Green

# If no ProjectNames provided, load from JSON file
if (-not $ProjectNames) {
$ProjectsJsonPath = Join-Path $PSScriptRoot '..\export\ExportAndDelete-ProjectsToProcess.json'
    if (-not (Test-Path $ProjectsJsonPath)) {
        Write-Error "Projects JSON file not found: $ProjectsJsonPath"
        exit 1
    }
    $ProjectsJson = Get-Content $ProjectsJsonPath -Raw | ConvertFrom-Json
    if (-not $ProjectsJson.projects) {
        Write-Error "No 'projects' array found in $ProjectsJsonPath"
        exit 1
    }
    $ProjectNames = $ProjectsJson.projects
}
Write-Host "Projects to query: $($ProjectNames -join ', ')" -ForegroundColor Green
Write-Host ""

$results = [System.Collections.Generic.List[object]]::new()

foreach ($projectName in $ProjectNames) {
    Write-Host "----------------------------------------" -ForegroundColor Yellow
    Write-Host "Processing: $projectName" -ForegroundColor Yellow
    Write-Host "----------------------------------------" -ForegroundColor Yellow

    # Step 1: Get project ID
    Write-Verbose "Step 1: Getting project ID"
    $projectInfo = Get-ProjectId -ProjectName $projectName -Headers $headers -Organization $Organization

    if ($null -eq $projectInfo) {
        Write-Warning "Skipping project '$projectName' - could not find project ID"
        continue
    }

    $projectId = $projectInfo.Id
    $projectNameDisplay = $projectInfo.Name

    # Step 2: Get project scope descriptor
    Write-Verbose "Step 2: Getting project scope descriptor"
    try {
        $scopeDescriptor = Get-ProjectScopeDescriptor -ProjectId $projectId -Headers $headers -Organization $Organization
    }
    catch {
        Write-Warning "Skipping project '$projectName' - could not get scope descriptor"
        continue
    }

    # Step 3: Get Project Administrators group
    Write-Verbose "Step 3: Getting Project Administrators group"
    try {
        $adminGroupDescriptor = Get-ProjectAdministratorsGroup -ScopeDescriptor $scopeDescriptor -Headers $headers -Organization $Organization
    }
    catch {
        Write-Warning "Skipping project '$projectName' - could not get Project Administrators group"
        continue
    }

    if ($null -eq $adminGroupDescriptor) {
        Write-Warning "Skipping project '$projectName' - Project Administrators group not found"
        continue
    }

    # Step 4: Get all admin users recursively
    Write-Verbose "Step 4: Getting all Project Administrator users"
    $adminUsers = Get-ProjectAdmins -GroupDescriptor $adminGroupDescriptor -Headers $headers -Organization $Organization

    foreach ($admin in $adminUsers) {
        $results.Add([PSCustomObject]@{
            ProjectName   = $projectNameDisplay
            AdminName     = $admin.DisplayName
            AdminEmail    = $admin.MailAddress
            PrincipalName = $admin.PrincipalName
        })
    }

    Write-Host "Found $($adminUsers.Count) Project Administrator(s)" -ForegroundColor Green
    Write-Host ""
}

#endregion

#region Output Results

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "RESULTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($results.Count -eq 0) {
    Write-Host "No Project Administrators found." -ForegroundColor Yellow
}
else {
    $results | Format-Table -Property ProjectName, AdminName, AdminEmail -AutoSize

    Write-Host ""
    Write-Host "Detailed Output:" -ForegroundColor Cyan
    Write-Host "----------------" -ForegroundColor Cyan

    $results | ForEach-Object {
        Write-Host "Project: $($_.ProjectName)"
        Write-Host "  Admin Name:  $($_.AdminName)"
        Write-Host "  Admin Email: $($_.AdminEmail)"
        Write-Host ""
    }
}

Write-Host "Total Project Administrators found: $($results.Count)" -ForegroundColor Green

if ($OutputJson) {
    $jsonOutput = @{ projects = @() }

    $results | Group-Object -Property ProjectName | ForEach-Object {
        $jsonOutput.projects += @{
            name   = $_.Name
            emails = @($_.Group | ForEach-Object { $_.AdminEmail })
        }
    }

    $jsonOutput | ConvertTo-Json -Depth 10 | Out-File -FilePath $OutputJson -Encoding UTF8
    Write-Host ""
    Write-Host "Results saved to: $OutputJson" -ForegroundColor Green
}

#endregion