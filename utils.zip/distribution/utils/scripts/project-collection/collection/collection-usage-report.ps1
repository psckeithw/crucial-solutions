

# Import both CSVs from Script 1 (now using 'metrics-previous.csv' and 'metrics-current.csv')
$PreviousCsv = Get-ChildItem -Path .\output -Filter 'metrics-previous.csv' | Sort-Object LastWriteTime | Select-Object -Last 1
$CurrentCsv  = Get-ChildItem -Path .\output -Filter 'metrics-current.csv'  | Sort-Object LastWriteTime | Select-Object -Last 1

if (-not $PreviousCsv -or -not $CurrentCsv) {
    Write-Host "Could not find both metrics-previous.csv and metrics-current.csv in the output directory."
    return
}

# Helper to map and add fields
function Convert-MetricsRow {
    param($row, $dateLabel)
    [PSCustomObject]@{
        Project         = $row.ProjectName
        Date            = $dateLabel
        RepoSize        = [double]$row.RepoSize_MB
        Commits         = [int]$row.Commits_6mo
        Builds          = [int]$row.Builds_6mo
        PipelineMinutes = [double]$row.PipelineMinutes
        ArtifactStorage = [double]$row.ArtifactStorage
        ActiveUsers     = [int]$row.ActiveUsers
        BuildSuccessRatePct = [double]$row.'BuildSuccessRate_Pct'
    }
}

# Import and map both datasets
$PreviousData = Import-Csv $PreviousCsv.FullName | ForEach-Object { Convert-MetricsRow $_ 'Previous' }
$CurrentData  = Import-Csv $CurrentCsv.FullName  | ForEach-Object { Convert-MetricsRow $_ 'Current' }

# Combine for analysis
$MetricsData = $PreviousData + $CurrentData


# Get the list of all projects in the data
$Projects = $MetricsData | Select-Object -ExpandProperty Project -Unique

# Calculate percentage change for each metric per project
$Results = foreach ($Project in $Projects) {
	$ProjectData = $MetricsData | Where-Object { $_.Project -eq $Project }
	$Past = $ProjectData | Sort-Object Date | Select-Object -First 1
	$Current = $ProjectData | Sort-Object Date -Descending | Select-Object -First 1
	if ($Past -and $Current) {
		[PSCustomObject]@{
			Project = $Project
			RepoSizeChange = if ($Past.RepoSize -ne 0) { [Math]::Max(0, (($Current.RepoSize - $Past.RepoSize) / $Past.RepoSize) * 100) } else { $null }
			CommitsChange = if ($Past.Commits -ne 0) { [Math]::Max(0, (($Current.Commits - $Past.Commits) / $Past.Commits) * 100) } else { $null }
			BuildsChange = if ($Past.Builds -ne 0) { [Math]::Max(0, (($Current.Builds - $Past.Builds) / $Past.Builds) * 100) } else { $null }
			PipelineMinutesChange = if ($Past.PipelineMinutes -ne 0) { [Math]::Max(0, (($Current.PipelineMinutes - $Past.PipelineMinutes) / $Past.PipelineMinutes) * 100) } else { $null }
			ArtifactStorageChange = if ($Past.ArtifactStorage -ne 0) { [Math]::Max(0, (($Current.ArtifactStorage - $Past.ArtifactStorage) / $Past.ArtifactStorage) * 100) } else { $null }
			ActiveUsersChange = if ($Past.ActiveUsers -ne 0) { [Math]::Max(0, (($Current.ActiveUsers - $Past.ActiveUsers) / $Past.ActiveUsers) * 100) } else { $null }
			BuildSuccessRatePctChange = if ($Past.BuildSuccessRatePct -ne 0) { [Math]::Max(0, (($Current.BuildSuccessRatePct - $Past.BuildSuccessRatePct) / $Past.BuildSuccessRatePct) * 100) } else { $null }
		}
	}
}

# Output results (for charting, export as needed)
$Results | Format-Table
$Results | Export-Csv -Path '.\output\UsageGrowthReport.csv' -NoTypeInformation
