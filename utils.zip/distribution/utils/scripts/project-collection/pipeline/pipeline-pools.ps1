param(
    [string]$OrgUrl = "https://dev.azure.com/aha-bt",
    [string]$PatEnvVar = "AZDO_PAT",
    [bool]  $PromptIfMissing = $true,
    [string]$OutFile = ".\AgentOS_Results_AllAgents.csv"    
)

$ErrorActionPreference = "Stop"

function ConvertFrom-SecureStringPlain {
    param([SecureString]$Secure)
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function Get-PatFromEnv {
    param([string]$Name)
    [Environment]::GetEnvironmentVariable($Name, "User") ??
    [Environment]::GetEnvironmentVariable($Name, "Machine") ??
    [Environment]::GetEnvironmentVariable($Name, "Process")
}

$PAT = Get-PatFromEnv -Name $PatEnvVar
if ([string]::IsNullOrWhiteSpace($PAT)) {
    if ($PromptIfMissing) {
        Write-Host "PAT not found in env var '$PatEnvVar'. Prompting..."
        $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
        $PAT = ConvertFrom-SecureStringPlain $sec
    } else {
        throw "PAT not found in env var '$PatEnvVar'. Set it (e.g., `setx $PatEnvVar '<pat>'`) and re-run."
    }
}

# Auth
$base64Auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
$headers = @{ Authorization = "Basic $base64Auth" }


$results = @()

Write-Host "Fetching agent pools..."
$pools = Invoke-RestMethod -Headers $headers -Uri "$OrgUrl/_apis/distributedtask/pools?api-version=7.1-preview.1"

foreach ($pool in $pools.value) {

    Write-Host "Scanning pool: $($pool.name)"

    $agentsUrl = "$OrgUrl/_apis/distributedtask/pools/$($pool.id)/agents?api-version=7.1-preview.1"
    $agents = Invoke-RestMethod -Headers $headers -Uri $agentsUrl

    foreach ($agent in $agents.value) {

        # --- OS FILTER COMMENTED OUT ---
        # $os = $agent.osDescription
        # $isMatch = $false
        # if ($os -match "Windows.*2019") { $isMatch = $true }
        # if ($os -match "macOS" -or $os -match "Darwin") { $isMatch = $true }
        # if (-not $isMatch) { continue }

        # Always add agent (no filtering)
        $results += [pscustomobject]@{
            PoolName   = $pool.name
            AgentName  = $agent.name
            OS         = $agent.osDescription
            Status     = $agent.status
            Enabled    = $agent.enabled
            Version    = $agent.version
            LastOnline = $agent.lastOnline
        }
    }
}

Write-Host "Exporting → $OutFile"
$results | Export-Csv -NoTypeInformation -Path $OutFile

Write-Host "Done!"
