#Requires -Version 7.0
<#
.SYNOPSIS
    Scans Azure DevOps YAML pipelines for deprecated OS images.
.DESCRIPTION
    Analyzes all pipelines in an organization to identify those using deprecated
    operating system images like windows-2019, macos, etc.
.PARAMETER Org
    Azure DevOps organization name.
.PARAMETER PatEnvVar
    Environment variable name containing the PAT.
.PARAMETER OutputFolder
    Folder for CSV output.
.PARAMETER PromptIfMissing
    Prompt for PAT if not found in environment variable.
.EXAMPLE
    .\scan-pipeline-yaml.ps1
.EXAMPLE
    .\scan-pipeline-yaml.ps1 -Org "myorg" -OutputFolder "./results"
#>
[CmdletBinding()]
param(
    [Parameter()]
    [string]$Org = 'aha-bt',

    [Parameter()]
    [string]$PatEnvVar = 'AZDO_PAT',

    [Parameter()]
    [string]$OutputFolder = './output',

    [Parameter()]
    [switch]$PromptIfMissing
)

# Load configuration
$configPath = Join-Path $PSScriptRoot '..\config\defaults.json'
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
    if (-not $PSBoundParameters.ContainsKey('Org')) { $Org = $config.organization }
    if (-not $PSBoundParameters.ContainsKey('PatEnvVar')) { $PatEnvVar = $config.patEnvVar }
}

# Import module (robust path resolution)
$modulePath = Join-Path $PSScriptRoot '..\..\..\modules\AzDO-Helpers.psm1'
if (-not (Get-Module -ListAvailable -Name AzDO-Helpers)) {
    Import-Module $modulePath -Force
}

# Get authentication (use testPat from config if present, otherwise env var or prompt)
if ($config.testPat -and $config.testPat -ne "REVOKED_OR_FAKE_PAT_VALUE") {
    $pat = $config.testPat
} else {
    $pat = Get-AdoPat -EnvVarName $PatEnvVar -PromptIfMissing:$PromptIfMissing
}
$headers = Get-AdoHeaders -Pat $pat

# Get projects
Write-Host "Fetching projects..." -ForegroundColor Cyan
$projects = Get-AdoProjects -Org $Org -Headers $headers
$results = @()

Write-Host "Scanning $($projects.Count) projects..." -ForegroundColor Cyan
$counter = 0

foreach ($project in $projects) {
    $counter++
    $percent = [math]::Round(($counter / $projects.Count) * 100)
    Write-Progress -Activity "Scanning Projects" -Status "$counter of $($projects.Count) - $($project.name)" -PercentComplete $percent

    try {
        $pipelines = Get-AdoPipelines -Org $Org -Project $project.name -Headers $headers

        foreach ($pipe in $pipelines) {
            # Get YAML config metadata
            try {
                $configUrl = "_apis/pipelines/$($pipe.id)"
                $pipeConfig = Invoke-AdoApi -Org $Org -Project $project.name -Method Get -ApiPath $configUrl -Headers $headers
            }
            catch {
                # Classic pipeline - skip
                continue
            }

            $yamlPath = $pipeConfig.configuration.path
            $repoId = $pipeConfig.configuration.repository.id

            if (-not $yamlPath) {
                continue
            }

            # Fetch raw YAML
            $yamlUrl = "_apis/git/repositories/$repoId/items?path=$yamlPath&includeContent=true"
            try {
                $yamlResponse = Invoke-AdoApi -Org $Org -Project $project.id -Method Get -ApiPath $yamlUrl -Headers $headers
            }
            catch {
                continue
            }

            # Extract content
            if ($yamlResponse -is [string]) {
                $yaml = $yamlResponse
            }
            elseif ($yamlResponse.content) {
                $yaml = $yamlResponse.content
            }
            else {
                continue
            }

            # Check for deprecated OS
            $matchedPattern = $null
            foreach ($pattern in $config.patterns.deprecatedOs) {
                if ($yaml -match $pattern) {
                    $matchedPattern = $pattern
                    break
                }
            }

            if ($matchedPattern) {
                $results += [PSCustomObject]@{
                    ProjectName = $project.name
                    PipelineName = $pipe.name
                    YamlPath = $yamlPath
                    MatchedPattern = $matchedPattern
                    YamlUrl = "https://dev.azure.com/$Org/$($project.name)/_git/$($pipeConfig.configuration.repository.name)?path=$yamlPath"
                }
            }
        }
    }
    catch {
        Write-Host "Error scanning $($project.name): $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Progress -Activity "Scanning Projects" -Completed

# Export results
if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outputPath = Join-Path $OutputFolder "PipelineYamlScan-$timestamp.csv"
$results | Export-Csv -Path $outputPath -NoTypeInformation

Write-Host "Scan complete. Found $($results.Count) pipelines with deprecated OS." -ForegroundColor Green
Write-Host "Results: $outputPath" -ForegroundColor Cyan

if ($results.Count -gt 0) {
    $results | Format-Table -AutoSize
}
