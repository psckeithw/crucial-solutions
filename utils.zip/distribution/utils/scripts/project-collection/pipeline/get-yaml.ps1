# ================================
# Azure DevOps – YAML Discovery Script
# ================================

param(
    [string]$OrgName = "aha-bt",
    [string]$PatEnvVar = "AZDO_PAT",
    [bool]$PromptIfMissing = $true,
    [string]$OutFile = "YamlScanResults.csv"
)

function ConvertFrom-SecureStringPlain {
    param([Security.SecureString]$Secure)
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Get-PatFromEnv {
    param([string]$Name)
    [Environment]::GetEnvironmentVariable($Name, "User") ??
    [Environment]::GetEnvironmentVariable($Name, "Machine") ??
    [Environment]::GetEnvironmentVariable($Name, "Process")
}

$Pat = Get-PatFromEnv -Name $PatEnvVar
if ([string]::IsNullOrWhiteSpace($Pat)) {
    if ($PromptIfMissing) {
        Write-Host "PAT not found in env var '$PatEnvVar'. Prompting..."
        $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
        $Pat = ConvertFrom-SecureStringPlain $sec
    } else {
        throw "PAT not found in env var '$PatEnvVar'. Set it (e.g., `setx $PatEnvVar '<pat>'`) and re-run."
    }
}

# --- Headers ---
$base64Auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$Pat"))
$headers = @{ Authorization = "Basic $base64Auth" }

Write-Host "Querying projects..."

# --- Get all projects ---
$projectsUrl = "https://dev.azure.com/$OrgName/_apis/projects?api-version=7.1-preview.1"
$projects    = Invoke-RestMethod -Uri $projectsUrl -Headers $headers -Method Get

$results = @()

foreach ($project in $projects.value) {

    Write-Host "Scanning project: $($project.name)"

    # --- Get repos for this project ---
    $reposUrl = "https://dev.azure.com/$OrgName/$($project.id)/_apis/git/repositories?api-version=7.1-preview.1"
    $repos    = Invoke-RestMethod -Uri $reposUrl -Headers $headers -Method Get

    foreach ($repo in $repos.value) {
        Write-Host "  Repo: $($repo.name)"

        # --- Root listing for YAML files ---
        $itemsUrl = "https://dev.azure.com/$OrgName/$($project.id)/_apis/git/repositories/$($repo.id)/items?recursionLevel=Full&api-version=7.1-preview.1"

        try {
            $items = Invoke-RestMethod -Uri $itemsUrl -Headers $headers -Method Get
        }
        catch {
            Write-Host "    Failed to list repo items. Skipping."
            continue
        }

        # --- Filter YAML items ---
        $yamlFiles = $items.value | Where-Object { $_.path -match "\.ya?ml$" }

        foreach ($file in $yamlFiles) {

            $yamlPath = $file.path
            Write-Host "    Found YAML: $yamlPath"

            # --- URL to raw YAML ---
            $yamlUrl = "https://dev.azure.com/$OrgName/$($project.id)/_apis/git/repositories/$($repo.id)/items?path=$yamlPath&api-version=7.1-preview.1&includeContent=true"

            try {
                $yamlRaw = Invoke-RestMethod -Uri $yamlUrl -Headers $headers -Method Get
                $yamlContent = $yamlRaw.content
            }
            catch {
                $yamlContent = "[ERROR retrieving YAML]"
            }

            # --- Save record ---
            $results += [pscustomobject]@{
                ProjectName = $project.name
                RepoName    = $repo.name
                FilePath    = $yamlPath
                RawYaml     = $yamlContent
            }
        }
    }
}

# --- Export CSV ---
$results | Export-Csv -Path $OutFile -NoTypeInformation -Encoding utf8
Write-Host "Results exported to $OutFile"