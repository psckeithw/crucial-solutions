#Requires -Version 7.0
<#
.SYNOPSIS
    Exports Azure DevOps project work items and optionally deletes the project.

.DESCRIPTION
    This production-grade script exports full work item data from Azure DevOps projects
    to CSV/Excel files, with optional project deletion. It implements safe defaults:
    - Export-only by default (no deletion)
    - Deletion requires BOTH -ConfirmDelete AND -Force switches
    - Supports checkpoint/resume via state files
    - Implements retry with jitter for 429/5xx responses
    - Bounded concurrency for parallel project processing

    Output structure:
    Each project's folder in <OutputRoot> contains:
    - <OutputRoot>\<ProjectName>\<ProjectName>-workitems.csv
    - <OutputRoot>\<ProjectName>\<ProjectName>-workitems.xlsx (if -UseImportExcel)
    - <OutputRoot>\<ProjectName>\<ProjectName>-metadata.json
    - <OutputRoot>\<ProjectName>\<ProjectName>-workitem_fields.json
    - <OutputRoot>\<ProjectName>\<ProjectName>-pipeline_pool_usage.json
    - <OutputRoot>\<ProjectName>\<ProjectName>-manifest.json
    - <OutputRoot>\<ProjectName>\<ProjectName>-state.json
    - <OutputRoot>\<ProjectName>\<ProjectName>-log.txt
    
    Run summary files are written to <OutputRoot> root.

.PARAMETER OrganizationUrl
    Azure DevOps organization URL. Default: https://aha-bt.visualstudio.com/

.PARAMETER ProjectsToProcess
    Semicolon-separated list of exact project names to process.
    Required unless -ConfigFile is provided.
    Example: "ProjA;Proj B;ProjC"

.PARAMETER ConfigFile
    JSON config file containing project list.
    If provided, projects are loaded from this file instead of -ProjectsToProcess.
    Example: "ExportAndDelete-ProjectsToProcess.json"

.PARAMETER OutputRoot
    Root folder for all output. Default: C:\code\Niche Sandbox\dev\Niche Sandbox\test-output

.PARAMETER PatPrompt
    Prompt securely for PAT if not found in environment variable.

.PARAMETER Pat
    Explicit secure string PAT input.

.PARAMETER Concurrency
    Maximum parallel projects to process. Default: 4. Range: 1-32

.PARAMETER ApiVersion
    Azure DevOps API version. Default: 7.1

.PARAMETER ExportOnly
    Skip delete regardless of other switches. Default behavior is export-only.

.PARAMETER ConfirmDelete
    Deletion gate 1 of 2. Must be combined with -Force.

.PARAMETER Force
    Deletion gate 2 of 2. Must be combined with -ConfirmDelete.

.PARAMETER UseImportExcel
    Export to XLSX format if ImportExcel module is available.

.PARAMETER LogPath
    Path for log file. Default: <OutputRoot>\_logs\ExportAndDelete-AdoProjects-<timestamp>.log

.PARAMETER TimeoutSeconds
    HTTP request timeout in seconds. Default: 120

.PARAMETER MaxRetries
    Maximum retry attempts for transient errors. Default: 6

.EXAMPLE
    # Export only (safe default)
    pwsh -File "utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1" `
        -ProjectsToProcess "ProjA;Proj B;ProjC" -PatPrompt

.EXAMPLE
    # Export + delete with dual confirmation
    pwsh -File "utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1" `
        -ProjectsToProcess "ProjA;Proj B;ProjC" -PatPrompt -ConfirmDelete -Force

.EXAMPLE
    # Resume after partial failure (continues from last checkpoint)
    pwsh -File "utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1" `
        -ProjectsToProcess "ProjA;Proj B;ProjC" -PatPrompt -ExportOnly

.NOTES
    Required PAT scopes:
    - Work item read (vso.work)
    - Project and team read (vso.project)
    - Project deletion (vso.project_delete) - only if using delete functionality

    Safe defaults enforced:
    - Export-only unless BOTH -ConfirmDelete AND -Force are supplied
    - PAT never logged or persisted to any file
    - Any PAT values seen in local plain text are treated as temporary and should be considered revoked
    - PAT values are intended for in-memory/session-only use, except explicit local debug scenarios
    - Pipeline pool identities are read-only (no pool deletion)
#>

[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]
param(
    [Parameter()]
    [string]$OrganizationUrl = 'https://aha-bt.visualstudio.com/',

    [Parameter()]
    [string]$ProjectsToProcess,

    [Parameter()]
    [string]$ConfigFile,

    [Parameter()]
    [string]$OutputRoot = 'C:\code\Niche Sandbox\dev\Niche Sandbox\test-output',

    [Parameter()]
    [switch]$PatPrompt,

    [Parameter()]
    [SecureString]$Pat,

    [Parameter()]
    [ValidateRange(1, 32)]
    [int]$Concurrency = 4,

    [Parameter()]
    [string]$ApiVersion = '7.1',

    [Parameter()]
    [switch]$ExportOnly,

    [Parameter()]
    [switch]$ConfirmDelete,

    [Parameter()]
    [switch]$Force,

    [Parameter()]
    [switch]$UseImportExcel,

    [Parameter()]
    [string]$LogPath,

    [Parameter()]
    [int]$TimeoutSeconds = 120,

    [Parameter()]
    [int]$MaxRetries = 6
)

# Resolve projects from config file or parameter
if ([string]::IsNullOrWhiteSpace($ProjectsToProcess) -and [string]::IsNullOrWhiteSpace($ConfigFile)) {
    Write-Error "Either -ProjectsToProcess or -ConfigFile must be provided."
    exit 1
}

# Load from config file if provided
if ($ConfigFile) {
    $configPath = $ConfigFile
    # If relative path, make it relative to script location
    if (-not [System.IO.Path]::IsPathRooted($configPath)) {
        $configPath = Join-Path $PSScriptRoot $ConfigFile
    }
    
    if (Test-Path -LiteralPath $configPath) {
        try {
            $config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
            if ($config.projects -and $config.projects.Count -gt 0) {
                $ProjectsToProcess = $config.projects -join ';'
                Write-Host "Loaded $($config.projects.Count) projects from config file: $configPath" -ForegroundColor Cyan
            }
            else {
                Write-Error "Config file has no projects defined: $configPath"
                exit 1
            }
        }
        catch {
            Write-Error "Failed to parse config file: $configPath - $($_.Exception.Message)"
            exit 1
        }
    }
    else {
        Write-Error "Config file not found: $configPath"
        exit 1
    }
}

if ([string]::IsNullOrWhiteSpace($ProjectsToProcess)) {
    Write-Error "No projects to process. Provide -ProjectsToProcess or a -ConfigFile with projects."
    exit 1
}

# Import AzDO Helpers module
$modulePath = Join-Path $PSScriptRoot '..\..\..\modules\AzDO-Helpers.psm1'
if (Test-Path -LiteralPath $modulePath) {
    Import-Module -Name $modulePath -Force
}
else {
    Write-Error "AzDO-Helpers.psm1 not found at: $modulePath"
    exit 1
}

#region Configuration
$ErrorActionPreference = 'Stop'
$script:RunId = [guid]::NewGuid().ToString('N').Substring(0, 8)
$script:ScriptStartUtc = [DateTime]::UtcNow
# Resolve organization name from OrganizationUrl when provided
$script:OrgName = 'aha-bt'
if (-not [string]::IsNullOrWhiteSpace($OrganizationUrl)) {
    try {
        $orgUri = [uri]$OrganizationUrl
        if ($orgUri.Host -eq 'dev.azure.com') {
            $segments = $orgUri.AbsolutePath.Trim('/') -split '/'
            if ($segments.Count -ge 1 -and -not [string]::IsNullOrWhiteSpace($segments[0])) {
                $script:OrgName = $segments[0]
            }
        }
        elseif ($orgUri.Host -match '\.visualstudio\.com$') {
            $script:OrgName = ($orgUri.Host -split '\.')[0]
        }
    }
    catch {
        # Keep default org name if URL parsing fails
    }
}
$script:Errors = [System.Collections.Generic.List[object]]::new()

# Store the UseImportExcel flag for use in runspace
$script:UseImportExcel = $UseImportExcel

# Determine effective delete mode
$script:EnableDelete = (-not $ExportOnly) -and $ConfirmDelete -and $Force

# Setup output directories
$script:OutputRoot = $OutputRoot

# Ensure root output directory exists
if (-not (Test-Path -LiteralPath $OutputRoot)) {
    New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
}

# Log path will be per-project, written in each project folder

#endregion

#region Helper Functions

function Write-Log {
    param(
        [Parameter(Mandatory)]
        [string]$Message,

        [ValidateSet('INFO', 'WARN', 'ERROR')]
        [string]$Level = 'INFO',

        [string]$ProjectName = $null
    )

    $timestamp = (Get-Date).ToUniversalTime().ToString('o')
    $projectPrefix = if ($ProjectName) { "[$ProjectName]" } else { '' }
    $logEntry = "[$timestamp] [$Level] [$script:RunId] $projectPrefix $Message"

    # Write to log file if path is set and not empty
    if ($LogPath -and -not [string]::IsNullOrWhiteSpace($LogPath)) {
        try {
            Add-Content -LiteralPath $LogPath -Value $logEntry -Encoding UTF8
        } catch {}
    }
    # Always write to console
    $color = switch ($Level) {
        'ERROR' { 'Red' }
        'WARN' { 'Yellow' }
        default { 'White' }
    }
    Write-Host $logEntry -ForegroundColor $color
}

function Write-StructuredError {
    param(
        [string]$ProjectName,
        [string]$Operation,
        [int]$HttpStatus = $null,
        [string]$Message,
        [int]$RetryCount = 0,
        [bool]$IsTransient = $false
    )

    $errorObj = @{
        TimeUtc = [DateTime]::UtcNow.ToString('o')
        ProjectName = $ProjectName
        Operation = $Operation
        HttpStatus = $HttpStatus
        Message = $Message
        RetryCount = $RetryCount
        IsTransient = $IsTransient
    }

    $script:Errors.Add([PSCustomObject]$errorObj)

    # Mask potential PAT in error message
    $maskedMessage = $Message -replace '[a-zA-Z0-9]{20,}', '***MASKED***'
    Write-Log -Message $maskedMessage -Level ERROR -ProjectName $ProjectName
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,

        [string]$ProjectName = $null,

        [string]$OperationName = 'operation',

        [int]$MaxRetries = $script:MaxRetries,

        [int]$TimeoutSeconds = $script:TimeoutSeconds
    )

    $attempt = 0
    $lastException = $null

    while ($attempt -le $MaxRetries) {
        try {
            $attempt++
            if ($attempt -gt 1) {
                Write-Log -Message "Retry attempt $attempt of $MaxRetries for $OperationName" -Level WARN -ProjectName $ProjectName
            }

            $result = & $ScriptBlock
            return $result
        }
        catch {
            $lastException = $_
            $statusCode = $null
            $errorMessage = $_.Exception.Message

            # Extract HTTP status if available
            if ($_.Exception.Response) {
                $statusCode = [int]$_.Exception.Response.StatusCode.Value__

                try {
                    $responseBody = $null
                    if ($_.Exception.Response -is [System.Net.Http.HttpResponseMessage]) {
                        $responseBody = $_.Exception.Response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                    }
                    else {
                        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                        $responseBody = $reader.ReadToEnd()
                    }

                    if (-not [string]::IsNullOrWhiteSpace($responseBody)) {
                        $errorMessage = "$errorMessage`n$responseBody"
                    }
                }
                catch {
                    # Keep base exception message if response body cannot be extracted
                }
            }

            $isTransient = $false
            # 404 is not transient - project may be archived/deleted
            if ($statusCode -eq 404) {
                $isTransient = $false
            }
            elseif ($statusCode -eq 429 -or ($statusCode -ge 500 -and $statusCode -lt 600)) {
                $isTransient = $true
            }

            # Check for Retry-After header
            $retryAfter = 0
            if ($_.Exception.Response.Headers['Retry-After']) {
                [int]::TryParse($_.Exception.Response.Headers['Retry-After'], [ref]$retryAfter)
            }

            if ($isTransient -and $attempt -le $MaxRetries) {
                # Calculate backoff with jitter
                $baseDelay = [Math]::Min(60, [Math]::Pow(2, $attempt))
                $jitter = Get-Random -Minimum 0 -Maximum 1.5
                $delay = if ($retryAfter -gt 0) { $retryAfter } else { [int]($baseDelay + $jitter) }

                Write-Log -Message "Transient error (HTTP $statusCode). Waiting $delay seconds before retry." -Level WARN -ProjectName $ProjectName
                Start-Sleep -Seconds $delay
            }
            else {
                Write-StructuredError -ProjectName $ProjectName -Operation $OperationName -HttpStatus $statusCode -Message $errorMessage -RetryCount ($attempt - 1) -IsTransient $isTransient
                throw $errorMessage
            }
        }
    }

    throw "Max retries exceeded for $OperationName. Last error: $($lastException.Message)"
}

function Invoke-AdoRest {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [ValidateSet('Get', 'Post', 'Patch', 'Delete', 'Put')]
        [string]$Method,

        [Parameter(Mandatory)]
        [string]$ApiPath,

        [string]$Project = $null,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [object]$Body = $null,

        [string]$ApiVersion = $script:ApiVersion,

        [int]$TimeoutSeconds = $script:TimeoutSeconds,

        [string]$OperationName = 'ADO API call',

        [string]$ProjectName = $null
    )

    # Build base URL
    $baseUrl = if ($Project) {
        $encodedProject = [uri]::EscapeDataString($Project)
        "https://dev.azure.com/$Org/$encodedProject"
    }
    else {
        "https://dev.azure.com/$Org"
    }

    # Build full URL with query string
    $separator = if ($ApiPath -match '\?') { '&' } else { '?' }
    $url = "$baseUrl/$ApiPath$separator`api-version=$ApiVersion"

    # Prepare request parameters
    $requestParams = @{
        Method = $Method
        Uri = $url
        Headers = $Headers
        TimeoutSec = $TimeoutSeconds
    }

    if ($Body) {
        $requestParams['ContentType'] = 'application/json'
        $requestParams['Body'] = $Body | ConvertTo-Json -Depth 10
    }

    $wrapped = {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-RestMethod @requestParams
    }

    return Invoke-WithRetry -ScriptBlock $wrapped -OperationName $OperationName -ProjectName $ProjectName -MaxRetries $script:MaxRetries -TimeoutSeconds $TimeoutSeconds
}

function Split-IntoChunks {
    param(
        [Parameter(Mandatory)]
        [object[]]$InputArray,

        [Parameter(Mandatory)]
        [int]$ChunkSize
    )

    $chunks = @()
    for ($i = 0; $i -lt $InputArray.Count; $i += $ChunkSize) {
        $chunks += ,@($InputArray[$i..[Math]::Min($i + $ChunkSize - 1, $InputArray.Count - 1)])
    }
    return $chunks
}

function ConvertTo-Hashtable {
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [object]$InputObject
    )
    
    if ($null -eq $InputObject) { return $null }
    
    if ($InputObject -is [System.Collections.IDictionary]) {
        $hash = @{}
        foreach ($key in $InputObject.Keys) {
            $hash[$key] = $InputObject[$key]
        }
        return $hash
    }
    
    $hash = @{}
    foreach ($property in $InputObject.PSObject.Properties) {
        $hash[$property.Name] = $property.Value
    }
    return $hash
}

function Get-FileHashSafe {
    param(
        [Parameter(Mandatory)]
        [string]$Path
    )

    if (Test-Path -LiteralPath $Path) {
        return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    }
    return $null
}

function Write-ProjectState {
    param(
        [Parameter(Mandatory)]
        [string]$ProjectName,

        [Parameter(Mandatory)]
        [string]$Status,

        [string]$LastPhase = $null,

        [string]$ErrorMessage = $null,

        [string]$DeleteOperationId = $null
    )

    $projectFolder = Join-Path $script:OutputRoot $ProjectName
    if (-not (Test-Path -LiteralPath $projectFolder)) {
        New-Item -ItemType Directory -Path $projectFolder -Force | Out-Null
    }
    $stateFile = Join-Path $projectFolder "$ProjectName-state.json"
    $state = @{
        ProjectName = $ProjectName
        Status = $Status
        LastPhase = $LastPhase
        UpdatedUtc = [DateTime]::UtcNow.ToString('o')
        Error = $ErrorMessage
        DeleteOperationId = $DeleteOperationId
    }
    if (Test-Path -LiteralPath $stateFile) {
        $existing = Get-Content -LiteralPath $stateFile | ConvertFrom-Json
        $state.ProjectId = $existing.ProjectId
    }
    $state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $stateFile -Encoding UTF8
}

function Write-ProjectManifest {
    param(
        [Parameter(Mandatory)]
        [hashtable]$ManifestData
    )

    $projectFolder = Join-Path $script:OutputRoot $ManifestData.ProjectName
    if (-not (Test-Path -LiteralPath $projectFolder)) {
        New-Item -ItemType Directory -Path $projectFolder -Force | Out-Null
    }
    $manifestFile = Join-Path $projectFolder "$($ManifestData.ProjectName)-manifest.json"
    $ManifestData | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $manifestFile -Encoding UTF8
}

function Get-ProjectState {
    param(
        [Parameter(Mandatory)]
        [string]$ProjectName
    )

    $projectFolder = Join-Path $script:OutputRoot $ProjectName
    $stateFile = Join-Path $projectFolder "$ProjectName-state.json"
    if (Test-Path -LiteralPath $stateFile) {
        return Get-Content -LiteralPath $stateFile | ConvertFrom-Json
    }
    return $null
}

function Get-AdoProjectByName {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$ProjectName,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    # Resolve directly first (works with PATs that cannot list all projects)
    $encodedProjectName = [uri]::EscapeDataString($ProjectName)
    try {
        return Invoke-AdoRest -Org $Org -Method Get -ApiPath "_apis/projects/$encodedProjectName" -Headers $Headers -OperationName "Get project by name" -ProjectName $ProjectName
    }
    catch {
        # Fallback to org-wide listing for compatibility if direct lookup fails for non-auth reasons
        if ($_.Exception.Message -match '401|403') {
            throw
        }

        $result = Invoke-AdoRest -Org $Org -Method Get -ApiPath "_apis/projects" -Headers $Headers -OperationName "Get projects list" -ProjectName $ProjectName

        # Find exact match (case-insensitive)
        $project = $result.value | Where-Object { $_.name -eq $ProjectName } | Select-Object -First 1

        if (-not $project) {
            throw "Project '$ProjectName' not found in organization"
        }

        return $project
    }
}

function Test-AdoAuthentication {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    try {
        $null = Invoke-AdoRest -Org $Org -Method Get -ApiPath '_apis/connectionData' -Headers $Headers -OperationName 'Auth preflight'
        return $true
    }
    catch {
        $message = $_.Exception.Message
        if ($message -match 'Access Denied: The Personal Access Token used has expired') {
            throw "Azure DevOps authentication failed: the AZDO_PAT token is expired. Generate a new PAT and update AZDO_PAT in your current session before running this script."
        }
        if ($message -match '401|Unauthorized') {
            throw "Azure DevOps authentication failed (401 Unauthorized). Verify AZDO_PAT is current, has required scopes, and is loaded in the current pwsh process."
        }
        throw
    }
}

function Get-WorkItemIdsViaWiql {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$ProjectName,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $wiql = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = '$ProjectName'"
    $encodedProjectName = [uri]::EscapeDataString($ProjectName)
    $url = "https://dev.azure.com/$Org/$encodedProjectName/_apis/wit/wiql?api-version=$($script:ApiVersion)"

    $requestParams = @{
        Method = 'Post'
        Uri = $url
        Headers = $Headers
        ContentType = 'application/json'
        Body = (@{ query = $wiql } | ConvertTo-Json -Depth 5)
    }

    $wrapped = {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-RestMethod @requestParams
    }

    $result = Invoke-WithRetry -ScriptBlock $wrapped -OperationName "WIQL query for work item IDs" -ProjectName $ProjectName -MaxRetries $script:MaxRetries -TimeoutSeconds $script:TimeoutSeconds
    return $result.workItems
}

function Get-WorkItemDetails {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$ProjectName,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [Parameter(Mandatory)]
        [int[]]$WorkItemIds
    )

    $idsString = "ids=" + ($WorkItemIds -join ',')
    $fields = '*'

    $result = Invoke-AdoRest -Org $Org -Method Get -ApiPath "_apis/wit/workitems?$idsString&`$fields=$fields" -Project $ProjectName -Headers $Headers -OperationName "Get work item details" -ProjectName $ProjectName

    return $result.value
}

function Get-ProjectPools {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$ProjectName,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $pools = @()

    try {
        # Get build definitions to find queue pools
        $buildDefs = Invoke-AdoRest -Org $Org -Method Get -ApiPath '_apis/build/definitions' -Project $ProjectName -Headers $Headers -OperationName "Get build definitions" -ProjectName $ProjectName

        $seenPools = @{}

        foreach ($def in $buildDefs.value) {
            if ($def.queue -and $def.queue.poolId) {
                $poolId = $def.queue.poolId
                if (-not $seenPools.ContainsKey($poolId)) {
                    $seenPools[$poolId] = $true

                    try {
                        # Get pool details
                        $poolInfo = Invoke-AdoRest -Org $Org -Method Get -ApiPath "_distributedtask/pools/$poolId" -Headers $Headers -OperationName "Get pool info" -ProjectName $ProjectName
                        $pools += @{
                            PoolId = $poolId
                            PoolName = $poolInfo.name
                            IsHosted = $poolInfo.isHosted
                            QueueId = $def.queue.id
                        }
                    }
                    catch {
                        # Pool might not be accessible, add basic info
                        $pools += @{
                            PoolId = $poolId
                            PoolName = "Pool $poolId"
                            IsHosted = $null
                            QueueId = $def.queue.id
                        }
                    }
                }
            }
        }
    }
    catch {
        Write-Log -Message "Failed to get pipeline pools: $($_.Exception.Message)" -Level WARN -ProjectName $ProjectName
    }

    return $pools
}

function Export-WorkItemsToCsv {
    param(
        [Parameter(Mandatory)]
        [object[]]$WorkItems,

        [Parameter(Mandatory)]
        [string]$OutputPath
    )

    # Core columns in desired order
    $coreColumns = @('Id', 'Title', 'WorkItemType', 'State', 'AreaPath', 'IterationPath', 'AssignedTo', 'CreatedDate', 'ChangedDate')

    # Discover all fields
    $allFields = @{}
    foreach ($wi in $WorkItems) {
        foreach ($field in $wi.fields.PSObject.Properties) {
            $allFields[$field.Name] = $true
        }
    }

    # Build column list: core first, then others alphabetically
    $remainingFields = $allFields.Keys | Where-Object { $_ -notin $coreColumns } | Sort-Object
    $allColumns = $coreColumns + $remainingFields

    # Normalize and build rows
    $rows = @()
    foreach ($wi in $WorkItems) {
        $row = @{}
        foreach ($col in $allColumns) {
            $value = $null
            if ($wi.fields.PSObject.Properties[$col]) {
                $value = $wi.fields.$col

                # Flatten complex objects
                if ($value -is [System.Collections.IDictionary] -or $value.PSObject.Properties['displayName']) {
                    $value = $value.displayName
                }
            }

            # Handle dates
            if ($value -is [DateTime]) {
                $value = $value.ToString('o')
            }

            $row[$col] = $value
        }
        $rows += [PSCustomObject]$row
    }

    $rows | Export-Csv -LiteralPath $OutputPath -NoTypeInformation -Encoding UTF8
}

function Queue-ProjectDelete {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$ProjectId,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $result = Invoke-AdoRest -Org $Org -Method Delete -ApiPath "_apis/projects/$ProjectId" -Headers $Headers -OperationName "Queue project delete" -ProjectName $ProjectId

    # Operation ID is returned in Location header or response
    return $result
}

function Wait-ForDeleteOperation {
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [object]$Operation,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [string]$ProjectName = $null,

        [int]$MaxWaitMinutes = 20
    )

    $startTime = Get-Date
    $timeout = $startTime.AddMinutes($MaxWaitMinutes)

    while ((Get-Date) -lt $timeout) {
        $status = $Operation.status

        if ($status -eq 'succeeded') {
            return @{ Success = $true; Status = 'Succeeded' }
        }
        elseif ($status -eq 'failed' -or $status -eq 'cancelled') {
            $message = if ($Operation.statusMessage) { $Operation.statusMessage } else { "Delete $status" }
            return @{ Success = $false; Status = $status; Message = $message }
        }

        # Check for operation URL to poll
        if ($Operation.url) {
            Start-Sleep -Seconds 5
            try {
                $Operation = Invoke-AdoRest -Org $Org -Method Get -ApiPath $Operation.url -Headers $Headers -OperationName "Poll delete operation" -ProjectName $ProjectName
            }
            catch {
                # Operation might have completed
                return @{ Success = $true; Status = 'Succeeded' }
            }
        }
        else {
            Start-Sleep -Seconds 10
        }
    }

    return @{ Success = $false; Status = 'TimedOut'; Message = "Delete operation timed out after $MaxWaitMinutes minutes" }
}

#endregion

#region Main Script

try {
    Write-Log -Message "=== Starting ExportAndDelete-AdoProjects ==="
    Write-Log -Message "Run ID: $script:RunId"
    Write-Log -Message "Organization: $script:OrgName"
    Write-Log -Message "Projects: $ProjectsToProcess"
    Write-Log -Message "Delete enabled: $script:EnableDelete"
    Write-Log -Message "Output root: $OutputRoot"


    # Resolve PAT with proper precedence and in-memory handling
    $plainPat = $null

    # Priority 1: Explicit -Pat parameter (SecureString)
    if ($Pat) {
        $plainPat = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR(
            [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Pat)
        )
    }
    # Priority 2: Prompt if -PatPrompt is specified
    elseif ($PatPrompt) {
        Write-Host "Prompting for PAT..." -ForegroundColor Yellow
        $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
        $plainPat = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR(
            [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        )
    }
    # Priority 3: Environment variable (AZDO_PAT)
    else {
        # Use Process scope first so current pwsh session value is preferred
        $envPat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
        if ([string]::IsNullOrWhiteSpace($envPat)) {
            $envPat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'User')
        }
        if ([string]::IsNullOrWhiteSpace($envPat)) {
            $envPat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Machine')
        }

        if (-not [string]::IsNullOrWhiteSpace($envPat)) {
            $plainPat = $envPat.Trim().Trim('"')
        }
    }

    # Debug: Masked echo of PAT for troubleshooting
    if (-not [string]::IsNullOrWhiteSpace($plainPat)) {
        $maskedPat = if ($plainPat.Length -ge 10) {
            $plainPat.Substring(0,6) + '...<redacted>...' + $plainPat.Substring($plainPat.Length-4)
        } else {
            '<too short to display>'
        }
        Write-Host "[DEBUG] PAT resolved at runtime: $maskedPat" -ForegroundColor Yellow
    } else {
        Write-Host "[DEBUG] PAT is empty after resolution" -ForegroundColor Red
    }

    if ([string]::IsNullOrWhiteSpace($plainPat)) {
        throw "PAT is required. Use -Pat, -PatPrompt, or set AZDO_PAT environment variable."
    }

    # Create auth header (never logged)
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$plainPat"))
    $headers = @{
        Authorization = "Basic $auth"
        'Content-Type' = 'application/json'
    }

    # Validate authentication early for clearer failures
    Test-AdoAuthentication -Org $script:OrgName -Headers $headers | Out-Null

    # Clear PAT from memory
    $plainPat = $null

    # Parse project list
    $projectList = $ProjectsToProcess -split ';' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
    $projectList = $projectList | Select-Object -Unique

    Write-Log -Message "Parsed $($projectList.Count) unique projects to process"

    # Resolve projects from ADO
    $resolvedProjects = @()
    $failedProjects = @()

    foreach ($projName in $projectList) {
        try {
            Write-Log -Message "Resolving project: $projName" -ProjectName $projName

            $existingState = Get-ProjectState -ProjectName $projName

            $projectFolder = Join-Path $OutputRoot $projName
            $workitemsCsvPath = Join-Path $projectFolder "$projName-workitems.csv"

            if ($existingState -and $existingState.Status -eq 'Deleted') {
                Write-Log -Message "Project already deleted, skipping" -ProjectName $projName
                continue
            }

            if ($existingState -and $existingState.Status -eq 'Exported' -and (Test-Path $workitemsCsvPath)) {
                Write-Log -Message "Project already exported, checking if resume needed" -ProjectName $projName
            }

            $adoProject = Get-AdoProjectByName -Org $script:OrgName -ProjectName $projName -Headers $headers
            $resolvedProjects += @{
                Name = $adoProject.name
                Id = $adoProject.id
                ExistingState = $existingState
            }

            Write-Log -Message "Resolved project: $($adoProject.name) (ID: $($adoProject.id))" -ProjectName $projName
        }
        catch {
            Write-Log -Message "Failed to resolve project '$projName': $($_.Exception.Message)" -Level ERROR -ProjectName $projName
            Write-ProjectState -ProjectName $projName -Status 'Failed' -LastPhase 'Resolve' -ErrorMessage $_.Exception.Message
            $failedProjects += $projName
        }
    }

    Write-Log -Message "Resolved $($resolvedProjects.Count) projects, $($failedProjects.Count) failed to resolve"

    # Process projects with bounded concurrency
    $runSummary = @()
    # Note: Using runspace pool for concurrency instead of Semaphore

    $jobs = foreach ($proj in $resolvedProjects) {
        @{
            Name = $proj.Name
            Id = $proj.Id
            ExistingState = $proj.ExistingState
        }
    }

    $processScript = {
        param($proj, $serializedHeaders, $OrgName, $OutputRootPath, $EnableDeleteFlag, $UseImportExcelFlag, $ApiVersionValue, $TimeoutSecondsValue, $MaxRetriesValue, $LogsFolderPath)

        # Deserialize headers from JSON
        $headers = $serializedHeaders | ConvertFrom-Json | ConvertTo-Hashtable
        # Set per-project log path
        $logPath = Join-Path $projectFolder "$($proj.Name)-log.txt"
        $global:LogPath = $logPath
        $result = @{
            ProjectName = $proj.Name
            ProjectId = $proj.Id
            Status = 'Pending'
            ExistingWorkItemCount = 0
            ExportedWorkItemCount = 0
            Difference = 0
            DeleteRequested = $false
            DeleteStatus = 'NotRequested'
            DeleteOperationId = $null
            PipelinePoolCount = 0
            PipelinePoolIdentities = ''
            ErrorCount = 0
            StartedUtc = [DateTime]::UtcNow.ToString('o')
            CompletedUtc = $null
            Errors = @()
        }
        try {
            Write-Log -Message "Starting export phase" -ProjectName $proj.Name
            $existingState = $proj.ExistingState
            $projectFolder = Join-Path $OutputRootPath $proj.Name
            if (-not (Test-Path -LiteralPath $projectFolder)) {
                New-Item -ItemType Directory -Path $projectFolder -Force | Out-Null
            }
            $csvPath = Join-Path $projectFolder "$($proj.Name)-workitems.csv"
            $xlsxPath = Join-Path $projectFolder "$($proj.Name)-workitems.xlsx"
            $metadataPath = Join-Path $projectFolder "$($proj.Name)-metadata.json"
            $fieldsPath = Join-Path $projectFolder "$($proj.Name)-workitem_fields.json"
            $poolsPath = Join-Path $projectFolder "$($proj.Name)-pipeline_pool_usage.json"
            $logPath = Join-Path $projectFolder "$($proj.Name)-log.txt"
            if ($existingState -and $existingState.Status -eq 'Exported' -and (Test-Path $csvPath)) {
                Write-Log -Message "Resuming: project already exported, gathering type info for summary" -ProjectName $proj.Name
                $result.Status = 'Exported'
                $workItemTypesInProject = @()
                try {
                    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                    $encodedProject = [uri]::EscapeDataString($proj.Name)
                    $typeUrl = "https://dev.azure.com/$OrgName/$encodedProject/_apis/wit/workitemtypes?api-version=$ApiVersionValue"
                    $typeResult = Invoke-RestMethod -Uri $typeUrl -Headers $headers -TimeoutSec $TimeoutSecondsValue
                    $workItemTypesInProject = $typeResult.value | ForEach-Object { $_.name }
                }
                catch {
                    if ($_.Exception.Message -match '404') {
                        Write-Log -Message "Work item types not available (project may be archived)" -Level WARN -ProjectName $proj.Name
                    } else {
                        Write-Log -Message "Could not get work item types: $($_.Exception.Message)" -Level WARN -ProjectName $proj.Name
                    }
                }
                $exportedWorkItemTypes = @()
                if (Test-Path -LiteralPath $csvPath) {
                    try {
                        $csvData = Import-Csv -LiteralPath $csvPath
                        $exportedWorkItemTypes = @($csvData | Select-Object -ExpandProperty WorkItemType -Unique)
                    } catch {}
                }
                $notExportedTypes = @()
                if ($workItemTypesInProject.Count -gt 0 -and $exportedWorkItemTypes.Count -gt 0) {
                    $notExportedTypes = $workItemTypesInProject | Where-Object { $_ -notin $exportedWorkItemTypes }
                } elseif ($workItemTypesInProject.Count -gt 0 -and $exportedWorkItemTypes.Count -eq 0) {
                    $notExportedTypes = $workItemTypesInProject
                }
                $result.WorkItemTypesInProject = ($workItemTypesInProject -join ';')
                $result.ExportedWorkItemTypes = ($exportedWorkItemTypes -join ';')
                $result.NotExportedTypes = ($notExportedTypes -join ';')
                $fields = @{
                    workItemTypesInProject = $workItemTypesInProject
                    exportedWorkItemTypes = $exportedWorkItemTypes
                    notExportedTypes = $notExportedTypes
                    note = "Work item type info gathered during resume"
                }
                $fields | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $fieldsPath -Encoding UTF8
            } else {
                Write-ProjectState -ProjectName $proj.Name -Status 'Exporting' -LastPhase 'Export'
                Write-Log -Message "Querying work item IDs" -ProjectName $proj.Name
                $wiIds = Get-WorkItemIdsViaWiql -Org $OrgName -ProjectName $proj.Name -Headers $headers
                $result.ExistingWorkItemCount = $wiIds.Count
                Write-Log -Message "Found $($wiIds.Count) work items" -ProjectName $proj.Name
                if ($wiIds.Count -gt 0) {
                    $chunkSize = 200
                    $allWorkItems = @()
                    $idChunks = Split-IntoChunks -InputArray $wiIds.id -ChunkSize $chunkSize
                    foreach ($chunk in $idChunks) {
                        Write-Log -Message "Fetching chunk of $($chunk.Count) work items" -ProjectName $proj.Name
                        $details = Get-WorkItemDetails -Org $OrgName -ProjectName $proj.Name -Headers $headers -WorkItemIds $chunk
                        $allWorkItems += $details
                    }
                    Export-WorkItemsToCsv -WorkItems $allWorkItems -OutputPath $csvPath
                    $result.ExportedWorkItemCount = $allWorkItems.Count
                    Write-Log -Message "Exported $($allWorkItems.Count) work items to CSV" -ProjectName $proj.Name
                    if ($UseImportExcelFlag) {
                        try {
                            Import-Module ImportExcel -ErrorAction Stop
                            $allWorkItems | Export-Excel -Path $xlsxPath -TableName 'WorkItems' -AutoSize -OpenExcel:$false
                            Write-Log -Message "Exported to XLSX" -ProjectName $proj.Name
                        } catch {
                            Write-Log -Message "XLSX export failed (module may not be available): $($_.Exception.Message)" -Level WARN -ProjectName $proj.Name
                        }
                    }
                }
                $metadata = @{
                    projectName = $proj.Name
                    projectId = $proj.Id
                    exportedUtc = [DateTime]::UtcNow.ToString('o')
                    workItemCount = $result.ExportedWorkItemCount
                }
                $metadata | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $metadataPath -Encoding UTF8
                $workItemTypesInProject = @()
                try {
                    $typeResult = Invoke-AdoRest -Org $OrgName -Method Get -ApiPath "_apis/wit/workitemtypes" -Headers $headers -OperationName "Get work item types" -ProjectName $proj.Name
                    $workItemTypesInProject = $typeResult.value | ForEach-Object { $_.name }
                } catch {
                    Write-Log -Message "Could not get work item types: $($_.Exception.Message)" -Level WARN -ProjectName $proj.Name
                }
                $exportedWorkItemTypes = @()
                if (Test-Path -LiteralPath $csvPath) {
                    try {
                        $csvData = Import-Csv -LiteralPath $csvPath
                        $exportedWorkItemTypes = @($csvData | Select-Object -ExpandProperty WorkItemType -Unique)
                    } catch {}
                }
                $notExportedTypes = @()
                if ($workItemTypesInProject.Count -gt 0 -and $exportedWorkItemTypes.Count -gt 0) {
                    $notExportedTypes = $workItemTypesInProject | Where-Object { $_ -notin $exportedWorkItemTypes }
                } elseif ($workItemTypesInProject.Count -gt 0 -and $exportedWorkItemTypes.Count -eq 0) {
                    $notExportedTypes = $workItemTypesInProject
                }
                $fields = @{
                    discovered = @($wiIds | ForEach-Object { $_.PSObject.Properties.Name } | Select-Object -Unique)
                    exported = $result.ExportedWorkItemCount
                    workItemTypesInProject = $workItemTypesInProject
                    exportedWorkItemTypes = $exportedWorkItemTypes
                    notExportedTypes = $notExportedTypes
                    notExportedNote = "Test Plans, Test Suites, and shared parameters require special API calls and may not be included in standard work item exports"
                }
                $fields | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $fieldsPath -Encoding UTF8
                $result.WorkItemTypesInProject = ($workItemTypesInProject -join ';')
                $result.ExportedWorkItemTypes = ($exportedWorkItemTypes -join ';')
                $result.NotExportedTypes = ($notExportedTypes -join ';')
                Write-Log -Message "Gathering pipeline pool information" -ProjectName $proj.Name
                $pools = Get-ProjectPools -Org $OrgName -ProjectName $proj.Name -Headers $headers
                $result.PipelinePoolCount = $pools.Count
                $result.PipelinePoolIdentities = ($pools | ForEach-Object { "$($_.PoolName)($($_.PoolId))" }) -join ';'
                $pools | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $poolsPath -Encoding UTF8
                $result.Status = 'Exported'
                Write-ProjectState -ProjectName $proj.Name -Status 'Exported' -LastPhase 'Export'
            }

            # Difference
            $result.Difference = $result.ExportedWorkItemCount - $result.ExistingWorkItemCount

            # Conditional deletion
            if ($EnableDeleteFlag) {
                Write-Log -Message "Delete enabled, requesting project deletion" -ProjectName $proj.Name

                if ($PSCmdlet.ShouldProcess($proj.Name, 'Delete Azure DevOps project')) {
                    $result.DeleteRequested = $true
                    Write-ProjectState -ProjectName $proj.Name -Status 'DeleteQueued' -LastPhase 'Delete'

                    # Queue delete
                    $deleteResult = Queue-ProjectDelete -Org $OrgName -ProjectId $proj.Id -Headers $headers

                    # Handle operation
                    $operationId = $null
                    if ($deleteResult -is [hashtable] -and $deleteResult.operationId) {
                        $operationId = $deleteResult.operationId
                    }
                    elseif ($deleteResult.PSObject.Properties['operationId']) {
                        $operationId = $deleteResult.operationId
                    }

                    $result.DeleteOperationId = $operationId

                    # Poll for completion
                    if ($operationId) {
                        Write-Log -Message "Delete operation queued: $operationId" -ProjectName $proj.Name
                        $pollResult = Wait-ForDeleteOperation -Org $OrgName -Operation $deleteResult -Headers $headers -ProjectName $proj.Name

                        $result.DeleteStatus = $pollResult.Status
                        if ($pollResult.Success) {
                            $result.Status = 'Deleted'
                            Write-ProjectState -ProjectName $proj.Name -Status 'Deleted' -LastPhase 'Delete' -DeleteOperationId $operationId
                            Write-Log -Message "Project deleted successfully" -ProjectName $proj.Name
                        }
                        else {
                            $result.Status = 'Failed'
                            Write-ProjectState -ProjectName $proj.Name -Status 'Failed' -LastPhase 'Delete' -ErrorMessage $pollResult.Message -DeleteOperationId $operationId
                            Write-Log -Message "Delete failed: $($pollResult.Message)" -Level ERROR -ProjectName $proj.Name
                        }
                    }
                    else {
                        # Synchronous delete (immediate)
                        $result.DeleteStatus = 'Succeeded'
                        $result.Status = 'Deleted'
                        Write-ProjectState -ProjectName $proj.Name -Status 'Deleted' -LastPhase 'Delete'
                        Write-Log -Message "Project deleted (synchronous)" -ProjectName $proj.Name
                    }
                }
                else {
                    $result.DeleteStatus = 'Declined'
                    Write-Log -Message "Delete declined by ShouldProcess" -ProjectName $proj.Name
                }
            }
            else {
                $result.DeleteStatus = 'NotRequested'
            }
        }
        catch {
            $result.Status = 'Failed'
            $result.Errors += $_.Exception.Message
            Write-Log -Message "Processing failed: $($_.Exception.Message)" -Level ERROR -ProjectName $proj.Name
            Write-ProjectState -ProjectName $proj.Name -Status 'Failed' -LastPhase 'Process' -ErrorMessage $_.Exception.Message
        }

        $result.CompletedUtc = [DateTime]::UtcNow.ToString('o')
        return $result
    }

    # Run project processing in current session scope for reliable function/state access
    $runResults = @()

    $jobsData = @()
    foreach ($proj in $jobs) {
        $jobsData += $proj
    }

    # Serialize headers to JSON for safe cross-runspace transfer
    $serializedHeaders = $headers | ConvertTo-Json -Compress

    foreach ($proj in $jobsData) {
        $result = & $processScript -proj $proj -serializedHeaders $serializedHeaders -OrgName $script:OrgName -OutputRootPath $script:OutputRoot -EnableDeleteFlag $script:EnableDelete -UseImportExcelFlag $script:UseImportExcel -ApiVersionValue $script:ApiVersion -TimeoutSecondsValue $script:TimeoutSeconds -MaxRetriesValue $script:MaxRetries -LogsFolderPath $script:LogsFolder
        $runResults += $result
    }

    # Build run summary
    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'

    foreach ($r in $runResults) {
        # Build concise error message, masking sensitive data
        $errorMessage = ''
        if ($r.Errors.Count -gt 0) {
            $errorMessage = $r.Errors[0]
            # Mask potential PAT-like strings (alphanumeric strings 20+ chars)
            $errorMessage = $errorMessage -replace '[a-zA-Z0-9]{20,}', '***MASKED***'
            # Truncate to reasonable length for summary visibility
            if ($errorMessage.Length -gt 200) {
                $errorMessage = $errorMessage.Substring(0, 197) + '...'
            }
        }

        $runSummary += [PSCustomObject]@{
            ProjectName = $r.ProjectName
            ProjectId = $r.ProjectId
            Status = $r.Status
            ExistingWorkItemCount = $r.ExistingWorkItemCount
            ExportedWorkItemCount = $r.ExportedWorkItemCount
            Difference = $r.Difference
            DeleteRequested = $r.DeleteRequested
            DeleteStatus = $r.DeleteStatus
            DeleteOperationId = $r.DeleteOperationId
            PipelinePoolCount = $r.PipelinePoolCount
            PipelinePoolIdentities = $r.PipelinePoolIdentities
            WorkItemTypesInProject = if ($r.WorkItemTypesInProject) { $r.WorkItemTypesInProject } else { '' }
            ExportedWorkItemTypes = if ($r.ExportedWorkItemTypes) { $r.ExportedWorkItemTypes } else { '' }
            NotExportedTypes = if ($r.NotExportedTypes) { $r.NotExportedTypes } else { '' }
            ErrorCount = $r.Errors.Count
            ErrorMessage = $errorMessage
            StartedUtc = $r.StartedUtc
            CompletedUtc = $r.CompletedUtc
        }

        # Write per-project manifest
        $projectFolder = Join-Path $OutputRoot $r.ProjectName
        $csvPath = Join-Path $projectFolder "$($r.ProjectName)-workitems.csv"
        $xlsxPath = Join-Path $projectFolder "$($r.ProjectName)-workitems.xlsx"
        $manifest = @{
            RunId = $script:RunId
            ProjectName = $r.ProjectName
            ProjectId = $r.ProjectId
            OrganizationUrl = $OrganizationUrl
            ApiVersion = $script:ApiVersion
            StartedUtc = $r.StartedUtc
            CompletedUtc = $r.CompletedUtc
            DurationSeconds = if ($r.StartedUtc -and $r.CompletedUtc) {
                ([DateTime]$r.CompletedUtc - [DateTime]$r.StartedUtc).TotalSeconds
            } else { 0 }
            ExistingWorkItemCount = $r.ExistingWorkItemCount
            ExportedWorkItemCount = $r.ExportedWorkItemCount
            ColumnsExported = @('Id', 'Title', 'WorkItemType', 'State', 'AreaPath', 'IterationPath', 'AssignedTo', 'CreatedDate', 'ChangedDate')
            CoreColumnsPresent = $true
            CsvPath = $csvPath
            CsvSha256 = Get-FileHashSafe -Path $csvPath
            XlsxPath = if (Test-Path $xlsxPath) { $xlsxPath } else { $null }
            XlsxSha256 = Get-FileHashSafe -Path $xlsxPath
            WorkItemTypesInProject = if ($r.WorkItemTypesInProject) { $r.WorkItemTypesInProject -split ';' } else { @() }
            ExportedWorkItemTypes = if ($r.ExportedWorkItemTypes) { $r.ExportedWorkItemTypes -split ';' } else { @() }
            NotExportedTypes = if ($r.NotExportedTypes) { $r.NotExportedTypes -split ';' } else { @() }
            DeleteRequested = $r.DeleteRequested
            DeleteOperationId = $r.DeleteOperationId
            DeleteStatus = $r.DeleteStatus
            DeleteStatusMessage = $null
            PipelinePoolIdentities = @($r.PipelinePoolIdentities -split ';' | Where-Object { $_ })
            Errors = $r.Errors
        }
        Write-ProjectManifest -ManifestData $manifest
    }

    # Write run summary
    $summaryCsvPath = Join-Path $OutputRoot "ExportAndDelete-AdoProjects-Summary-$timestamp.csv"
    $summaryJsonPath = Join-Path $OutputRoot "ExportAndDelete-AdoProjects-Summary-$timestamp.json"

    $runSummary | Export-Csv -LiteralPath $summaryCsvPath -NoTypeInformation -Encoding UTF8
    $runSummary | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $summaryJsonPath -Encoding UTF8

    $succeededCount = ($runSummary | Where-Object { $_.Status -eq 'Exported' -or $_.Status -eq 'Deleted' }).Count
    $failedCount = ($runSummary | Where-Object { $_.Status -eq 'Failed' }).Count + $failedProjects.Count

    $totalProjects = $runSummary.Count + $failedProjects.Count
    Write-Log -Message "=== Run Summary ==="
    Write-Log -Message "Total projects: $totalProjects"
    Write-Log -Message "Succeeded: $succeededCount"
    Write-Log -Message "Failed: $failedCount"
    Write-Log -Message "Summary CSV: $summaryCsvPath"
    Write-Log -Message "Summary JSON: $summaryJsonPath"

    # Determine exit code
    if ($failedCount -gt 0) {
        Write-Log -Message "Script completed with errors: $failedCount projects failed" -Level ERROR
        exit 1
    }

    Write-Log -Message "=== Script completed successfully ==="
    exit 0
}
catch {
    Write-Log -Message "Fatal error: $($_.Exception.Message)" -Level ERROR
    exit 1
}
finally {
    # Cleanup
    $headers = $null
    $plainPat = $null
    $global:LogPath = $null
}

#endregion
