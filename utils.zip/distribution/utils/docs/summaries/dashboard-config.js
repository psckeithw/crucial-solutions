'use strict';

const DASHBOARD_CONFIG = {
  organization: "aha-bt",
  basePath: "C:\\code\\Niche Sandbox\\dev\\Niche Sandbox\\utils",
  scripts: [
    // ===== COLLECTION SCRIPTS =====
    {
      id: "collection-audit",
      label: "Collection Audit",
      group: "Collection",
      file: "scripts\\project-collection\\collection\\get-collection-audit.ps1",
      desc: "Comprehensive activity audit across repos, pipelines, work items, PRs, and releases for all projects.",
      params: [
        { name: "Days", flag: "-Days", type: "number", default: "90", label: "Days threshold", required: false }
      ]
    },
    {
      id: "dormant-projects",
      label: "Dormant Projects",
      group: "Collection",
      file: "scripts\\project-collection\\collection\\get-dormant-projects.ps1",
      desc: "Identifies projects with no commit or pipeline activity for a specified number of days.",
      params: [
        { name: "Days", flag: "-Days", type: "number", default: "90", label: "Days of inactivity", required: false }
      ]
    },
    {
      id: "collection-metrics",
      label: "Collection Metrics",
      group: "Collection",
      file: "scripts\\project-collection\\collection\\ado-collection-metrics.ps1",
      desc: "Collects usage metrics across the Azure DevOps collection.",
      params: []
    },
    {
      id: "collection-usage-report",
      label: "Collection Usage Report",
      group: "Collection",
      file: "scripts\\project-collection\\collection\\collection-usage-report.ps1",
      desc: "Generates a usage report for the collection.",
      params: []
    },
    {
      id: "git-repo-user-list",
      label: "Git Repo User List",
      group: "Collection",
      file: "scripts\\project-collection\\collection\\git-repo-user-list.ps1",
      desc: "Lists all users who have committed to git repos across the collection.",
      params: []
    },
    {
      id: "get-project-admins",
      label: "Get Project Admins",
      group: "Collection",
      file: "scripts\\project-collection\\collection\\get-project-admins.ps1",
      desc: "Retrieves admin users and groups for specified projects.",
      params: [
        { name: "Projects", flag: "-Projects", type: "string", default: "", label: "Project names (semicolon-separated)", required: true }
      ]
    },
    // ===== PIPELINE SCRIPTS =====
    {
      id: "scan-pipeline-yaml",
      label: "Scan Pipeline YAML",
      group: "Pipeline",
      file: "scripts\\project-collection\\pipeline\\scan-pipeline-yaml.ps1",
      desc: "Finds pipelines using deprecated OS images such as windows-2019 or macos-latest.",
      params: []
    },
    {
      id: "pipeline-pools",
      label: "Pipeline Pools",
      group: "Pipeline",
      file: "scripts\\project-collection\\pipeline\\pipeline-pools.ps1",
      desc: "Lists all agent pools and their configuration across the organization.",
      params: []
    },
    {
      id: "get-yaml",
      label: "Get Pipeline YAML",
      group: "Pipeline",
      file: "scripts\\project-collection\\pipeline\\get-yaml.ps1",
      desc: "Downloads YAML pipeline definitions for specified projects.",
      params: [
        { name: "Projects", flag: "-Projects", type: "string", default: "", label: "Project names (semicolon-separated)", required: true }
      ]
    },
    // ===== EXPORT/DELETE SCRIPTS =====
    {
      id: "export-delete-projects",
      label: "Export & Delete Projects",
      group: "Admin",
      file: "scripts\\project-collection\\export\\export-and-delete-ado-projects.ps1",
      desc: "Exports work items to CSV/Excel and optionally deletes projects. Requires both -ConfirmDelete AND -Force to delete.",
      params: [
        { name: "OrganizationUrl", flag: "-OrganizationUrl", type: "string", default: "https://aha-bt.visualstudio.com/", label: "Organization URL", required: false },
        { name: "ProjectsToProcess", flag: "-ProjectsToProcess", type: "string", default: "", label: "Projects (semicolon-separated)", required: false },
        { name: "ConfigFile", flag: "-ConfigFile", type: "string", default: "", label: "Config JSON file", required: false },
        { name: "OutputRoot", flag: "-OutputRoot", type: "string", default: "test-output", label: "Output folder", required: false },
        { name: "PatPrompt", flag: "-PatPrompt", type: "switch", default: "true", label: "Prompt for PAT", required: false },
        { name: "Concurrency", flag: "-Concurrency", type: "number", default: "4", label: "Concurrency", required: false },
        { name: "ExportOnly", flag: "-ExportOnly", type: "switch", default: "true", label: "Export only (no delete)", required: false },
        { name: "ConfirmDelete", flag: "-ConfirmDelete", type: "switch", default: "false", label: "Confirm Delete", required: false },
        { name: "Force", flag: "-Force", type: "switch", default: "false", label: "Force Delete", required: false }
      ]
    },
    // ===== REPORTING SCRIPTS =====
    {
      id: "snapshot-get",
      label: "Get Metrics Snapshot",
      group: "Reporting",
      file: "scripts\\project-collection\\reporting\\snapshot-get.ps1",
      desc: "Captures a snapshot of Azure DevOps metrics (projects, pipelines, work items).",
      params: [
        { name: "OutputDir", flag: "-OutputDir", type: "string", default: "output", label: "Output directory", required: false }
      ]
    },
    {
      id: "snapshot-compare",
      label: "Compare Snapshots",
      group: "Reporting",
      file: "scripts\\project-collection\\reporting\\snapshot-compare.ps1",
      desc: "Compares two metric snapshots and shows growth/decline.",
      params: [
        { name: "Before", flag: "-Before", type: "string", default: "", label: "Before snapshot file", required: true },
        { name: "After", flag: "-After", type: "string", default: "", label: "After snapshot file", required: true }
      ]
    },
    {
      id: "azure-devops-metrics",
      label: "Azure DevOps Metrics",
      group: "Reporting",
      file: "scripts\\project-collection\\reporting\\azure-devops-metrics-snapshot.ps1",
      desc: "Collects detailed Azure DevOps metrics including history.",
      params: [
        { name: "OutputDir", flag: "-OutputDir", type: "string", default: "output", label: "Output directory", required: false }
      ]
    },
    // ===== EMAIL SCRIPTS (Non-ADO - Uses Outlook) =====
    /*
    {
      id: "scan-email",
      label: "Scan Email (Outlook)",
      group: "Email",
      file: "email\\scan-email.ps1",
      desc: "Scans Outlook inbox for emails containing 'smartsheet', extracts names and budget codes. Outputs to Downloads.",
      params: []
    },
    {
      id: "match-emails",
      label: "Match Emails",
      group: "Email",
      file: "email\\match-emails.ps1",
      desc: "Matches email addresses from two CSV files based on name matching.",
      params: [
        { name: "SourceCsv", flag: "-SourceCsv", type: "string", default: "", label: "Source CSV path", required: true },
        { name: "MatchCsv", flag: "-MatchCsv", type: "string", default: "", label: "Match CSV path", required: true },
        { name: "OutputCsv", flag: "-OutputCsv", type: "string", default: "output/matched.csv", label: "Output CSV path", required: false }
      ]
    },
    {
      id: "sort-by-name",
      label: "Sort by Name",
      group: "Email",
      file: "email\\sort-by-name.ps1",
      desc: "Sorts a CSV file by name column.",
      params: [
        { name: "InputCsv", flag: "-InputCsv", type: "string", default: "", label: "Input CSV path", required: true },
        { name: "OutputCsv", flag: "-OutputCsv", type: "string", default: "output/sorted.csv", label: "Output CSV path", required: false }
      ]
    },
    */
  ]
};
