# Azure DevOps Utilities - Architecture Documentation

## Overview

This codebase provides a set of PowerShell utilities for analyzing and managing Azure DevOps organizations. The architecture follows modular design principles to maximize reusability and maintainability.

This is the **Distribution Package** - a subset of the full development repository containing only the files needed for the Unified Platform Operations dashboard and core scripts.

## Current Effort Scope

The primary focus is the **Export-and-Delete** effort:
- Main script: `utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1`
- Default mode: export-only (safe, no deletion)
- Deletion requires explicit dual confirmation (`-ConfirmDelete` and `-Force`)

## Package Structure

This distribution package contains **37 files** organized as follows:

```
Niche Sandbox/ (distribution root)
├── README.md                      # Primary operational guide
├── tree.flat.distributed.json                # Project structure reference
├── MANIFEST.md                   # Package manifest & sync instructions
├── sync-from-source.ps1          # Sync updated files from dev repository
├── push-to-main.ps1              # Push only distribution files to main
├── create-pr.ps1                 # Create PR for distribution updates
│
├── utils/
│   ├── modules/
│   │   └── AzDO-Helpers.psm1   # Reusable ADO API functions
│   │
│   ├── scripts/
│   │   └── project-collection/
│   │       ├── config/
│   │       │   └── defaults.json          # Centralized configuration
│   │       ├── collection/                # Collection metrics scripts
│   │       │   ├── get-collection-audit.ps1
│   │       │   ├── get-dormant-projects.ps1
│   │       │   ├── ado-collection-metrics.ps1
│   │       │   ├── collection-usage-report.ps1
│   │       │   ├── git-repo-user-list.ps1
│   │       │   └── get-project-admins.ps1
│   │       ├── export/                   # Export/delete scripts
│   │       │   └── export-and-delete-ado-projects.ps1
│   │       ├── pipeline/                 # Pipeline analysis scripts
│   │       │   ├── scan-pipeline-yaml.ps1
│   │       │   ├── pipeline-pools.ps1
│   │       │   └── get-yaml.ps1
│   │       └── reporting/               # Reporting scripts
│   │           ├── snapshot-get.ps1
│   │           ├── snapshot-compare.ps1
│   │           └── azure-devops-metrics-snapshot.ps1
│   │
│   └── docs/
│       ├── ARCHITECTURE.md              # This file
│       ├── SCRIPT-REFERENCE.md          # Detailed API documentation
│       ├── SCRIPT-PATTERNS.md           # Common patterns and best practices
│       └── summaries/                   # Dashboard HTML files
│           ├── Dashboard.html            # Main dashboard
│           ├── dashboard-config.js       # Dashboard configuration
│           ├── dashboard2.html           # Alternative dashboard
│           ├── ExportAndDelete-Summary.html
│           ├── Collection-Summary.html
│           ├── Pipeline-Summary.html
│           ├── WorkItems-Summary.html
│           ├── Reporting-Summary.html
│           └── agent-comparison-dashboard.html
```

## What's NOT in This Package

The following files from the full development repository are intentionally excluded:

- `utils/email/` - Email processing scripts
- `utils/templates/` - Script and module templates
- `utils/tests/` - Test scripts and harness
- `utils/main.ps1` - Unified CLI entry point
- `utils/generate-project-tree-json.ps1` - Tree generation script
- `projects_details.json`, `projects.json` - Project metadata (generated at runtime)
- `process-templates/` - Work item processing templates
- `output/`, `test-output/` - Runtime output directories

## Dev-to-Main Split Process

This distribution package implements a split deployment strategy:

### 1. Source of Truth (dev branch)
- Contains ALL files (full repository)
- Development happens here
- Includes tests, templates, email scripts, etc.

### 2. Distribution Package (main branch)
- Contains ONLY the 37 files listed in this package
- Used for production/operations
- Synced from dev via `sync-from-source.ps1`

### Sync Workflow

```
dev branch → sync-from-source.ps1 → distribution package → push to main
```

To sync updates from the full dev repository:

```powershell
cd distribution
.\sync-from-source.ps1
```

This script reads the source path automatically and copies only the files that are part of this distribution package.

### Publishing to Main

**Option 1 - Direct Push:**
```powershell
cd distribution
.\push-to-main.ps1 -Message "Release v1.1"
```

**Option 2 - Create PR:**
```powershell
cd distribution
.\create-pr.ps1 -PRTitle "Update distribution"
```

## Module Design

### AzDO-Helpers.psm1

The core module containing reusable Azure DevOps operations. This module follows the Single Responsibility Principle - each function does one thing well.

#### Authentication Layer
- `Get-AdoPat` - Retrieves PAT from environment variables (User > Machine > Process)
- `Get-AdoHeaders` - Creates authorization headers for REST calls

#### API Layer
- `Invoke-AdoApi` - Generic REST method wrapper with error handling
- `Get-AdoProjects` - Fetches all projects
- `Get-AdoPipelines` - Lists pipelines for a project
- `Get-AdoPipelineRuns` - Gets recent pipeline executions
- `Get-AdoRepos` - Lists git repositories
- `Get-AdoRepoCommits` - Gets recent commits
- `Get-AdoWorkItems` - Queries work items via WIQL
- `Get-AdoPullRequests` - Lists pull requests
- `Get-AdoReleases` - Lists releases

#### Helper Functions
- `Get-AdoProjectActivity` - Aggregates all activity types into single timestamp
- `Write-AdoProgress` - Consistent progress bar output
- `Export-ToCsv` - Standardized CSV export with timestamps

### Configuration (defaults.json)

Centralized configuration that avoids hardcoded values:

```json
{
  "organization": "aha-bt",
  "patEnvVar": "AZDO_PAT",
  "defaults": {
    "daysDormant": 90,
    "topRepos": 3,
    "topPipelines": 5
  },
  "patterns": {
    "deprecatedOs": ["windows-2019", "macos", ...]
  }
}
```

## Script Architecture

### Common Pattern

All scripts follow a consistent structure:

1. **Parameter Block** - All configurable options exposed as parameters
2. **Config Loading** - Load from defaults.json, allow parameter override
3. **Module Import** - Import AzDO-Helpers
4. **Authentication** - Get PAT and headers
5. **Main Logic** - Iterate, process, collect results
6. **Export** - Write CSV with timestamp

### Collection Scripts

| Script | Purpose |
|--------|---------|
| `get-collection-audit.ps1` | Comprehensive activity analysis across all projects |
| `get-dormant-projects.ps1` | Identify inactive projects |
| `ado-collection-metrics.ps1` | Collect usage metrics |
| `collection-usage-report.ps1` | Generate usage reports |
| `git-repo-user-list.ps1` | List all git contributors |
| `get-project-admins.ps1` | Retrieve project administrators |

### Pipeline Scripts

| Script | Purpose |
|--------|---------|
| `scan-pipeline-yaml.ps1` | Find deprecated OS images |
| `pipeline-pools.ps1` | List agent pools |
| `get-yaml.ps1` | Download pipeline definitions |

### Export Scripts

| Script | Purpose |
|--------|---------|
| `export-and-delete-ado-projects.ps1` | Export work items and optionally delete projects |

### Reporting Scripts

| Script | Purpose |
|--------|---------|
| `snapshot-get.ps1` | Capture metrics snapshot |
| `snapshot-compare.ps1` | Compare two snapshots |
| `azure-devops-metrics-snapshot.ps1` | Detailed metrics collection |

## Design Patterns

### 1. Parameter Precedence
Parameters override config file, which overrides hardcoded defaults:
```
Command Line > defaults.json > Module Defaults
```

### 2. Idempotent Error Handling
Each API call wrapped in try/catch to continue on individual failures.

### 3. Progress Reporting
Consistent Write-Progress usage across all scripts.

### 4. Output Standardization
- Timestamps in filenames: `basename-YYYYMMDD-HHmmss.csv`
- Consistent column naming
- Auto-open after export

## Environment Setup

Before using the dashboard, set the environment variable:

```powershell
$env:NICHE_SANDBOX_ROOT = "C:\path\to\Niche Sandbox"
```

The dashboard and scripts use this to resolve absolute paths for running PowerShell commands.

## Dependencies

- PowerShell 7.0+
- Azure DevOps Personal Access Token (PAT)
- PAT stored in environment variable (default: `AZDO_PAT`)

## Security Considerations

- PATs stored in environment variables, never in code
- Basic auth header construction uses base64 encoding
- TLS 1.2 enforced for API calls

## See Also

- `MANIFEST.md` - Package manifest with sync and publish instructions
- `SCRIPT-REFERENCE.md` - Detailed API documentation
- `SCRIPT-PATTERNS.md` - Common patterns and best practices
