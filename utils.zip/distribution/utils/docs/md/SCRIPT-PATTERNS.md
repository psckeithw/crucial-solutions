# Script Patterns and Conventions

## Overview

This document defines the naming and layout conventions for PowerShell scripts in this project. These standards ensure consistency, maintainability, and ease of use across all scripts.

---

## Folder Structure

```
Niche Sandbox/
├── utils/
│   ├── config/
│   │   └── defaults.json             # Centralized configuration
│   ├── modules/                      # Shared PowerShell modules
│   │   ├── AzDO-Helpers.psm1
│   │   └── EmailHelpers.psm1
│   ├── scripts/                      # Standalone utility scripts
│   │   ├── email-match/              # Email matching scripts
│   │   ├── project-collection/       # ADO project scripts
│   │   │   ├── collection/           # Collection metrics
│   │   │   ├── config/               # Configuration files
│   │   │   ├── export/               # Export/delete scripts
│   │   │   ├── pipeline/             # Pipeline analysis
│   │   │   └── reporting/            # Reporting scripts
│   │   └── templates/                # Script and module templates
│   └── docs/
│       └── (documentation)
├── test-output/                       # Runtime output (git-ignored)
├── analysis.md
├── TODO.md
└── .gitignore
```

---

## Naming Conventions

### Scripts

| Type | Pattern | Example |
|------|---------|---------|
| Orchestrator | `Invoke-{ToolName}.ps1` | `Invoke-EmailTool.ps1` |
| Stage/Action | `Verb-Noun.ps1` | `Match-BySignature.ps1`, `get-collection-audit.ps1` |
| Get/Audit | `Get-{Noun}.ps1` | `get-collection-audit.ps1`, `get-dormant-projects.ps1` |
| Scan/Find | `Scan-{Noun}.ps1` | `scan-pipeline-yaml.ps1` |
| Add/Remove | `Add-{Noun}.ps1`, `Remove-{Noun}.ps1` | `Add-OrphanEmails.ps1` |

### Functions

- Use PowerShell Verb-Noun pattern
- PascalCase
- Examples: `Get-CharSignature`, `Normalize-Name`, `Invoke-EmailMatching`

### Modules

| Type | Pattern | Example |
|------|---------|---------|
| Helper module | `{Noun}-Helpers.psm1` | `AzDO-Helpers.psm1`, `EmailHelpers.psm1` |

### Output Files

- Format: `{BaseName}-{timestamp}.csv`
- Timestamp format: `yyyyMMdd-HHmmss`
- Example: `CollectionAudit-20260216-143022.csv`

---

## Script Template

All new scripts should follow this structure:

```powershell
#Requires -Version 7.0
<#
.SYNOPSIS
    Brief description of what this script does.
.DESCRIPTION
    Longer description of the script's purpose and functionality.
.PARAMETER Org
    Azure DevOps organization name (optional).
.PARAMETER PatEnvVar
    Environment variable name containing the PAT (optional).
.PARAMETER OutputFolder
    Folder for CSV output (optional).
.PARAMETER PromptIfMissing
    Prompt for PAT if not found in environment variable.
.EXAMPLE
    .\ScriptName.ps1
.EXAMPLE
    .\ScriptName.ps1 -Org "myorg" -OutputFolder "./results"
#>

[CmdletBinding()]
param(
    [Parameter()]
    [string]$Org = 'aha-bt',

    [Parameter()]
    [string]$PatEnvVar = 'AZDO_PAT',

    [Parameter()]
    [string]$OutputFolder = 'output',

    [Parameter()]
    [switch]$PromptIfMissing
)

#region Configuration
# Load configuration if available
$configPath = Join-Path $PSScriptRoot '..\..\config\defaults.json'
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
    if (-not $PSBoundParameters.ContainsKey('Org')) { $Org = $config.organization }
    if (-not $PSBoundParameters.ContainsKey('PatEnvVar')) { $PatEnvVar = $config.patEnvVar }
}
#endregion

#region Functions
function Verb-Noun {
    # ...
}
#endregion

#region Main
try {
    # Ensure output folder exists
    if (-not (Test-Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }

    # Main logic here

    # Export with timestamp
    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $outputPath = Join-Path $OutputFolder "Output-$timestamp.csv"

    Write-Host "Complete. Output: $outputPath" -ForegroundColor Green
}
catch {
    Write-Error "Failed: $_"
}
#endregion
```

---

## Required Elements

### Script Metadata

| Element | Required | Description |
|---------|----------|-------------|
| `#Requires -Version 7.0` | Yes | PowerShell version requirement |
| `.SYNOPSIS` | Yes | Brief one-line description |
| `.DESCRIPTION` | Recommended | Longer description |
| `.PARAMETER` | Recommended | Each parameter documented |
| `.EXAMPLE` | Recommended | Usage examples |

### Parameters

- Use `[CmdletBinding()]` for advanced functions
- Use `[Parameter()]` for all parameters
- Provide sensible defaults
- Include `-PromptIfMissing` for PAT-based scripts

### Error Handling

- Wrap main logic in `try/catch`
- Use `Write-Error` for failures
- Include context in error messages

### Output

- Default to `test-output/` folder
- Use timestamps in filenames
- Write success messages with `-ForegroundColor Green`

---

## Path Standards

- Use `$PSScriptRoot` for relative path resolution
- Default output to `test-output/` 
- Load config from `config/defaults.json`

### Good Examples
```powershell
$configPath = Join-Path $PSScriptRoot '..\..\config\defaults.json'
$outputPath = Join-Path $OutputFolder "Output-$timestamp.csv"
```

### Avoid
```powershell
$data = Import-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv"
```

---

## Function Standards

### Shared Functions

- Extract reusable logic to modules (`utils/modules/`)
- Use Verb-Noun naming
- Include comment-based help
- Export via `Export-ModuleMember`

### Inline Functions

- Use for script-specific logic only
- Place in `#region Functions` block
- Include basic help

---

## Module Template

```powershell
#Requires -Version 7.0
<#
.SYNOPSIS
    Module name and brief description.
.DESCRIPTION
    Detailed description of what this module provides.
#>

#region Variables
$script:ModuleName = 'ModuleName'
#endregion

#region Functions

function Verb-Noun {
    <#
    .SYNOPSIS
        Short description of what this function does.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$Parameter1
    )

    # Function logic here
}

#endregion

#region Module Exports
Export-ModuleMember -Function @(
    'Verb-Noun'
)
#endregion
```

---

## Migration Notes

### Root-Level Email Scripts

These scripts should eventually be moved to `src/private/`:

| Current | Proposed |
|---------|----------|
| `match-emails.ps1` | `src/private/Match-BySignature.ps1` |
| `match-emails-by-lastname.ps1` | `src/private/Match-ByLastName.ps1` |
| `match-and-duplicate.ps1` | `src/private/Match-WithDuplicates.ps1` |
| `add-orphans-column.ps1` | `src/private/Add-OrphanEmails.ps1` |
| `deduplicate-unmatched.ps1` | `src/private/Remove-DuplicateEmails.ps1` |
| `sort-by-name.ps1` | `src/private/Sort-EmailsByName.ps1` |
| `final-update.ps1` | `src/private/Apply-ManualOverrides.ps1` |

### Output Folder Consolidation

- Rename `test-output/` to `output/` in documentation and future scripts
- Existing `test-output/` contents can remain for now

---

## References

- Template files: `utils/templates/script-template.ps1`, `utils/templates/module-template.ps1`
- Helper modules: `utils/modules/AzDO-Helpers.psm1`, `utils/modules/EmailHelpers.psm1`
- Configuration: `config/defaults.json`
