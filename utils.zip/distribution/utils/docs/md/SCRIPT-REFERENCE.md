## Project Metadata Files

Project-related scripts use the following files in `utils/scripts/project-collection/`:

- `projects_details.json`: Canonical detailed metadata for all projects (id, name, url, etc.)
- `projects.json`: Array of project names, regenerated from the details file
- `regenerate-projects-json.ps1`: Utility script to regenerate `projects.json` from `projects_details.json`

To update the project name list after refreshing details:
```
pwsh utils/scripts/project-collection/regenerate-projects-json.ps1
```

# Script Reference Guide
## Main Entry Script: main.ps1

### Purpose
Unified entry point for all major workflows (pipeline scan, collection audit, dormant project detection).

### Synopsis
```
./main.ps1 -Action scan-pipeline|audit-collection|find-dormant [-Org <string>] [-PatEnvVar <string>] [-OutputFolder <string>] [-PromptIfMissing] [-ProjectName <string>] [-Days <int>]
```

### Parameters

| Parameter      | Type   | Default     | Description                                 |
|---------------|--------|-------------|---------------------------------------------|
| `Action`      | string | scan-pipeline | Workflow to run (see below)                |
| `Org`         | string | aha-bt      | Azure DevOps organization name               |
| `PatEnvVar`   | string | AZDO_PAT    | Environment variable containing PAT          |
| `OutputFolder`| string | ./output    | Folder for CSV output                        |
| `PromptIfMissing` | switch | false   | Prompt for PAT if not in env var            |
| `ProjectName` | string | (all)       | Filter to specific project (if supported)    |
| `Days`        | int    | 90          | Dormancy threshold (if supported)            |

### Actions
- `scan-pipeline`: Run scan-pipeline-yaml.ps1 workflow
- `audit-collection`: Run get-collection-audit.ps1 workflow
- `find-dormant`: Run get-dormant-projects.ps1 workflow
- `custom`: Manual script execution

### Examples
```powershell
# Scan for deprecated pipeline images
./main.ps1 -Action scan-pipeline

# Audit all projects
./main.ps1 -Action audit-collection

# Find dormant projects older than 180 days
./main.ps1 -Action find-dormant -Days 180
```

---

## Prerequisites

### Required
- PowerShell 7.0 or later
- Azure DevOps Personal Access Token (PAT)

### PAT Setup
Set the PAT environment variable before running any script:

```powershell
# PowerShell 7+
[Environment]::SetEnvironmentVariable('AZDO_PAT', 'your-pat-token', 'User')
```

Or run with `-PromptIfMissing` flag to enter PAT interactively.

Security note:

- Any PAT values seen in local plain text are treated as temporary and should be considered revoked.
- PAT values should only live in the active PowerShell session memory and should never be saved to source, logs, or output files.
- Recommended practice is to create PATs for session use and revoke them after use.

---

## scan-pipeline-yaml.ps1

### Purpose
Scans all Azure DevOps pipelines to identify those using deprecated operating system images (e.g., windows-2019, macos).

### Synopsis
```
.\scan-pipeline-yaml.ps1 [-Org <string>] [-PatEnvVar <string>] [-OutputFolder <string>] [-PromptIfMissing]
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `Org` | string | aha-bt | Azure DevOps organization name |
| `PatEnvVar` | string | AZDO_PAT | Environment variable containing PAT |
| `OutputFolder` | string | ./output | Folder for CSV output |
| `PromptIfMissing` | switch | false | Prompt for PAT if not in env var |

### Examples

```powershell
# Basic scan with default settings
.\scan-pipeline-yaml.ps1

# Scan specific organization
.\scan-pipeline-yaml.ps1 -Org "myorg"

# Scan with custom output folder
.\scan-pipeline-yaml.ps1 -OutputFolder "C:\Results"

# Prompt for PAT if not found
.\scan-pipeline-yaml.ps1 -PromptIfMissing
```

### Output
CSV file with columns:
- ProjectName
- PipelineName
- YamlPath
- MatchedPattern
- YamlUrl

---

## get-collection-audit.ps1

### Purpose
Performs comprehensive audit of all projects in an organization, collecting activity data across repos, pipelines, work items, pull requests, and releases.

### Synopsis
```
.\get-collection-audit.ps1 [-Org <string>] [-PatEnvVar <string>] [-ProjectName <string>] [-Days <int>] [-OutputFolder <string>] [-PromptIfMissing]
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `Org` | string | aha-bt | Azure DevOps organization name |
| `PatEnvVar` | string | AZDO_PAT | Environment variable containing PAT |
| `ProjectName` | string | (all) | Filter to specific project |
| `Days` | int | 90 | Dormancy threshold (not used in output) |
| `OutputFolder` | string | ./output | Folder for CSV output |
| `PromptIfMissing` | switch | false | Prompt for PAT if not in env var |

### Examples

```powershell
# Audit entire collection
.\get-collection-audit.ps1

# Audit specific project
.\get-collection-audit.ps1 -ProjectName "MyProject"

# Audit with custom dormancy threshold
.\get-collection-audit.ps1 -Days 180
```

### Output
CSV file with columns:
- ProjectName
- MostRecentActivity
- LastWorkItemUpdate
- LastCommitDate
- LastPipelineRun
- LastReleaseDate
- DaysSinceActivity
- WorkItemCount
- RepoCount
- PipelineCount
- ReleaseCount

---

## get-dormant-projects.ps1

### Purpose
Identifies projects with no activity (commits or pipeline runs) for a specified number of days.

### Synopsis
```
.\get-dormant-projects.ps1 [-Org <string>] [-PatEnvVar <string>] [-Days <int>] [-ProjectName <string>] [-OutputFolder <string>] [-PromptIfMissing]
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `Org` | string | aha-bt | Azure DevOps organization name |
| `PatEnvVar` | string | AZDO_PAT | Environment variable containing PAT |
| `Days` | int | 90 | Days of inactivity to flag as dormant |
| `ProjectName` | string | (all) | Filter to specific project |
| `OutputFolder` | string | ./output | Folder for CSV output |
| `PromptIfMissing` | switch | false | Prompt for PAT if not in env var |

### Examples

```powershell
# Find projects dormant > 90 days
.\get-dormant-projects.ps1

# Find projects dormant > 180 days
.\get-dormant-projects.ps1 -Days 180

# Check specific project
.\get-dormant-projects.ps1 -ProjectName "MyProject"
```

### Output
CSV file with columns:
- ProjectName
- LastActivity
- DaysDormant

---

## Common Options

### Output Location
All scripts output to `./output` by default. Create this folder or specify custom path:

```powershell
.\Script.ps1 -OutputFolder "C:\MyResults"
```

### CSV Auto-Open
Scripts automatically open the exported CSV after completion. Disable by modifying the script (remove `Invoke-Item` line).

### Progress Display
Scripts show progress bars during execution. PowerShell progress bars display in console.

### Error Handling
Scripts continue on individual API failures. Errors are logged to console in yellow.

---

## Configuration File

Edit `utils/scripts/project-collection/config/defaults.json` to change defaults across all scripts:

```json
{
  "organization": "aha-bt",
  "patEnvVar": "AZDO_PAT",
  "testPat": "REVOKED_OR_FAKE_PAT_VALUE",
  "defaults": {
    "daysDormant": 90,
    "outputFolder": "./output",
    "topRepos": 3,
    "topPipelines": 5,
    "topWorkItems": 10
  },
  "patterns": {
    "deprecatedOs": [
      "windows-2019",
      "win2019",
      "macos",
      "macos-latest",
      "10\\.0\\.14393",
      "6\\.3\\.9600"
    ]
  }
}
```

> **Note:** `testPat` is for automated tests and source validation only. Always use a real PAT via environment variable or prompt for production use.

---

## Troubleshooting

### "PAT not found" Error
Set the PAT environment variable:
```powershell
[Environment]::SetEnvironmentVariable('AZDO_PAT', 'your-token', 'User')
```

Or run with `-PromptIfMissing`

### "Invoke-RestMethod" Errors
- Verify organization name is correct
- Verify PAT has appropriate scopes (full access or specific permissions)
- Check network connectivity

### Empty Output
- Verify projects exist in the organization
- Check if PAT has read access to projects

### Module Import Errors
Ensure running from correct directory (root of utils folder):
```powershell
cd C:\path\to\utils
.\scripts\scan-pipeline-yaml.ps1
```
