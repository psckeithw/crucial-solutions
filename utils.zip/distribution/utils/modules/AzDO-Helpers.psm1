#Requires -Version 7.0
<#
.SYNOPSIS
    Azure DevOps REST API helper functions.
.DESCRIPTION
    Provides reusable functions for Azure DevOps operations including
    authentication, API calls, and common operations.
#>

#region Configuration
$script:DefaultOrg = 'aha-bt'
$script:DefaultPatEnvVar = 'AZDO_PAT'
$script:DefaultApiVersion = '7.1-preview.1'
#endregion

#region Authentication Functions

function Get-AdoPat {
    <#
    .SYNOPSIS
        Retrieves PAT from environment variable or prompts user.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$EnvVarName = $script:DefaultPatEnvVar,

        [Parameter()]
        [switch]$PromptIfMissing
    )

    # Prefer Process scope (current session) for session-first behavior
    $pat = [Environment]::GetEnvironmentVariable($EnvVarName, 'Process')
    if ([string]::IsNullOrWhiteSpace($pat)) {
        $pat = [Environment]::GetEnvironmentVariable($EnvVarName, 'User')
    }
    if ([string]::IsNullOrWhiteSpace($pat)) {
        $pat = [Environment]::GetEnvironmentVariable($EnvVarName, 'Machine')
    }

    if ([string]::IsNullOrWhiteSpace($pat)) {
        if ($PromptIfMissing -or $PromptIfMissing.IsPresent) {
            Write-Host "PAT not found in env var '$EnvVarName'. Prompting..." -ForegroundColor Yellow
            $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
            $pat = ConvertFrom-SecureStringPlain $sec
        }
        else {
            throw "PAT not found in env var '$EnvVarName'. Set it with [Environment]::SetEnvironmentVariable('$EnvVarName', '<pat>', 'User')"
        }
    }

    return $pat
}

function ConvertFrom-SecureStringPlain {
    <#
    .SYNOPSIS
        Converts secure string to plain text.
    #>
    param([Security.SecureString]$Secure)

    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try {
        [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}

function Get-AdoHeaders {
    <#
    .SYNOPSIS
        Creates authorization headers for ADO API calls.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Pat
    )

    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$Pat"))
    return @{ Authorization = "Basic $auth" }
}

#endregion

#region API Functions

function Invoke-AdoApi {
    <#
    .SYNOPSIS
        Makes authenticated REST call to Azure DevOps.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [ValidateSet('Get', 'Post', 'Patch', 'Delete', 'Put')]
        [string]$Method,

        [Parameter(Mandatory)]
        [string]$ApiPath,

        [Parameter()]
        [string]$Project,

        [Parameter()]
        [hashtable]$Headers,

        [Parameter()]
        [object]$Body,

        [Parameter()]
        [string]$ApiVersion = $script:DefaultApiVersion
    )

    # Build base URL
    $baseUrl = if ($Project) {
        "https://dev.azure.com/$Org/$Project"
    }
    else {
        "https://dev.azure.com/$Org"
    }

    # Build full URL with query string
    $separator = if ($ApiPath -match '\?') { '&' } else { '?' }
    $url = "$baseUrl/$ApiPath$separator`api-version=$ApiVersion"

    # Prepare request parameters
    $requestParams = @{
        Method = $Method
        Uri    = $url
        Headers = $Headers
    }

    if ($Body) {
        $requestParams['ContentType'] = 'application/json'
        $requestParams['Body'] = $Body | ConvertTo-Json -Depth 10
    }

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-RestMethod @requestParams -ErrorAction Stop
    }
    catch {
        if ($_.ErrorDetails.Message) {
            $bodyText = $_.ErrorDetails.Message
        }
        elseif ($_.Exception.Response) {
            try {
                $status = $_.Exception.Response.StatusCode.value__
                $stream = $_.Exception.Response.GetResponseStream()
                $reader = New-Object System.IO.StreamReader($stream)
                $bodyText = $reader.ReadToEnd()
                $reader.Close()
                $stream.Close()
            }
            catch {
                $bodyText = $_.Exception.Message
            }
        }
        else {
            $bodyText = $_.Exception.Message
        }
        throw "HTTP error - $Method $url`n$bodyText"
    }
}

function Get-AdoProjects {
    <#
    .SYNOPSIS
        Gets all projects in an organization.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$Org = $script:DefaultOrg,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $result = Invoke-AdoApi -Org $Org -Method Get -ApiPath '_apis/projects' -Headers $Headers
    return $result.value
}

function Get-AdoPipelines {
    <#
    .SYNOPSIS
        Gets pipelines for a project.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Get -ApiPath '_apis/pipelines' -Headers $Headers
    return $result.value
}

function Get-AdoPipelineRuns {
    <#
    .SYNOPSIS
        Gets recent pipeline runs for a project.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [Parameter()]
        [int]$Top = 5
    )

    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Get -ApiPath "_apis/pipelines/runs?`$top=$Top" -Headers $Headers
    return $result.value
}

function Get-AdoRepos {
    <#
    .SYNOPSIS
        Gets repositories for a project.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Get -ApiPath '_apis/repos' -Headers $Headers
    return $result.value
}

function Get-AdoRepoCommits {
    <#
    .SYNOPSIS
        Gets recent commits for a repository.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [string]$RepoId,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [Parameter()]
        [int]$Top = 1
    )

    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Get -ApiPath "_apis/git/repositories/$RepoId/commits?`$top=$Top" -Headers $Headers
    return $result.value
}

function Get-AdoWorkItems {
    <#
    .SYNOPSIS
        Queries work items using WIQL.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [Parameter(Mandatory)]
        [string]$WiqlQuery
    )

    $body = @{ query = $WiqlQuery } | ConvertTo-Json
    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Post -ApiPath '_apis/wit/wiql' -Headers $Headers -Body $body
    return $result.workItems
}

function Get-AdoPullRequests {
    <#
    .SYNOPSIS
        Gets pull requests for a project.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [Parameter()]
        [ValidateSet('all', 'active', 'completed', 'draft')]
        [string]$Status = 'all',

        [Parameter()]
        [int]$Top = 5
    )

    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Get -ApiPath "_apis/git/repos/pullrequests?status=$Status&`$top=$Top" -Headers $Headers
    return $result.value
}

function Get-AdoReleases {
    <#
    .SYNOPSIS
        Gets releases for a project.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [string]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [Parameter()]
        [int]$Top = 5
    )

    $result = Invoke-AdoApi -Org $Org -Project $Project -Method Get -ApiPath "_apis/release/releases?`$top=$Top" -Headers $Headers
    return $result.value
}

#endregion

#region Helper Functions

function Get-AdoProjectActivity {
    <#
    .SYNOPSIS
        Gets the most recent activity date across all project artifacts.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Org,

        [Parameter(Mandatory)]
        [object]$Project,

        [Parameter(Mandatory)]
        [hashtable]$Headers
    )

    $projectId = $Project.id
    $dates = @([DateTime]$Project.lastUpdateTime)

    # Get repo commits
    try {
        $repos = Get-AdoRepos -Org $Org -Project $projectId -Headers $Headers
        foreach ($repo in $repos | Select-Object -First 3) {
            try {
                $commits = Get-AdoRepoCommits -Org $Org -Project $projectId -RepoId $repo.id -Headers $Headers -Top 1
                if ($commits -and $commits.Count -gt 0) {
                    $dates += [DateTime]$commits[0].author.date
                }
            }
            catch { }
        }
    }
    catch { }

    # Get pipeline runs
    try {
        $runs = Get-AdoPipelineRuns -Org $Org -Project $projectId -Headers $Headers -Top 5
        foreach ($run in $runs) {
            if ($run.finishTime) {
                $dates += [DateTime]$run.finishTime
            }
        }
    }
    catch { }

    # Get pull requests
    try {
        $prs = Get-AdoPullRequests -Org $Org -Project $projectId -Headers $Headers -Top 5
        foreach ($pr in $prs) {
            if ($pr.closedDate) {
                $dates += [DateTime]$pr.closedDate
            }
            elseif ($pr.creationDate) {
                $dates += [DateTime]$pr.creationDate
            }
        }
    }
    catch { }

    # Get releases
    try {
        $releases = Get-AdoReleases -Org $Org -Project $projectId -Headers $Headers -Top 5
        foreach ($release in $releases) {
            if ($release.createdOn) {
                $dates += [DateTime]$release.createdOn
            }
        }
    }
    catch { }

    if ($dates.Count -gt 0) {
        return ($dates | Measure-Object -Maximum).Maximum
    }

    return $null
}

function Write-AdoProgress {
    <#
    .SYNOPSIS
        Writes consistent progress output.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Activity,

        [Parameter(Mandatory)]
        [string]$Status,

        [Parameter(Mandatory)]
        [int]$PercentComplete
    )

    Write-Progress -Activity $Activity -Status $Status -PercentComplete $PercentComplete
}

function Export-ToCsv {
    <#
    .SYNOPSIS
        Exports data to CSV with timestamp in filename.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$InputObject,

        [Parameter(Mandatory)]
        [string]$OutputFolder,

        [Parameter(Mandatory)]
        [string]$BaseName
    )

    if (-not (Test-Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }

    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $outputPath = Join-Path $OutputFolder "$BaseName-$timestamp.csv"

    $InputObject | Export-Csv -Path $outputPath -NoTypeInformation

    return $outputPath
}

#endregion

#region Module Exports
Export-ModuleMember -Function @(
    'Get-AdoPat',
    'Get-AdoHeaders',
    'Invoke-AdoApi',
    'Get-AdoProjects',
    'Get-AdoPipelines',
    'Get-AdoPipelineRuns',
    'Get-AdoRepos',
    'Get-AdoRepoCommits',
    'Get-AdoWorkItems',
    'Get-AdoPullRequests',
    'Get-AdoReleases',
    'Get-AdoProjectActivity',
    'Write-AdoProgress',
    'Export-ToCsv'
)
#endregion
