# Create Pull Request
# Reads MANIFEST.md to get file list and creates a PR with only those files

param(
    [string]$SourceBranch = "dev",
    [string]$TargetBranch = "main",
    [string]$PRTitle = "Update distribution package",
    [string]$PRDescription = "Automated PR created by create-pr.ps1`n`nThis PR updates only the files listed in MANIFEST.md",
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$distributionPath = $PSScriptRoot
$repoRoot = $distributionPath

Write-Host "=== Create Distribution PR ===" -ForegroundColor Cyan
Write-Host "Distribution Path: $distributionPath" -ForegroundColor Gray
Write-Host "Source Branch: $SourceBranch" -ForegroundColor Gray
Write-Host "Target Branch: $TargetBranch" -ForegroundColor Gray
Write-Host ""

# Check if this is a git repository
if (-not (Test-Path (Join-Path $repoRoot ".git"))) {
    Write-Error "Not a git repository. Run from the distribution folder within a git repo."
}

Push-Location $repoRoot

try {
    # Read MANIFEST.md
    $manifestPath = Join-Path $distributionPath "MANIFEST.md"
    if (-not (Test-Path $manifestPath)) {
        Write-Error "MANIFEST.md not found at $manifestPath"
    }

    Write-Host "Reading MANIFEST.md..." -ForegroundColor Yellow
    $manifestContent = Get-Content $manifestPath -Raw

    # Parse file list from MANIFEST.md
    $fileList = @()
    $inCodeBlock = $false
    $lines = $manifestContent -split "`n"
    foreach ($line in $lines) {
        if ($line -match '^```$') {
            $inCodeBlock = -not $inCodeBlock
            continue
        }
        if ($inCodeBlock -and $line.Trim() -ne '') {
            if ($line -match '^[A-Za-z]') {
                $fileList += $line.Trim()
            }
        }
    }

    Write-Host "Found $($fileList.Count) files in manifest" -ForegroundColor Green

    # Create a unique branch name for this PR
    $prBranch = "distribution-pr-$(Get-Date -Format 'yyyyMMdd-HHmmss')"

    if ($DryRun) {
        Write-Host "[DRY RUN] Would create branch: $prBranch" -ForegroundColor DarkGray
        Write-Host "[DRY RUN] Would create PR from $SourceBranch to $TargetBranch" -ForegroundColor DarkGray
        Write-Host "[DRY RUN] Would include $($fileList.Count) files" -ForegroundColor DarkGray
    } else {
        # Checkout source branch
        Write-Host "Checking out $SourceBranch..." -ForegroundColor Yellow
        git checkout $SourceBranch 2>$null
        
        # Create new branch
        Write-Host "Creating branch: $prBranch" -ForegroundColor Yellow
        git checkout -b $prBranch

        # Stage only the files in the manifest
        Write-Host "Staging $($fileList.Count) files..." -ForegroundColor Yellow
        git reset HEAD -- . 2>$null
        
        foreach ($relativePath in $fileList) {
            $filePath = Join-Path $distributionPath $relativePath
            if (Test-Path $filePath) {
                git add $relativePath
                Write-Host "[STAGED] $relativePath" -ForegroundColor Gray
            } else {
                Write-Warning "File not found, skipping: $relativePath"
            }
        }
        
        # Commit
        Write-Host "Committing changes..." -ForegroundColor Yellow
        git commit -m $PRTitle
        
        # Push the branch
        Write-Host "Pushing branch: $prBranch" -ForegroundColor Yellow
        git push origin $prBranch --set-upstream

        # Try to create PR using az CLI
        $prCreated = $false
        if (Get-Command az -ErrorAction SilentlyContinue) {
            Write-Host ""
            Write-Host "Attempting to create PR via Azure CLI..." -ForegroundColor Yellow
            
            try {
                $org = "aha-bt"
                $project = "Niche Sandbox"
                
                # Try to create PR
                $result = az repos pr create `
                    --organization "https://dev.azure.com/$org" `
                    --project $project `
                    --source-branch $prBranch `
                    --target-branch $TargetBranch `
                    --title $PRTitle `
                    --description $PRDescription `
                    --output json 2>&1

                if ($LASTEXITCODE -eq 0) {
                    $prUrl = ($result | ConvertFrom-Json).webUrl
                    Write-Host ""
                    Write-Host "PR Created Successfully!" -ForegroundColor Green
                    Write-Host "URL: $prUrl" -ForegroundColor Cyan
                    $prCreated = $true
                }
            } catch {
                Write-Warning "Failed to create PR via Azure CLI: $_"
            }
        }

        if (-not $prCreated) {
            Write-Host ""
            Write-Host "=== Manual PR Instructions ===" -ForegroundColor Yellow
            Write-Host "Azure CLI not available or PR creation failed." -ForegroundColor Yellow
            Write-Host ""
            Write-Host "To create the PR manually:" -ForegroundColor White
            Write-Host "1. Go to: https://dev.azure.com/aha-bt/Niche%20Sandbox/_git/Niche%20Sandbox" -ForegroundColor Gray
            Write-Host "2. Create a PR from branch '$prBranch' to '$TargetBranch'" -ForegroundColor Gray
            Write-Host "3. Title: $PRTitle" -ForegroundColor Gray
            Write-Host ""
            Write-Host "Branch '$prBranch' has been pushed to remote." -ForegroundColor Green
            Write-Host "You can now create the PR in the Azure DevOps web interface." -ForegroundColor Gray
        }

        # Switch back to original branch
        Write-Host ""
        Write-Host "Switching back to $SourceBranch..." -ForegroundColor Yellow
        git checkout $SourceBranch
    }

    Write-Host ""
    Write-Host "=== Summary ===" -ForegroundColor Cyan
    Write-Host "Files in manifest: $($fileList.Count)" -ForegroundColor Gray
    Write-Host "Source Branch: $SourceBranch" -ForegroundColor Gray
    Write-Host "Target Branch: $TargetBranch" -ForegroundColor Gray
    Write-Host "PR Title: $PRTitle" -ForegroundColor Gray

} finally {
    Pop-Location
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
