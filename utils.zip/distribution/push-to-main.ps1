# Push to Main Branch
# Reads MANIFEST.md to get file list and pushes only those files to main branch

param(
    [string]$Message = "Update distribution package",
    [string]$Branch = "main",
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$distributionPath = $PSScriptRoot
$repoRoot = $distributionPath

Write-Host "=== Push to Main Branch ===" -ForegroundColor Cyan
Write-Host "Distribution Path: $distributionPath" -ForegroundColor Gray
Write-Host "Target Branch: $Branch" -ForegroundColor Gray
Write-Host ""

# Check if this is a git repository
if (-not (Test-Path (Join-Path $repoRoot ".git"))) {
    Write-Error "Not a git repository. Run from the distribution folder within a git repo."
}

Push-Location $repoRoot

try {
    # Read MANIFEST.md
    $manifestPath = Join-Path $distributionPath "MANIFEST.md"
    if (-not (Test-Path $manifestPath)) {
        Write-Error "MANIFEST.md not found at $manifestPath"
    }

    Write-Host "Reading MANIFEST.md..." -ForegroundColor Yellow
    $manifestContent = Get-Content $manifestPath -Raw

    # Parse file list from MANIFEST.md
    $fileList = @()
    $inCodeBlock = $false
    $lines = $manifestContent -split "`n"
    foreach ($line in $lines) {
        if ($line -match '^```$') {
            $inCodeBlock = -not $inCodeBlock
            continue
        }
        if ($inCodeBlock -and $line.Trim() -ne '') {
            if ($line -match '^[A-Za-z]') {
                $fileList += $line.Trim()
            }
        }
    }

    Write-Host "Found $($fileList.Count) files in manifest" -ForegroundColor Green

    # Create a temporary branch name
    $tempBranch = "distribution-update-$(Get-Date -Format 'yyyyMMdd-HHmmss')"

    if ($DryRun) {
        Write-Host "[DRY RUN] Would create branch: $tempBranch" -ForegroundColor DarkGray
        Write-Host "[DRY RUN] Would push $($fileList.Count) files to $Branch" -ForegroundColor DarkGray
    } else {
        # Stage only the files in the manifest
        Write-Host "Staging $($fileList.Count) files..." -ForegroundColor Yellow
        
        # First, remove all staged files to start fresh
        git reset HEAD -- . 2>$null
        
        # Stage each file from the manifest
        foreach ($relativePath in $fileList) {
            $filePath = Join-Path $distributionPath $relativePath
            if (Test-Path $filePath) {
                git add $relativePath
                Write-Host "[STAGED] $relativePath" -ForegroundColor Gray
            } else {
                Write-Warning "File not found, skipping: $relativePath"
            }
        }
        
        # Commit
        Write-Host "Committing changes..." -ForegroundColor Yellow
        git commit -m $Message
        
        # Push directly to main (or target branch)
        Write-Host "Pushing to $Branch..." -ForegroundColor Yellow
        git push origin HEAD:$Branch --force
        
        Write-Host ""
        Write-Host "Successfully pushed to $Branch!" -ForegroundColor Green
        Write-Host "Committed $(git rev-list --count HEAD) total commits in this branch" -ForegroundColor Gray
    }

    Write-Host ""
    Write-Host "=== Summary ===" -ForegroundColor Cyan
    Write-Host "Files in manifest: $($fileList.Count)" -ForegroundColor Gray
    Write-Host "Branch: $Branch" -ForegroundColor Gray
    Write-Host "Message: $Message" -ForegroundColor Gray

} finally {
    Pop-Location
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Green
