# Main Entry Script for Azure DevOps Utilities
# This script provides a unified CLI for common workflows.

param(
    [Parameter()][ValidateSet('scan-pipeline', 'audit-collection', 'find-dormant', 'custom')][string]$Action = 'scan-pipeline',
    [Parameter()][string]$Org,
    [Parameter()][string]$PatEnvVar,
    [Parameter()][string]$OutputFolder,
    [Parameter()][switch]$PromptIfMissing,
    [Parameter()][string]$ProjectName,
    [Parameter()][int]$Days
)

# Load config
$configPath = Join-Path $PSScriptRoot 'config/defaults.json'
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
}

# Import module
$modulePath = Join-Path $PSScriptRoot 'modules/AzDO-Helpers.psm1'
Import-Module $modulePath -Force


# Set defaults and enforce test-output folder
if (-not $Org -or $Org -eq '') { $Org = $config.organization }
if (-not $PatEnvVar -or $PatEnvVar -eq '') { $PatEnvVar = $config.patEnvVar }
$OutputFolder = 'test-output'
if (-not (Test-Path $OutputFolder)) { New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null }
if (-not $Days -or $Days -eq 0) { $Days = $config.defaults.daysDormant }


# Get auth (use testPat from config if present, otherwise env var or prompt)
if ($config.testPat -and $config.testPat -ne "REVOKED_OR_FAKE_PAT_VALUE") {
    $pat = $config.testPat
} else {
    $pat = Get-AdoPat -EnvVarName $PatEnvVar -PromptIfMissing:$PromptIfMissing
}
$headers = Get-AdoHeaders -Pat $pat


# Robust script path resolution
$scanPipeline = Join-Path $PSScriptRoot 'scripts/project-collection/pipeline/scan-pipeline-yaml.ps1'
$auditCollection = Join-Path $PSScriptRoot 'scripts/project-collection/collection/get-collection-audit.ps1'
$findDormant = Join-Path $PSScriptRoot 'scripts/project-collection/collection/get-dormant-projects.ps1'

switch ($Action) {
    'scan-pipeline' {
        . $scanPipeline -Org $Org -PatEnvVar $PatEnvVar -OutputFolder $OutputFolder -PromptIfMissing:$PromptIfMissing
    }
    'audit-collection' {
        . $auditCollection -Org $Org -PatEnvVar $PatEnvVar -OutputFolder $OutputFolder -PromptIfMissing:$PromptIfMissing -ProjectName $ProjectName
    }
    'find-dormant' {
        . $findDormant -Org $Org -PatEnvVar $PatEnvVar -OutputFolder $OutputFolder -PromptIfMissing:$PromptIfMissing -Days $Days -ProjectName $ProjectName
    }
    'custom' {
        Write-Host 'Custom action: please run the desired script manually.'
    }
    default {
        Write-Host 'Unknown action. Use scan-pipeline, audit-collection, or find-dormant.'
    }
}
