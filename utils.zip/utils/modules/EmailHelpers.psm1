#Requires -Version 7.0
<#
.SYNOPSIS
    Email matching helper functions.
.DESCRIPTION
    Provides reusable functions for email-to-name matching operations
    including signature generation, normalization, and matching logic.
#>

#region Helper Functions

function Get-CharSignature {
    <#
    .SYNOPSIS
        Creates a character frequency signature from a string.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$InputString
    )

    # Clean the string: keep only letters, convert to lowercase
    $cleanedString = ($InputString -replace '[^a-zA-Z]', '').ToLower()

    # Create a sorted character array to represent the signature
    $charArray = $cleanedString.ToCharArray()
    [array]::Sort($charArray)
    return -join $charArray
}

function Normalize-Name {
    <#
    .SYNOPSIS
        Normalizes a name string for matching.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Name
    )

    # Remove parenthetical parts, suffixes, and middle initials
    $cleanedName = $Name -replace '\s*\(.*\)\s*', '' `
                         -replace '\s+(Jr|Sr|I{1,3}|IV|V)$', '' `
                         -replace '\s+[A-Z]\.\s*', ' '

    return Get-CharSignature -InputString $cleanedName
}

function Normalize-Email {
    <#
    .SYNOPSIS
        Normalizes an email prefix for matching.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Email
    )

    # Get the part before @
    $emailPrefix = ($Email.Split('@')[0])

    # Remove 't-' and 'consultant'
    $cleanedPrefix = $emailPrefix -replace '^t-', '' `
                                 -replace 'consultant', ''

    return Get-CharSignature -InputString $cleanedPrefix
}

function Get-LastName {
    <#
    .SYNOPSIS
        Extracts the last name from a full name.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$FullName
    )

    if ([string]::IsNullOrWhiteSpace($FullName)) {
        return ""
    }
    $parts = $FullName.Trim().Split(' ')
    return $parts[-1].ToLower()
}

function Get-LastNameFromEmail {
    <#
    .SYNOPSIS
        Extracts the last name from an email prefix.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Email
    )

    if ([string]::IsNullOrWhiteSpace($Email)) {
        return ""
    }
    $emailPrefix = ($Email.Split('@')[0]).ToLower()
    $emailPrefix = $emailPrefix -replace '^t-', '' -replace '\.consultant', ''
    $nameParts = $emailPrefix.Split('.')
    return $nameParts[-1]
}

#endregion

#region Module Exports
Export-ModuleMember -Function @(
    'Get-CharSignature',
    'Normalize-Name',
    'Normalize-Email',
    'Get-LastName',
    'Get-LastNameFromEmail'
)
#endregion
