<#
.SYNOPSIS
  Export a directory tree as a FLAT JSON list (no nested children) to avoid ConvertTo-Json depth limits.

.DESCRIPTION
  Emits an object with:
    {
      "schemaVersion": 2,
      "layout": "flat",
      "root": ".",
      "count": <int>,
      "nodes": [
        { "id","parentId","name","type","path",["size"] }
      ]
    }

.PARAMETER RootPath
  Root folder to scan.

.PARAMETER OutputPath
  File path for JSON output. Defaults to "<RootPath>\tree.flat.distributed.json".

.PARAMETER Exclude
  Glob patterns to exclude. Supports "**" "*" "?". Examples:
    '.git', 'node_modules', '**/dist/**', '**/*.log'

.PARAMETER MaxDepth
  -1 for unlimited. 0 returns only the root node. 1 returns direct children.

.PARAMETER IncludeHidden
  Include hidden and system files. Default: excluded unless -IncludeHidden is set.

.PARAMETER IncludeSizes
  Include file sizes in bytes for file nodes.

.PARAMETER FollowSymlinks
  Traverse reparse points and symlinks. Guarded against cycles.

.PARAMETER UseGitIgnore
  Append patterns from a root-level .gitignore to Exclude (basic support).

.PARAMETER CompactJson
  If set, writes compact JSON. Otherwise pretty-printed.

.PARAMETER Sort
  "DirsFirst" sorts directories before files by name. "Flat" is a simple name-only sort.
#>
[CmdletBinding()]

param(
  [ValidateNotNullOrEmpty()]
  [string]$RootPath = "C:\code\Niche Sandbox\dev\Niche Sandbox",

  [string]$OutputPath,

  [int]$MaxDepth = -1,

  [string[]]$Exclude = @('.git','node_modules','bin','obj','.vs','.vscode','dist','target','out'),

  [switch]$IncludeHidden,
  [switch]$IncludeSizes,
  [switch]$FollowSymlinks,
  [switch]$UseGitIgnore,
  [switch]$CompactJson,

  [ValidateSet('DirsFirst','Flat')]
  [string]$Sort = 'DirsFirst'
)

begin {
  # Resolve and validate root
  try {
    $rootItem = Get-Item -LiteralPath $RootPath -ErrorAction Stop
  } catch {
    throw "RootPath not found: $RootPath"
  }
  if (-not $rootItem.PSIsContainer) {
    throw "RootPath must be a directory: $RootPath"
  }

  if (-not $OutputPath) {
    $OutputPath = Join-Path $rootItem.FullName 'tree.flat.distributed.json'
  }

  # Utility: relative path with forward slashes that works on 5.1 and 7+
  function Get-RelativePath {
    param([string]$Base, [string]$Path)
    $baseFixed = ($Base.TrimEnd('\') + '\')
    $uriBase = [Uri]$baseFixed
    $uriPath = [Uri]$Path
    $rel = $uriBase.MakeRelativeUri($uriPath).ToString()
    [Uri]::UnescapeDataString($rel).Replace('\','/').TrimStart('./')
  }

  # Convert a glob to a regex pattern string. Anchored.
  function Convert-GlobToRegex {
    param([string]$Pattern)

    $p = $Pattern.Replace('\','/').Trim()
    $escaped = [Regex]::Escape($p)
    $escaped = $escaped -replace '\\*\\*', '___GLOBSTAR___'
    $escaped = $escaped -replace '\\*', '[^/]*'
    $escaped = $escaped -replace '___GLOBSTAR___', '.*'
    $escaped = $escaped -replace '\\\?', '.'

    '^' + $escaped + '$'
  }

  # Load .gitignore from root only (basic support)
  if ($UseGitIgnore) {
    $gitIgnore = Join-Path $rootItem.FullName '.gitignore'
    if (Test-Path -LiteralPath $gitIgnore) {
      $gi = Get-Content -LiteralPath $gitIgnore -ErrorAction SilentlyContinue |
            Where-Object { $_ -and -not $_.Trim().StartsWith('#') } |
            ForEach-Object { $_.Trim() }
      if ($gi) { $Exclude += $gi }
    }
  }

  # Compile exclude patterns into two lists:
  #  - Name-only patterns (no slash) matched against the item name
  #  - Path patterns (with slash) matched against the relative path
  $nameRegexes = New-Object System.Collections.Generic.List[Regex]
  $pathRegexes = New-Object System.Collections.Generic.List[Regex]

  foreach ($pat in $Exclude | Where-Object { $_ -and $_.Trim() -ne '' } | Select-Object -Unique) {
    $isPathPattern = $pat.Contains('/') -or $pat.Contains('\')
    $rx = [Regex]::new( (Convert-GlobToRegex $pat), [System.Text.RegularExpressions.RegexOptions]::IgnoreCase )
    if ($isPathPattern) { $pathRegexes.Add($rx) } else { $nameRegexes.Add($rx) }
  }

  function Should-Exclude {
    param(
      [System.IO.FileSystemInfo]$Item,
      [string]$RelPath
    )
    # Hidden/system filter if IncludeHidden not set
    if (-not $IncludeHidden) {
      if ($Item.Attributes.HasFlag([IO.FileAttributes]::Hidden) -or
          $Item.Attributes.HasFlag([IO.FileAttributes]::System)) {
        return $true
      }
    }

    # Directory symlink exclusion when not following links
    if (-not $FollowSymlinks) {
      if ($Item.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint)) {
        return $true
      }
    }

    # Match name-only rules
    foreach ($rx in $nameRegexes) {
      if ($rx.IsMatch($Item.Name)) { return $true }
    }

    # Match path rules against normalized relative path
    $normRel = $RelPath.Replace('\','/')

    foreach ($rx in $pathRegexes) {
      if ($rx.IsMatch($normRel)) { return $true }
    }
    return $false
  }

  function Sort-Items {
    param([System.IO.FileSystemInfo[]]$Items)
    if ($Sort -eq 'DirsFirst') {
      $Items | Sort-Object `
        @{ Expression = { if ($_.PSIsContainer) { 0 } else { 1 } } },
        @{ Expression = { $_.Name.ToLowerInvariant() } }
    } else {
      $Items | Sort-Object @{ Expression = { $_.Name.ToLowerInvariant() } }
    }
  }

  # Visited set to break cycles when following reparse points
  $visited = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  try {
    $rootResolved = (Resolve-Path -LiteralPath $rootItem.FullName -ErrorAction Stop).ProviderPath
  } catch {
    $rootResolved = $rootItem.FullName
  }
  $null = $visited.Add($rootResolved)

  # Flat collection
  $nodes = New-Object System.Collections.Generic.List[object]

  function Add-NodeFlat {
    param(
      [System.IO.FileSystemInfo]$Item,
      [string]$RelPath,
      [string]$ParentId,
      [int]$Depth
    )

    $id = if ([string]::IsNullOrWhiteSpace($RelPath)) { '.' } else { $RelPath.Replace('\','/') }

    $node = [ordered]@{
      id       = $id
      parentId = $ParentId
      name     = $Item.Name
      type     = if ($Item.PSIsContainer) { 'directory' } else { 'file' }
      path     = $id
    }

    if (-not $Item.PSIsContainer) {
      if ($IncludeSizes) {
        try { $node.size = [int64]$Item.Length } catch { $node.size = $null }
      }
      $nodes.Add([pscustomobject]$node)
      return
    }

    # Directory node
    $nodes.Add([pscustomobject]$node)

    # Respect MaxDepth: Depth=0 at root, so stop if we've reached it
    if ($MaxDepth -ge 0 -and $Depth -ge $MaxDepth) { return }

    # Resolve symlink target when following links to detect cycles
    $dirPathForCycleCheck = $Item.FullName
    if ($FollowSymlinks -and $Item.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint)) {
      try {
        $dirPathForCycleCheck = (Resolve-Path -LiteralPath $Item.FullName -ErrorAction Stop).ProviderPath
      } catch {
        # keep original path
      }
      if ($visited.Contains($dirPathForCycleCheck)) {
        # Emit a note node to indicate cycle and stop descent
        $note = [ordered]@{
          id       = "$id::__cycle__"
          parentId = $id
          name     = 'Skipped symlink cycle'
          type     = 'note'
          path     = $id
        }
        $nodes.Add([pscustomobject]$note)
        return
      }
      $null = $visited.Add($dirPathForCycleCheck)
    }

    # Enumerate children
    $gciParams = @{ LiteralPath = $Item.FullName; ErrorAction = 'SilentlyContinue' }
    if ($IncludeHidden) { $gciParams['Force'] = $true }
    $kids = @(Get-ChildItem @gciParams)

    foreach ($kid in (Sort-Items $kids)) {
      $childRel = Get-RelativePath -Base $rootItem.FullName -Path $kid.FullName
      if (Should-Exclude -Item $kid -RelPath $childRel) { continue }
      Add-NodeFlat -Item $kid -RelPath $childRel -ParentId $id -Depth ($Depth + 1)
    }
  }
}

process {
  # Root rel id
  $rootRel = Get-RelativePath -Base $rootItem.FullName -Path $rootItem.FullName
  if ([string]::IsNullOrWhiteSpace($rootRel)) { $rootRel = '.' }

  # Seed
  Add-NodeFlat -Item $rootItem -RelPath $rootRel -ParentId $null -Depth 0

  # Output object (flat)
  $outObj = [ordered]@{
    schemaVersion = 2
    layout        = 'flat'
    root          = '.'
    count         = $nodes.Count
    nodes         = $nodes
  }

  # Serialize (flat -> shallow). Depth 10 avoids the ConvertTo-Json 100 limit universally.
  $depthForConvert = 10
  if ($CompactJson) {
    $json = $outObj | ConvertTo-Json -Depth $depthForConvert -Compress
  } else {
    $json = $outObj | ConvertTo-Json -Depth $depthForConvert
  }

  # Ensure output folder exists
  $outDir = Split-Path -Parent -Path $OutputPath
  if ($outDir -and -not (Test-Path -LiteralPath $outDir)) {
    $null = New-Item -ItemType Directory -Path $outDir -Force
  }

  # Write file with UTF-8 without BOM
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($OutputPath, $json, $Utf8NoBom)

  Write-Verbose "Wrote: $OutputPath"
  $outObj
}
