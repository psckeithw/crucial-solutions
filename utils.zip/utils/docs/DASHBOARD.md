# Azure DevOps Dashboard

## Overview

The dashboard system generates a static HTML report from Azure DevOps data. It combines live API data with CSV exports from various scripts.

## Files

### generate-dashboard.ps1
Main PowerShell script that generates the dashboard.

**Usage:**
```powershell
# In authenticated terminal (AZDO_PAT must be set)
pwsh -File generate-dashboard.ps1
```

**Environment Variables:**
- `AZDO_PAT` - Azure DevOps Personal Access Token (required)

**Parameters:**
- `-Org` - Organization name (default: "aha-bt")
- `-OutputFolder` - Path to CSV files (default: "./output")
- `-DashboardOutput` - Output HTML file (default: "./dashboard.html")



HTML template file with placeholders that get replaced with actual data.

**Placeholders:**
- `{{GENERATEDAT}}` - Timestamp of generation
- `{{AUTHUSER}}` - Authenticated user display name
- `{{TOTALPROJECTS}}` - Total project count
- `{{TOTALTEAMS}}` - Total team count across all projects
- `{{WORKITEMCOUNT}}` - Work item count from CSV
- `{{ADMINCOUNT}}` - Admin count from CSV
- `{{ADMINTABLE}}` - HTML table rows for admins
- `{{WORKITEMTABLE}}` - HTML table for work items
- `{{PIPELINETABLE}}` - HTML table for pipelines
- `{{TEAMTABLE}}` - HTML table for team members
- `{{PIECHARTDATA}}` - JavaScript array for pie chart

## Expected CSV Files

The dashboard reads CSV files from the `./output/` folder. It looks for the most recent file matching these patterns:

### project-admins-*.csv
Required columns:
- `Project Name`
- `Admin Name`
- `Email`

### workitems-*.csv
Any columns are accepted - the dashboard displays whatever columns exist.

### team-members-*.csv
Required columns:
- `Team`
- `Member Name`
- `Email`

### pipeline-runs-*.csv
Required columns:
- `Pipeline Name`
- `Run Count`
- `Run Date`

## Live API Data

The script makes these live API calls:
- `GET /_apis/projects` - List all projects
- `GET /_apis/projects/{id}/teams` - Teams per project
- `GET /_apis.connectionData` - Authenticated user info

## Output

The script generates `dashboard.html` with:
- Dark theme (#0d1117 background)
- 4 stat cards (Projects, Teams, Work Items, Admins)
- Data tables for each CSV type
- Pie chart showing projects by team count (Canvas-based)
- Auto-opens in default browser

## API Timeout

All API calls timeout after 15 seconds. If an API call fails, it uses "N/A" as the value and continues.
