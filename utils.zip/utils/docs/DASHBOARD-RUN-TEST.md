# Dashboard - Run Test Button

## Overview

The dashboard (`utils/docs/summaries/dashboard2.html`) includes a "Run Test" button in the PAT Builder section that allows you to quickly test your Azure DevOps PAT authentication.

> **How the shell opens:**
> The dashboard cannot directly launch PowerShell or cmd due to browser security. Instead, it copies a command to your clipboard for you to paste and run. If you saw a shell open automatically, it was because the dashboard triggered a file download (such as a .ps1 launcher) and you manually opened it, or your browser prompted you to open the file after download.

> **Launcher file option:**
> If you want to restore automatic shell opening, you can add a "Download Launcher" button to the dashboard. This generates a .ps1 file containing the command and PAT, which you can open to launch PowerShell. No batch file is required.

> **Custom URI schemes:**
> If you have a custom URI scheme registered (like powershell://), the dashboard can use it to launch PowerShell directly, but this requires OS setup and is not standard.

## How to Use

### 1. Open the Dashboard
Open `utils/docs/summaries/dashboard2.html` in your browser.

### 2. Expand PAT Builder
Click the **+** button at the bottom of the page to expand the PAT Builder section.

### 3. Enter Your PAT
Paste your Azure DevOps Personal Access Token into the input field.

### 4. Click "Run Test"
Click the green **Run Test** button.

### 5. Run in PowerShell
1. Open PowerShell
2. Press **Ctrl+V** to paste the command
3. Press **Enter** to run

The command sets `$env:AZDO_PAT` and runs the test script to verify your PAT works.

> **Note:**
> Browsers cannot launch PowerShell directly from static HTML. Only file download + manual execution, or clipboard copy + paste, are supported. If you want a launcher file, ask for the dashboard to include a "Download Launcher" button.

## Command Format

The button copies this command:
```powershell
$env:AZDO_PAT="your-pat"; pwsh -File "C:\code\Niche Sandbox\dev\Niche Sandbox\utils\tests\test-pat.ps1" -Org "aha-bt"
```

## Session Behavior


---

### Troubleshooting

- If you want the dashboard to open PowerShell automatically, request a launcher file feature.
- If you see a shell open after clicking a dashboard button, it was due to a downloaded file or a custom URI scheme.
- No batch files are required; launcher files can be .ps1 PowerShell scripts.

## Troubleshooting

### Button doesn't respond
- Press **Ctrl+Shift+R** to hard refresh the browser
- Make sure the PAT Builder section is expanded (+)

### "Failed to copy" error
- Check browser permissions for clipboard access
- Try using the "Build Command" button instead and manually copy the output

### Test fails
- Verify your PAT has the correct scopes:
  - `vso.code` - Code (read)
  - `vso.build` - Build (read)
  - `vso.work` - Work (read)
  - `vso.project` - Project and Team (read)
