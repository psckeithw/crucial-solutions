#Requires -Version 7.0
param(
    [string]$Org = "aha-bt",
    [string]$OutputFolder = "./output",
    [string]$ReportOutput = "utils/docs/reports/report.html",
    [string]$TemplateFile = "utils/docs/reports/report-template.html"
)

$script:ApiTimeout = 15
$script:PieColors = @('#00d4aa', '#4d9eff', '#d2a8ff', '#f78166', '#7ee787', '#79c0ff', '#d2a8ff', '#ff7b72')

function Get-ApiHeaders {
    $pat = $env:AZDO_PAT
    if ([string]::IsNullOrWhiteSpace($pat)) { throw "AZDO_PAT not set" }
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
    return @{ Authorization = "Basic $auth" }
}

function Invoke-SafeApiCall {
    param($Url, $Headers)
    try { return Invoke-RestMethod -Uri $Url -Headers $Headers -TimeoutSec $script:ApiTimeout -ErrorAction Stop }
    catch { Write-Warning "API failed: $Url"; return $null }
}

function Get-NewestCsv {
    param($Pattern)
    $f = Get-ChildItem -Path $OutputFolder -Filter $Pattern -EA SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    return $f.FullName
}

function Import-CsvSafe {
    param($Path)
    if (-not (Test-Path $Path)) { return @() }
    try { return @((Import-Csv -Path $Path -EA Stop)) }
    catch { return @() }
}

function ConvertTo-HtmlText {
    param($Text)
    if ([string]::IsNullOrEmpty($Text)) { return "" }
    return [System.Net.WebUtility]::HtmlEncode($Text)
}

Write-Host "Generating Azure DevOps Report..." -ForegroundColor Cyan

# Collect CSV data
Write-Host "  Scanning CSV files..." -ForegroundColor Gray
$adminCsv = Get-NewestCsv "project-admins-*.csv"
$workItemCsv = Get-NewestCsv "workitems-*.csv"
$teamCsv = Get-NewestCsv "team-members-*.csv"
$pipelineCsv = Get-NewestCsv "pipeline-runs-*.csv"

$adminData = if ($adminCsv) { Import-CsvSafe $adminCsv } else { @() }
$workItemData = if ($workItemCsv) { Import-CsvSafe $workItemCsv } else { @() }
$teamData = if ($teamCsv) { Import-CsvSafe $teamCsv } else { @() }
$pipelineData = if ($pipelineCsv) { Import-CsvSafe $pipelineCsv } else { @() }

# Live API calls
Write-Host "  Fetching live data..." -ForegroundColor Gray
$headers = Get-ApiHeaders
$baseUrl = "https://dev.azure.com/$Org"

$projects = @()
$projData = Invoke-SafeApiCall "$baseUrl/_apis/projects?`$top=500" $headers
if ($projData -and $projData.value) { $projects = @($projData.value) }

$totalTeams = 0
$teamCounts = @{}
foreach ($p in $projects) {
    $t = Invoke-SafeApiCall "$baseUrl/_apis/projects/$($p.id)/teams?`$top=100" $headers
    if ($t -and $t.value) {
        $teamCounts[$p.name] = $t.value.Count
        $totalTeams += $t.value.Count
    }
}

$authUser = "N/A"
$conn = Invoke-SafeApiCall "$baseUrl/_apis.connectionData" $headers
if ($conn -and $conn.authenticatedUser) { $authUser = $conn.authenticatedUser.displayName }

# Build values
$genAt = Get-Date -Format "yyyy-MM-dd HH:mm"
$totalProj = if ($projects) { $projects.Count } else { 0 }

# Admin table
$adminRows = ""
$adminTotal = $adminData.Count
if ($adminTotal -gt 0) {
    foreach ($r in $adminData) {
        $adminRows += "<tr><td>$(ConvertTo-HtmlText $r.'Project Name')</td><td>$(ConvertTo-HtmlText $r.'Admin Name')</td><td>$(ConvertTo-HtmlText $r.Email)</td></tr>"
    }
}
$adminCount = if ($adminTotal -gt 0) { $adminTotal } else { "No data" }

# Work items table
$workRows = ""
$workTotal = $workItemData.Count
if ($workTotal -gt 0) {
    $disp = $workItemData | Select-Object -First 20
    $cols = $disp[0].PSObject.Properties.Name
    $workRows = "<thead><tr>"
    foreach ($c in $cols) { $workRows += "<th>$c</th>" }
    $workRows += "</tr></thead><tbody>"
    foreach ($r in $disp) {
        $workRows += "<tr>"
        foreach ($c in $cols) { $workRows += "<td>$(ConvertTo-HtmlText [string]$r.$c)</td>" }
        $workRows += "</tr>"
    }
    $workRows += "</tbody>"
}
$workCount = if ($workTotal -gt 0) { $workTotal } else { "No data" }
$workNote = if ($workTotal -gt 20) { "<p class='table-note'>Showing first 20 of $workTotal items</p>" } else { "" }

# Pipeline table
$pipeRows = ""
if ($pipelineData.Count -gt 0) {
    $g = $pipelineData | Group-Object "Pipeline Name" | ForEach-Object {
        [PSCustomObject]@{
            Name = $_.Name
            Count = $_.Count
            LastRun = ($_.Group | Sort-Object "Run Date" -Descending | Select-Object -First 1)."Run Date"
        }
    }
    foreach ($p in $g) {
        $pipeRows += "<tr><td>$(ConvertTo-HtmlText $p.Name)</td><td>$($p.Count)</td><td>$(ConvertTo-HtmlText $p.LastRun)</td></tr>"
    }
} else {
    $pipeRows = "<tr><td colspan='3' class='no-data'>No pipeline data</td></tr>"
}

# Team table
$teamRows = ""
$teamTotal = $teamData.Count
if ($teamTotal -gt 0) {
    foreach ($r in $teamData) {
        $teamRows += "<tr><td>$(ConvertTo-HtmlText $r.Team)</td><td>$(ConvertTo-HtmlText $r.'Member Name')</td><td>$(ConvertTo-HtmlText $r.Email)</td></tr>"
    }
}
$teamCountVal = if ($teamTotal -gt 0) { "$teamTotal total" } else { "No data" }

# Pie chart
$pieData = ""
$idx = 0
foreach ($e in $teamCounts.GetEnumerator() | Select-Object -First 8) {
    $pieData += "{ label: `"$($e.Key)`", count: $($e.Value), color: `"$($script:PieColors[$idx % 8])`" },"
    $idx++
}

# Read template and replace
Write-Host "  Writing report.html..." -ForegroundColor Gray
if (-not (Test-Path $TemplateFile)) {
    Write-Error "Template file not found: $TemplateFile"
    exit 1
}
$html = Get-Content $TemplateFile -Raw
if ([string]::IsNullOrWhiteSpace($html)) {
    Write-Error "Template file is empty: $TemplateFile"
    exit 1
}
$html = $html -replace '{{GENERATEDAT}}', $genAt
$html = $html -replace '{{AUTHUSER}}', $authUser
$html = $html -replace '{{TOTALPROJECTS}}', $totalProj
$html = $html -replace '{{TOTALTEAMS}}', $totalTeams
$html = $html -replace '{{WORKITEMCOUNT}}', $workCount
$html = $html -replace '{{ADMINCOUNT}}', $adminCount
$html = $html -replace '{{ADMINTOTAL}}', $adminTotal
$html = $html -replace '{{ADMINTABLE}}', $adminRows
$html = $html -replace '{{WORKITEMTOTAL}}', $workTotal
$html = $html -replace '{{WORKITEMTABLE}}', $workRows
$html = $html -replace '{{WORKITEMNOTE}}', $workNote
$html = $html -replace '{{PIPELINETABLE}}', $pipeRows
$html = $html -replace '{{TEAMCOUNT}}', $teamCountVal
$html = $html -replace '{{TEAMTABLE}}', $teamRows
$html = $html -replace '{{PIECHARTDATA}}', $pieData

$html | Out-File -FilePath $ReportOutput -Encoding UTF8

Write-Host "  Report written to: $ReportOutput" -ForegroundColor Green
Write-Host "  Opening in browser..." -ForegroundColor Gray
Start-Process $ReportOutput
Write-Host "Done!" -ForegroundColor Green
