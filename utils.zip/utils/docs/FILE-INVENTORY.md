# File Inventory

## Core Scripts (Active Use)

### project-collection/collection/ (Collection Metrics)
| File | Purpose |
|------|----------|
| get-collection-audit.ps1 | Comprehensive audit of all projects |
| get-dormant-projects.ps1 | Find inactive projects |
| ado-collection-metrics.ps1 | Collection usage metrics |
| collection-usage-report.ps1 | Usage report generation |
| git-repo-user-list.ps1 | List git repo users |
| regenerate-projects-json.ps1 | Regenerate projects.json |

### project-collection/export/ (Export/Delete - PRIMARY FOCUS)
| File | Purpose |
|------|----------|
| export-and-delete-ado-projects.ps1 | Main export/delete script |
| ExportAndDelete-ProjectsToProcess.json | Projects config |
| DecommissionEmailTemplate.json | Email template |

### project-collection/pipeline/
| File | Purpose |
|------|----------|
| scan-pipeline-yaml.ps1 | Find deprecated pipeline images |
| pipeline-pools.ps1 | List agent pools |
| get-yaml.ps1 | Download pipeline YAML |

### project-collection/config/
| File | Purpose |
|------|----------|
| defaults.json | Global configuration |

### project-collection/process-templates/WorkItems/Bug/
| File | Purpose |
|------|----------|
| bug-process-*.ps1 | Work item processing scripts |

### project-collection/reporting/
| File | Purpose |
|------|----------|
| snapshot-get.ps1 | Capture metrics snapshot |
| snapshot-compare.ps1 | Compare snapshots |
| azure-devops-metrics-snapshot.ps1 | Detailed metrics |

### modules/
| File | Purpose |
|------|----------|
| AzDO-Helpers.psm1 | Azure DevOps API functions |
| EmailHelpers.psm1 | Email processing functions |

### Email Scripts (utils/email/)
| File | Purpose |
|------|----------|
| create-draft-emails.ps1 | Create Outlook drafts |
| match-emails.ps1 | Match emails by name |
| match-emails-by-lastname.ps1 | Match by lastname |
| sort-by-name.ps1 | Sort CSV by name |
| add-orphans-column.ps1 | Add orphan column |
| deduplicate-unmatched.ps1 | Deduplicate emails |
| scan-email.ps1 | Scan Outlook inbox |
| final-update.ps1 | Manual overrides |
| match-and-duplicate.ps1 | Match with duplicates |

---

## Test/Utility Scripts (utils/tests/)

### Core Test Infrastructure
| File | Purpose | Status |
|------|----------|--------|
| Test-Harness.ps1 | Test runner | ACTIVE |
| export-and-delete-tests.ps1 | Regression tests | ACTIVE |
| get-project-admins.ps1 | Get project admins | ACTIVE |
| test-pat.ps1 | Test PAT validity | ACTIVE |
| test-urls.ps1 | Test API URLs | ACTIVE |
| test-admin-api.ps1 | Test admin API | ACTIVE |
| test-groups-api.ps1 | Test groups API | ACTIVE |
| test-project-object.ps1 | Test project object | ACTIVE |
| test-project-props.ps1 | Test project properties | ACTIVE |

### One-Off/Debug Scripts (Can Be Archived)
| File | Purpose | Recommendation |
|------|----------|-----------------|
| debug-admins.ps1 | Debug admin API | Archive |
| debug-admins2.ps1 | Debug admin API v2 | Archive |
| debug-admins3.ps1 | Debug admin API v3 | Archive |
| debug-wiql.ps1 | Debug WIQL queries | Archive |
| Find-MemoirProject.ps1 | Find specific project | Archive |
| analyze-errors.ps1 | Analyze error logs | Archive |
| clean-test-output.ps1 | Clean test outputs | Archive |
| fix-script.ps1 | One-off fix script | Archive |
| update-refs.ps1 | Update references | Archive |
| validate-fix.ps1 | Validate fixes | Archive |
| Get-ScriptRef.ps1 | Get script references | Archive |

### Test Results (Should Be Deleted or Moved)
| File | Recommendation |
|------|-----------------|
| TestHarness-Results-*.json | Delete (generated output) |
| tests/output/*.csv | Move to output/ or delete |

---

## Dashboard Files (utils/docs/summaries/)

### Active Dashboards
| File | Purpose |
|------|----------|
| Dashboard.html | Main dashboard |
| dashboard2.html | Secondary dashboard |
| dashboard-config.js | Dashboard configuration |

### Demo/Archive
| File | Purpose | Recommendation |
|------|----------|-----------------|
| Dashboard-collapsible-demo.html | Demo variant | Archive |
| dashboard-config-dropdown-demo.js | Demo config | Archive |
| dashboard-project-view/ | Empty folder | Delete |

### Static Summaries (Out of Scope)
| File | Purpose |
|------|----------|
| Collection-Summary.html | Static report |
| ExportAndDelete-Summary.html | Static report |
| Full-Project-Summary.html | Static report |
| Pipeline-Summary.html | Static report |
| Reporting-Summary.html | Static report |
| TextMatching-Summary.html | Static report |
| WorkItems-Summary.html | Static report |
| report-template.html | Template |

---

## Documentation (utils/docs/)

### Active Documentation
| File | Purpose |
|------|----------|
| ARCHITECTURE.md | System architecture |
| SCRIPT-REFERENCE.md | Script usage guide |
| SCRIPT-PATTERNS.md | Naming conventions |
| context.md | Project context |
| analysis.md | Current state analysis |
| DASHBOARD.md | Dashboard overview |

### Out of Scope (Not ADO Export)
| File | Purpose |
|------|----------|
| export-and-delete-ado-projects.md | Old doc |
| agent-prompt.md | Agent prompts |

---

## Recommendations

### Files to Archive/Delete:
1. `tests/debug-*.ps1` - One-off debug scripts
2. `tests/Find-MemoirProject.ps1` - Specific project finder
3. `tests/analyze-errors.ps1` - Error analysis
4. `tests/clean-test-output.ps1` - Cleanup utility
5. `tests/fix-script.ps1` - One-off fix
6. `tests/update-refs.ps1` - Reference updater
7. `tests/validate-fix.ps1` - Validation utility
8. `TestHarness-Results-*.json` - Test output (generated)
9. `tests/output/*.csv` - Test CSVs (generated)
10. `docs/summaries/dashboard-project-view/` - Empty folder

### Current Project Structure:
```
utils/
├── email/                    # Email processing (active)
├── modules/                  # Helper modules (active)
├── scripts/
│   └── project-collection/
│       ├── collection/       # Collection scripts (active)
│       ├── config/           # Configuration (active)
│       ├── export/           # PRIMARY FOCUS (active)
│       ├── pipeline/         # Pipeline scripts (active)
│       ├── process-templates/# Work item processing (active)
│       └── reporting/        # Reporting (active)
├── tests/
│   ├── Test-Harness.ps1    # Core test runner
│   └── output/              # Test outputs (generated)
└── docs/
    └── summaries/           # Dashboard files
```
