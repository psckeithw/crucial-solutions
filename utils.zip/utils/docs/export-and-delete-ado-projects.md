# export-and-delete-ado-projects.ps1

## Overview
Production-grade script that exports Azure DevOps project work items to CSV/Excel and optionally deletes the project. Implements safe defaults and checkpoint/resume support.

## Usage

### Basic Export (Safe - No Deletion)
```powershell
$env:AZDO_PAT = 'your-pat-token'
pwsh -File "utils\scripts\project-collection\clean-up\export-and-delete-ado-projects.ps1" `
    -ConfigFile "ExportAndDelete-ProjectsToProcess.json" `
    -ExportOnly
```

### Using Project List Directly
```powershell
pwsh -File "utils\scripts\project-collection\clean-up\export-and-delete-ado-projects.ps1" `
    -ProjectsToProcess "ProjectA;Project B;ProjectC" `
    -ExportOnly
```

### Export + Delete (Requires Both Flags)
```powershell
pwsh -File "utils\scripts\project-collection\clean-up\export-and-delete-ado-projects.ps1" `
    -ConfigFile "ExportAndDelete-ProjectsToProcess.json" `
    -ConfirmDelete -Force
```

## Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| ConfigFile | No | - | JSON file with project list |
| ProjectsToProcess | No* | - | Semicolon-separated project names |
| ExportOnly | No | true | Skip deletion (default) |
| ConfirmDelete | No | false | Deletion gate 1/2 |
| Force | No | false | Deletion gate 2/2 |
| OrganizationUrl | No | https://aha-bt.visualstudio.com/ | Azure DevOps org URL |
| OutputRoot | No | test-output | Output directory |
| ApiVersion | No | 7.1 | Azure DevOps API version |
| UseImportExcel | No | false | Export to XLSX format |

*Either ConfigFile or ProjectsToProcess is required.

## Output Structure
```
<OutputRoot>/
├── <ProjectName>/
│   ├── <ProjectName>-workitems.csv
│   ├── <ProjectName>-workitems.xlsx (if -UseImportExcel)
│   ├── <ProjectName>-metadata.json
│   ├── <ProjectName>-workitem_fields.json
│   ├── <ProjectName>-pipeline_pool_usage.json
│   ├── <ProjectName>-manifest.json
│   ├── <ProjectName>-state.json
│   ├── <ProjectName>-log.txt
├── ExportAndDelete-AdoProjects-Summary-*.csv/json
```

## Summary CSV Columns
- ProjectName, ProjectId, Status
- ExistingWorkItemCount, ExportedWorkItemCount, Difference
- WorkItemTypesInProject, ExportedWorkItemTypes, NotExportedTypes
- DeleteRequested, DeleteStatus, DeleteOperationId
- PipelinePoolCount, PipelinePoolIdentities
- ErrorCount, ErrorMessage

## Project Config File
Create a JSON file with your projects:
```json
{
  "description": "Projects to process",
  "instructions": "Add exact project names from Azure DevOps",
  "projects": [
    "Project A",
    "Project B",
    "Project C"
  ]
}
```

## Safety Features
- Export-only by default (no deletion)
- Deletion requires BOTH `-ConfirmDelete AND -Force`
- PAT never logged or persisted
- Supports checkpoint/resume via state files
- Retry with jitter for transient errors (429/5xx)

## Required PAT Scopes
- Work item read: `vso.work`
- Project and team read: `vso.project`
- Project deletion (optional): `vso.project_delete`

---

## Migration Plan (2026-02-17)
- All per-project artifacts will be written to a single folder per project, filenames prefixed with project name.
- State and manifest files remain distinct but are stored in the project folder.
- Main script and consolidated module will be updated to use new output structure.
- Documentation will reflect new workflow and directory structure.
