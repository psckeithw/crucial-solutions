# Azure DevOps Utilities - Architecture Documentation

## Overview

This codebase provides a set of PowerShell utilities for analyzing and managing Azure DevOps organizations. The architecture follows modular design principles to maximize reusability and maintainability.

## Current Effort Scope

The primary focus is the **Export-and-Delete** effort:
- Main script: `utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1`
- Default mode: export-only (safe, no deletion)
- Deletion requires explicit dual confirmation (`-ConfirmDelete` and `-Force`)

## Directory Structure


```
Niche Sandbox/
├── utils/
│   ├── config/
│   │   └── defaults.json          # Centralized configuration
│   ├── modules/
│   │   └── AzDO-Helpers.psm1      # Reusable ADO API functions
│   ├── scripts/
│   │   └── project-collection/
│   │       ├── projects_details.json   # Canonical detailed project metadata
│   │       ├── projects.json          # Canonical list of project names
│   │       ├── regenerate-projects-json.ps1 # Regenerate projects.json
│   │       ├── collection/           # Collection metrics scripts
│   │       ├── config/              # Configuration files
│   │       ├── export/              # Export/delete scripts
│   │       ├── pipeline/            # Pipeline analysis scripts
│   │       ├── reporting/            # Reporting scripts
│   │       └── process-templates/    # Work item processing
│   └── docs/
│       └── ...                    # Architecture, reference, and review docs
├── test-output/                 # Runtime output (git-ignored)
├── README.md                    # Primary operational guide
├── analysis.md                  # Current-state analysis
└── TODO.md                      # Active implementation backlog
```
## Project Metadata Files

- `projects_details.json`: Contains full metadata for all projects (id, name, url, lastUpdateTime, etc.). This is the canonical source for all project details.
- `projects.json`: Contains a simple array of project names, regenerated from the details file for lightweight lookups.
- Only these two files are used for project metadata. All scripts reference these canonical files in `utils/scripts/project-collection/`.

To regenerate the project name list, run:
```
pwsh utils/scripts/project-collection/regenerate-projects-json.ps1
```

## Module Design

### AzDO-Helpers.psm1

The core module containing reusable Azure DevOps operations. This module follows the Single Responsibility Principle - each function does one thing well.

#### Authentication Layer
- `Get-AdoPat` - Retrieves PAT from environment variables (User > Machine > Process)
- `Get-AdoHeaders` - Creates authorization headers for REST calls

#### API Layer
- `Invoke-AdoApi` - Generic REST method wrapper with error handling
- `Get-AdoProjects` - Fetches all projects
- `Get-AdoPipelines` - Lists pipelines for a project
- `Get-AdoPipelineRuns` - Gets recent pipeline executions
- `Get-AdoRepos` - Lists git repositories
- `Get-AdoRepoCommits` - Gets recent commits
- `Get-AdoWorkItems` - Queries work items via WIQL
- `Get-AdoPullRequests` - Lists pull requests
- `Get-AdoReleases` - Lists releases

#### Helper Functions
- `Get-AdoProjectActivity` - Aggregates all activity types into single timestamp
- `Write-AdoProgress` - Consistent progress bar output
- `Export-ToCsv` - Standardized CSV export with timestamps

### Configuration (defaults.json)

Centralized configuration that avoids hardcoded values:

```json
{
  "organization": "aha-bt",
  "patEnvVar": "AZDO_PAT",
  "defaults": {
    "daysDormant": 90,
    "topRepos": 3,
    "topPipelines": 5
  },
  "patterns": {
    "deprecatedOs": ["windows-2019", "macos", ...]
  }
}
```


## Script Architecture

### Common Pattern

All scripts follow a consistent structure:

1. **Parameter Block** - All configurable options exposed as parameters
2. **Config Loading** - Load from defaults.json, allow parameter override
3. **Module Import** - Import AzDO-Helpers
4. **Authentication** - Get PAT and headers
5. **Main Logic** - Iterate, process, collect results
6. **Export** - Write CSV with timestamp

### Main Entry Script (main.ps1)

**Purpose**: Provide a unified CLI for common workflows and orchestrate script execution.

**Usage**:
```powershell
./main.ps1 -Action scan-pipeline|audit-collection|find-dormant [-Org ...] [-PatEnvVar ...] [-OutputFolder ...] [-PromptIfMissing] [-ProjectName ...] [-Days ...]
```

**Actions**:
- `scan-pipeline`: Run scan-pipeline-yaml.ps1 workflow
- `audit-collection`: Run get-collection-audit.ps1 workflow
- `find-dormant`: Run get-dormant-projects.ps1 workflow
- `custom`: Manual script execution

This script loads configuration, imports modules, and standardizes authentication and parameter handling for all workflows.

### scan-pipeline-yaml.ps1

**Purpose**: Find pipelines using deprecated OS images

**Flow**:
1. Load deprecated OS patterns from config
2. For each project:
   - Get all pipelines
   - For each pipeline:
     - Fetch YAML definition
     - Match against patterns
     - Record matches
3. Export results

### get-collection-audit.ps1

**Purpose**: Comprehensive activity analysis

**Flow**:
1. For each project:
   - Get repo commits (top 3 repos)
   - Get pipeline runs (top 5)
   - Get work items
   - Get pull requests
   - Get releases
   - Aggregate all timestamps to find most recent
2. Export with detailed timestamps

### get-dormant-projects.ps1

**Purpose**: Identify inactive projects

**Flow**:
1. For each project:
   - Get repo commit dates
   - Get pipeline run dates
   - Find most recent
2. Filter by cutoff date
3. Export dormant projects

## Design Patterns

### 1. Parameter Precedence
Parameters override config file, which overrides hardcoded defaults:
```
Command Line > defaults.json > Module Defaults
```

### 2. Idempotent Error Handling
Each API call wrapped in try/catch to continue on individual failures.

### 3. Progress Reporting
Consistent Write-Progress usage across all scripts.

### 4. Output Standardization
- Timestamps in filenames: `basename-YYYYMMDD-HHmmss.csv`
- Consistent column naming
- Auto-open after export

## Extension Guide

### Adding a New Script

1. Create script in `utils/scripts/`
2. Use template:

```powershell
#Requires -Version 7.0
<#
.SYNOPSIS
    Brief description
.DESCRIPTION
    Detailed description
.PARAMETER Org
    Azure DevOps organization
#>
[CmdletBinding()]
param(
    [Parameter()][string]$Org = 'aha-bt',
    [Parameter()][string]$PatEnvVar = 'AZDO_PAT',
    [Parameter()][string]$OutputFolder = './output'
)

# Load config
$configPath = Join-Path $PSScriptRoot '..\config\defaults.json'
if (Test-Path $configPath) {
    $config = Get-Content $configPath | ConvertFrom-Json
    # Set defaults from config
}

# Import module
$modulePath = Join-Path $PSScriptRoot '..\modules\AzDO-Helpers.psm1'
Import-Module $modulePath -Force

# Get auth
$pat = Get-AdoPat -EnvVarName $PatEnvVar -PromptIfMissing
$headers = Get-AdoHeaders -Pat $pat

# Your logic here

# Export
$outputPath = Export-ToCsv -InputObject $results -OutputFolder $OutputFolder -BaseName "MyScript"
```

### Adding Module Functions

Add to `AzDO-Helpers.psm1`:

1. Write function with proper comment-based help
2. Add to `Export-ModuleMember` at bottom

### Modifying Configuration

Edit `defaults.json` - changes apply to all scripts on next run.

## Dependencies

- PowerShell 7.0+
- Azure DevOps Personal Access Token (PAT)
- PAT stored in environment variable (default: `AZDO_PAT`)

## Security Considerations

- PATs stored in environment variables, never in code
- Basic auth header construction uses base64 encoding
- TLS 1.2 enforced for API calls
