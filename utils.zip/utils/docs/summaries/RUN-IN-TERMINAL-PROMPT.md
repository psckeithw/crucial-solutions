
# HTML Dashboard Agent — Run in Terminal Guidance

**Role:** Senior frontend developer specializing in HTML/JavaScript dashboards.
**Objective:** Make the "Run Test" button trigger PowerShell script execution securely, without exposing secrets or requiring manual copy-paste after initial authentication.

---

## Context
File: `utils/docs/summaries/dashboard2.html`

## Problem Recap
- The dashboard is opened via file:// (not localhost, not hosted)
- Browsers cannot launch PowerShell or run scripts directly from file:// for security reasons
- No batch file or launcher file should be generated if it exposes secrets
- PAT must not be written to disk or displayed

## Solution Guidance

### 1. Manual Authentication (First Time Only)
- User authenticates in PowerShell terminal (sets $env:AZDO_PAT or runs Connect-AzAccount)
- Dashboard generates the command (e.g., `pwsh -File "utils\tests\test-pat.ps1" -Organization "aha-bt"`)
- User manually copies and pastes the command for initial authentication

### 2. Automated Command Execution (After Auth)
- If you want to automate running scripts from the dashboard without manual paste:
	- Ship a PowerShell bridge script (e.g., using System.Net.HttpListener)
	- User runs the bridge script in their authenticated shell
	- Dashboard sends commands to the bridge (via fetch to localhost)
	- Bridge executes the commands securely in the authenticated environment
- This approach avoids exposing the PAT and does not require manual copy-paste after initial auth

### 3. Clipboard Fallback
- If automation is not possible, fallback to clipboard copy for command generation
- User pastes the command in their authenticated shell

---

## Important Notes
- Browsers running from file:// cannot launch PowerShell or run scripts directly
- Any file download (batch, .ps1) will expose secrets if embedded
- Only the authenticated shell can run scripts securely
- The bridge script is optional and only needed for automation
- PAT should never be written to disk or displayed in the dashboard

---

## Action Items
- Remove any batch file download logic from dashboard2.html
- Update the "Run Test" button to either:
	- Copy the command to clipboard (fallback)
	- Send the command to a bridge script if running (automation)
- Ensure no secrets are exposed or written to disk




