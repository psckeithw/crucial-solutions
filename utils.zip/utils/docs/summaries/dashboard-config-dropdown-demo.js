/*
 * Dashboard Script Dropdown Demo
 * This file demonstrates the new dropdown structure for script groups.
 */

'use strict';

const DASHBOARD_CONFIG = {
  organization: "aha-bt",
  basePath: "C:\\code\\Niche Sandbox\\dev\\Niche Sandbox\\utils",
  scripts: [
    // ===== COLLECTION SCRIPTS =====
    {
      id: "collection-audit",
      label: "Collection Audit",
      group: "Collection",
      file: "scripts\\project-collection\\clean-up\\collection\\get-collection-audit.ps1",
      desc: "Comprehensive activity audit across repos, pipelines, work items, PRs, and releases for all projects.",
      params: [
        { name: "Days", flag: "-Days", type: "number", default: "90", label: "Days threshold", required: false }
      ]
    },
    {
      id: "dormant-projects",
      label: "Dormant Projects",
      group: "Collection",
      file: "scripts\\project-collection\\clean-up\\collection\\get-dormant-projects.ps1",
      desc: "Identifies projects with no commit or pipeline activity for a specified number of days.",
      params: [
        { name: "Days", flag: "-Days", type: "number", default: "90", label: "Days of inactivity", required: false }
      ]
    },
    {
      id: "collection-metrics",
      label: "Collection Metrics",
      group: "Collection",
      file: "scripts\\project-collection\\clean-up\\collection\\ado-collection-metrics.ps1",
      desc: "Collects usage metrics across the Azure DevOps collection.",
      params: []
    },
    // ===== GIT SCRIPTS =====
    {
      id: "git-repo-user-list",
      label: "Git Repo User List",
      group: "Git",
      file: "scripts\\project-collection\\clean-up\\collection\\git-repo-user-list.ps1",
      desc: "Lists all users who have committed to git repos across the collection.",
      params: []
    },
    // ===== PIPELINE SCRIPTS =====
    {
      id: "scan-pipeline-yaml",
      label: "Scan Pipeline YAML",
      group: "Pipeline",
      file: "scripts\\project-collection\\clean-up\\pipeline\\scan-pipeline-yaml.ps1",
      desc: "Finds pipelines using deprecated OS images such as windows-2019 or macos-latest.",
      params: []
    }
    // ...other scripts...
  ]
};

// Example HTML rendering for dropdowns
function renderScriptDropdowns(config) {
  const groups = {};
  config.scripts.forEach(script => {
    if (!groups[script.group]) groups[script.group] = [];
    groups[script.group].push(script);
  });

  let html = '';
  Object.keys(groups).forEach(group => {
    html += `<details class="script-group"><summary><span class="caret">▾</span> ${group}</summary><ul class="script-list">`;
    groups[group].forEach(script => {
      html += `<li class="script-item" data-script-id="${script.id}">${script.label}</li>`;
    });
    html += '</ul></details>';
  });
  return html;
}

// Usage: document.getElementById('scripts-panel').innerHTML = renderScriptDropdowns(DASHBOARD_CONFIG);
