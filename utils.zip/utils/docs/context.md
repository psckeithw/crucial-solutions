# Project Context Summary

## Current Effort Focus

This repo is focused on the **Export-and-Delete** effort for Azure DevOps projects:
- Primary script: `utils/scripts/project-collection/export/export-and-delete-ado-projects.ps1`
- Operating mode: export-first (safe by default)
- Deletion requires explicit dual confirmation

## High-Level Decisions & Rationale

- **Export-Only Default:**
  - All exports are safe by default - no deletion occurs unless explicitly requested
  - Deletion requires BOTH `-ConfirmDelete` AND `-Force` flags
  - Rationale: Prevent accidental project deletion, ensure data safety

- **PAT Security:**
  - PAT values are session-scoped only (in-memory)
  - No PAT values stored in scripts, config, logs, or committed output
  - Rationale: Prevent credential leakage, follow security best practices

- **Output Organization:**
  - Per-project exports go to individual folders under `test-output/`
  - All artifacts in a project folder are prefixed with project name
  - Runtime artifacts are git-ignored
  - Rationale: Clean organization, easy recovery, no source control pollution

- **Checkpoint/Resume:**
  - State and manifest files enable resumption after partial runs
  - Rationale: Handle large project sets, transient failures gracefully

## Repo Structure Overview

- **PowerShell Utilities:**
  - `modules/AzDO-Helpers.psm1` - Reusable Azure DevOps API functions
  - `scripts/project-collection/` - Domain-specific scripts organized by function
  - No single main entry point - scripts are invoked directly
- **Configuration:** `config/defaults.json` for global defaults
- **Docs:** Architecture, script reference, and review docs for onboarding

## Key Documents

- `README.md` - Primary operational guide
- `analysis.md` - Current-state analysis and scope
- `TODO.md` - Active implementation backlog
- `utils/docs/REVIEW-LATEST.md` - Quick status snapshot
- `utils/docs/PROJECT-REVIEW.md` - Detailed effort review

## Suggestions for Future Work

- Always review README.md before making changes
- Maintain export-only as default for safety
- Keep PAT handling session-only (no persistence)
- Document major decisions in context.md or analysis.md

---
This summary provides a historical and architectural overview for any future agent to quickly get up to speed and understand the main decisions, rationale, and structure of this repo.
