# Field binding
Invoke-ADOJson GET "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$WitRef/fields/$EnvRefName?api-version=7.1-preview.2"

# Layout
Invoke-ADOJson GET "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$WitRef/layout?api-version=7.1-preview.2"

# Required flags
Invoke-ADOJson GET "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$WitRef/fields/Microsoft.VSTS.Scheduling.StoryPoints?api-version=7.1-preview.2"