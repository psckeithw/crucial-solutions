$Base64Auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$Pat"))
$Headers = @{ "Authorization" = "Basic $Base64Auth" }

# function Get-AdoHeaders {
#     $token = (az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 | ConvertFrom-Json).accessToken
#     return @{ Authorization = "Bearer $token" }
# }
function Get-AdoHeaders {
    Write-Host "Get-AdoHeaders $Pat"
    if (-not $Pat) { throw "PAT is empty." }
    $base64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$Pat"))
    return @{ Authorization = "Basic $base64" }
}

# function Invoke-ADOJson {
#     param($Method,$Url,$Body=$null)
#     $Headers = Get-AdoHeaders
#     if ($Body -ne $null) {
#         $json = $Body | ConvertTo-Json -Depth 20
#         return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -ContentType "application/json" -Body $json
#     } else {
#         return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers
#     }
# }
function Invoke-ADOJson {
    param($Method, $Url, $Body = $null)

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $Headers = Get-AdoHeaders

    try {
        if ($Body -ne $null) {
            $json = $Body | ConvertTo-Json -Depth 20
            return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -ContentType "application/json" -Body $json
        }
        else {
            return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers
        }
    }
    catch {
        if ($_.Exception.Response) {
            $status = $_.Exception.Response.StatusCode.value__
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $bodyText = $reader.ReadToEnd()
            throw "HTTP $status $Method $Url`n$bodyText"
        }
        throw
    }
}

function Get-Process {
function Get-Process {
    $url = "https://dev.azure.com/$Org/_apis/work/processes?api-version=7.1-preview.2"
    $all = Invoke-ADOJson GET $url

    $all.value | ForEach-Object {
        Write-Host ("Process: '{0}'  Id: {1}" -f $_.name, $_.typeId)
    }

    return $all.value | Where-Object { $_.name -eq $Process }
}
}

function Get-WitByName {
    param($ProcessId, $WitName)
    $url = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes?api-version=7.1-preview.2"
    $wits = Invoke-ADOJson GET $url
    return $wits.value | Where-Object { $_.name -eq $WitName }
}

function Ensure-GlobalField {
    param($RefName, $Name)
    # GET field; create if missing
    $getUrl = "https://dev.azure.com/$Org/_apis/wit/fields/$RefName?api-version=7.1-preview.2"
    try {
        $f = Invoke-ADOJson GET $getUrl
        return $f
    }
    catch {
        # Create global field as string; picklist is enforced at process-level binding
        $createUrl = "https://dev.azure.com/$Org/_apis/wit/fields?api-version=7.1-preview.2"
        $body = @{
            name          = $Name
            referenceName = $RefName
            type          = "string"
            readOnly      = $false
        }
        return Invoke-ADOJson POST $createUrl $body
    }
}

function Ensure-ProcessFieldBinding {
    param($ProcessId, $WitRefName, $FieldRef, $Required, $AllowedValues)

    # Check if field already bound to WIT in process
    $getUrl = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes/$WitRefName/fields/$FieldRef?api-version=7.1-preview.2"
    try {
        $pf = Invoke-ADOJson GET $getUrl
        # Update if required/values differ
        $needsUpdate = $false
        if ($null -ne $Required -and $pf.required -ne $Required) { $needsUpdate = $true }
        if ($AllowedValues -and @($pf.allowedValues) -ne @($AllowedValues)) { $needsUpdate = $true }

        if ($needsUpdate) {
            $patchUrl = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes/$WitRefName/fields/$FieldRef?api-version=7.1-preview.2"
            $body = @{}
            if ($null -ne $Required) { $body.required = $Required }
            if ($AllowedValues.Count -gt 0) { $body.allowedValues = $AllowedValues }
            return Invoke-ADOJson PATCH $patchUrl $body
        }
        else {
            return $pf
        }
    }
    catch {
        # Create binding with allowedValues and required
        $postUrl = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes/$WitRefName/fields?api-version=7.1-preview.2"
        $body = @{
            referenceName = $FieldRef
            required      = $Required
        }
        if ($AllowedValues.Count -gt 0) { $body.allowedValues = $AllowedValues }
        return Invoke-ADOJson POST $postUrl $body
    }
}

function Get-BugLayout {
    param($ProcessId, $WitRefName)
    $url = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes/$WitRefName/layout?api-version=7.1-preview.2"
    return Invoke-ADOJson GET $url
}

function Find-SystemInfoGroup {
    param($Layout)
    # Search groups by label "System Info" (left column)
    foreach ($page in $Layout.pages) {
        foreach ($section in $page.sections) {
            foreach ($group in $section.groups) {
                if ($group.label -eq "System Info") { 
                    return @{ page = $page; section = $section; group = $group }
                }
            }
        }
    }
    throw "System Info group not found in layout."
}

function Ensure-ControlInGroup {
    param($ProcessId, $WitRefName, $Group, $FieldRefName, $Label)

    $existing = $Group.controls | Where-Object { $_.controlType -eq "FieldControl" -and $_.fields[0].referenceName -eq $FieldRefName }
    if ($existing) { return $existing }

    # POST control to the group
    $groupId = $Group.id
    $postUrl = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes/$WitRefName/layout/groups/$groupId/controls?api-version=7.1-preview.2"
    $body = @{
        id             = $null
        order          = 1000
        label          = $Label
        controlType    = "FieldControl"
        readOnly       = $false
        visible        = $true
        contributions  = @()
        inherited      = $false
        height         = 0
        isContribution = $false
        fields         = @(@{ referenceName = $FieldRefName })
    }
    return Invoke-ADOJson POST $postUrl $body
}

function Set-RequiredFlag {
    param($ProcessId, $WitRefName, $FieldRef, $Required)
    $patchUrl = "https://dev.azure.com/$Org/_apis/work/processes/$ProcessId/workItemTypes/$WitRefName/fields/$FieldRef?api-version=7.1-preview.2"
    $body = @{ required = $Required }
    try { 
        Invoke-ADOJson PATCH $patchUrl $body 
    }
    catch {
        # If not bound yet, bind minimal then patch
        Ensure-ProcessFieldBinding -ProcessId $ProcessId -WitRefName $WitRefName -FieldRef $FieldRef -Required $Required -AllowedValues @()
    }
}