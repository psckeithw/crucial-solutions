$Org        = "your-org"              # dev.azure.com/{your-org}
$Process    = "Your Inherited Process"
$PatEnvVar  = "AZDO_PAT"
$PromptIfMissing = $true

function ConvertFrom-SecureStringPlain {
	param([Security.SecureString]$Secure)
	$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
	try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
	finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Get-PatFromEnv {
	param([string]$Name)
	[Environment]::GetEnvironmentVariable($Name, "User") ??
	[Environment]::GetEnvironmentVariable($Name, "Machine") ??
	[Environment]::GetEnvironmentVariable($Name, "Process")
}

$Pat = Get-PatFromEnv -Name $PatEnvVar
if ([string]::IsNullOrWhiteSpace($Pat)) {
	if ($PromptIfMissing) {
		Write-Host "PAT not found in env var '$PatEnvVar'. Prompting..."
		$sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
		$Pat = ConvertFrom-SecureStringPlain $sec
	} else {
		throw "PAT not found in env var '$PatEnvVar'. Set it (e.g., `setx $PatEnvVar '<pat>'`) and re-run."
	}
}
$WitName    = "Bug"                   # We’ll resolve refName dynamically

# New field definition
$EnvFieldName   = "Environment"
$EnvRefName     = "Custom.Environment"   # choose your org prefix; immutable once created
$EnvValues      = @("Test","QA","Staging","Production")

# Optional: picklist changes for existing fields (example placeholders)
$IdentifiedDuringRef = "Custom.IdentifiedDuring"  # set to actual refname if known
$PlatformRef         = "Custom.Platform"          # set to actual refname if known
$IdentifiedDuring_Add    = @()  # e.g. "Regression testing","Exploratory testing"
$IdentifiedDuring_Remove = @()  # e.g. "Functional testing","Production"
$Platform_Add            = @()  # e.g. "Mobile","Admin","Email"
$Platform_Remove         = @()  # e.g. "Atlas","Ecards"