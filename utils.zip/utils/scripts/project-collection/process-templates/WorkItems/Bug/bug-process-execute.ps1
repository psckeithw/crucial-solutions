$proc = Get-Process
if (-not $proc) { throw "Process '$Process' not found." }

$wit = Get-WitByName -ProcessId $proc.id -WitName $WitName
if (-not $wit) { throw "WIT '$WitName' not found in process '$Process'." }
$WitRef = $wit.referenceName  # e.g., "Bug"

# 1) Ensure global field exists
Ensure-GlobalField -RefName $EnvRefName -Name $EnvFieldName | Out-Null

# 2) Bind to process WIT with allowedValues + required
Ensure-ProcessFieldBinding -ProcessId $proc.id -WitRefName $WitRef -FieldRef $EnvRefName -Required $true -AllowedValues $EnvValues | Out-Null

# 3) Place in System Info group
$layout = Get-BugLayout -ProcessId $proc.id -WitRefName $WitRef
$sys = Find-SystemInfoGroup -Layout $layout
Ensure-ControlInGroup -ProcessId $proc.id -WitRefName $WitRef -Group $sys.group -FieldRefName $EnvRefName -Label "Environment" | Out-Null

# 4) Required flags
Set-RequiredFlag -ProcessId $proc.id -WitRefName $WitRef -FieldRef "Microsoft.VSTS.Scheduling.StoryPoints" -Required $true
Set-RequiredFlag -ProcessId $proc.id -WitRefName $WitRef -FieldRef "Microsoft.VSTS.Common.Priority" -Required $false
Set-RequiredFlag -ProcessId $proc.id -WitRefName $WitRef -FieldRef "Microsoft.VSTS.Common.Severity" -Required $false

# 5) (Optional) Update existing picklists, if you provided their refnames
if ($IdentifiedDuringRef) {
    Ensure-ProcessFieldBinding -ProcessId $proc.id -WitRefName $WitRef -FieldRef $IdentifiedDuringRef -Required $null -AllowedValues @() | Out-Null
    # Read existing allowed values
    $getUrl = "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$WitRef/fields/$IdentifiedDuringRef?api-version=7.1-preview.2"
    $cur = Invoke-ADOJson GET $getUrl
    $vals = [System.Collections.Generic.List[string]]::new()
    ($cur.allowedValues | ForEach-Object { [void]$vals.Add($_) })
    foreach ($add in $IdentifiedDuring_Add) { if (-not $vals.Contains($add)) { [void]$vals.Add($add) } }
    foreach ($rem in $IdentifiedDuring_Remove) { [void]$vals.Remove($rem) | Out-Null }
    Invoke-ADOJson PATCH $getUrl @{ allowedValues = @($vals) } | Out-Null
}

if ($PlatformRef) {
    Ensure-ProcessFieldBinding -ProcessId $proc.id -WitRefName $WitRef -FieldRef $PlatformRef -Required $null -AllowedValues @() | Out-Null
    $getUrl = "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$WitRef/fields/$PlatformRef?api-version=7.1-preview.2"
    $cur = Invoke-ADOJson GET $getUrl
    $vals = [System.Collections.Generic.List[string]]::new()
    ($cur.allowedValues | ForEach-Object { [void]$vals.Add($_) })
    foreach ($add in $Platform_Add) { if (-not $vals.Contains($add)) { [void]$vals.Add($add) } }
    foreach ($rem in $Platform_Remove) { [void]$vals.Remove($rem) | Out-Null }
    Invoke-ADOJson PATCH $getUrl @{ allowedValues = @($vals) } | Out-Null
}

"Done."