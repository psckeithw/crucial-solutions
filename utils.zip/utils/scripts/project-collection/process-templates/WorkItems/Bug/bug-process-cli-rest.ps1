# Prereqs
az devops configure --defaults organization=https://dev.azure.com/$Org
az devops login --organization https://dev.azure.com/$Org  # paste PAT

# Get processes
az devops invoke --route-parameters organization=$Org `
  --method GET `
  --area work `
  --resource processes `
  --api-version 7.1-preview.2

# Example: create global field
az devops invoke --route-parameters organization=$Org `
  --method POST `
  --area wit --resource fields --api-version 7.1-preview.2 `
  --body "{`"name`":`"$EnvFieldName`",`"referenceName`":`"$EnvRefName`",`"type`":`"string`",`"readOnly`":false}"