
# az login
# az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798

# Load helpers
. "$PSScriptRoot\bug-process-helpers.ps1"


$PatEnvVar = "AZDO_PAT"
$PromptIfMissing = $true

function ConvertFrom-SecureStringPlain {
    param([Security.SecureString]$Secure)
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Get-PatFromEnv {
    param([string]$Name)
    [Environment]::GetEnvironmentVariable($Name, "User") ??
    [Environment]::GetEnvironmentVariable($Name, "Machine") ??
    [Environment]::GetEnvironmentVariable($Name, "Process")
}

$Pat = Get-PatFromEnv -Name $PatEnvVar
if ([string]::IsNullOrWhiteSpace($Pat)) {
    if ($PromptIfMissing) {
        Write-Host "PAT not found in env var '$PatEnvVar'. Prompting..."
        $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
        $Pat = ConvertFrom-SecureStringPlain $sec
    } else {
        throw "PAT not found in env var '$PatEnvVar'. Set it (e.g., `setx $PatEnvVar '<pat>'`) and re-run."
    }
}

$Org        = "aha-bt"              # dev.azure.com/{your-org}
$Process    = "AHA BT School Management Tool v3"
$WitName    = "Bug"

# New field: Environment
$EnvFieldName   = "Environment"
$EnvRefName     = "Custom.Environment"
$EnvValues      = @("Test","QA","Staging","Production")

# Existing fields: Identified During, Platform
$IdentifiedDuringRef = "Custom.IdentifiedDuring"
$PlatformRef         = "Custom.Platform"
$IdentifiedDuring_Add    = @("Regression testing","Exploratory testing")
$IdentifiedDuring_Remove = @("Functional testing","Production")
$Platform_Add            = @("Mobile","Admin","Email")
$Platform_Remove         = @("Atlas","Ecards")

# --- Main orchestration ---
Write-Host "Resolving process and Bug WIT..."
$proc = Get-Process
if (-not $proc) { throw "Process '$Process' not found." }
$wit = Get-WitByName $proc.id $WitName
if (-not $wit) { throw "Bug WIT not found in process." }

Write-Host "Ensuring Environment field exists..."
Ensure-GlobalField $EnvRefName $EnvFieldName

Write-Host "Binding Environment field to Bug WIT with allowed values and required flag..."
Ensure-ProcessFieldBinding $proc.id $wit.referenceName $EnvRefName $true $EnvValues

Write-Host "Updating picklist values for Identified During..."
if ($IdentifiedDuring_Add.Count -or $IdentifiedDuring_Remove.Count) {
    # Add values
    foreach ($val in $IdentifiedDuring_Add) {
        # Implement add logic here
        Write-Host "Would add '$val' to Identified During"
    }
    # Remove values
    foreach ($val in $IdentifiedDuring_Remove) {
        # Implement remove logic here
        Write-Host "Would remove '$val' from Identified During"
    }
}

Write-Host "Updating picklist values for Platform..."
if ($Platform_Add.Count -or $Platform_Remove.Count) {
    foreach ($val in $Platform_Add) {
        Write-Host "Would add '$val' to Platform"
    }
    foreach ($val in $Platform_Remove) {
        Write-Host "Would remove '$val' from Platform"
    }
}

Write-Host "Setting required flags for Story Points, Priority, Severity..."
Set-RequiredFlag $proc.id $wit.referenceName "Microsoft.VSTS.Scheduling.StoryPoints" $true
Set-RequiredFlag $proc.id $wit.referenceName "Microsoft.VSTS.Common.Priority" $false
Set-RequiredFlag $proc.id $wit.referenceName "Microsoft.VSTS.Common.Severity" $false

Write-Host "Placing Environment field on Bug form in System Info group..."
$layout = Get-BugLayout $proc.id $wit.referenceName
$group = Find-SystemInfoGroup $layout
Ensure-ControlInGroup $proc.id $wit.referenceName $EnvRefName $group.id

Write-Host "Verification:"
Invoke-ADOJson GET "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$($wit.referenceName)/fields/$EnvRefName?api-version=7.1-preview.2"
Invoke-ADOJson GET "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$($wit.referenceName)/layout?api-version=7.1-preview.2"
Invoke-ADOJson GET "https://dev.azure.com/$Org/_apis/work/processes/$($proc.id)/workItemTypes/$($wit.referenceName)/fields/Microsoft.VSTS.Scheduling.StoryPoints?api-version=7.1-preview.2"

Write-Host "All steps complete. Review output above for verification."