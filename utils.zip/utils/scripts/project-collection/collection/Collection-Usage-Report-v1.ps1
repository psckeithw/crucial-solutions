# Azure DevOps Metrics Snapshot
# Pulls current and 6-month-old metrics for all monitored projects
# Outputs: *old.csv (6 months ago) and *new.csv (today)

param(
    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = "C:\code\Niche Sandbox\utils\scripts\project-collection\output"
)

# Projects to monitor
$MonitoredProjects = @(
    # 'Azure Cloud Remediation',
# 'Azure Cloud Infrastructure',
# 'BT-Finance',
# 'CDO',
# 'CN Redesign'
# 'CampaignAnalytics',
# 'Copyright Website',
# 'Cybersec Team',
# 'DataWarehouse-OSO',
# 'Dig Ops Support',
# 'Digital Multimedia',
# 'Digital Program Operations',
# 'Direct Response Monthly Campaigns',
# 'ECC Sales DB Process Improvement Project',
# 'Fit Challenge',
# 'Front-End',
# 'Fundraising Systems Development',
# 'HC Redesign',
# 'HR Systems',
# 'Heartitude',
# 'IPAD Heart Check Re-write',
# 'Instructor Network',
# 'Liive',
# 'Living Guidelines Implementation',
# 'MS Dynamics',
'Niche Sandbox',
# 'OSO DataStore',
# 'OneHeart Datawarehouse',
# 'Oracle Integration Cloud (OIC)',
# 'PHD DOTNET',
# 'ProfessionalHeartDaily',
# 'Quality Initiatives',
# 'Rewards Redemption',
# 'Salesforce Program',
# 'SalesforceCSP',
# 'School Management Tool',
'SharePoint'
# 'Shared Requirements',
# 'SingleSignOn',
# 'Sitecore',
# 'Social Events',
# 'WordPress',
# 'Youth Market',
)

# Date ranges
$today = Get-Date
$sixMonthsAgo = $today.AddMonths(-6)

Write-Host "Current date: $($today.ToString('yyyy-MM-dd'))"
Write-Host "6 months ago: $($sixMonthsAgo.ToString('yyyy-MM-dd'))"
Write-Host "Projects: $($MonitoredProjects.Count)"
Write-Host ""

# Ensure output folder exists
if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder | Out-Null
}

# Load projects from file
$projectData = Get-Content (Join-Path $PSScriptRoot "projects.json") | ConvertFrom-Json
$projectsToProcess = @($projectData.value | Where-Object { $MonitoredProjects -contains $_.name })

Write-Host "Processing $($projectsToProcess.Count) projects.."

$oldResults = @()
$newResults = @()
$counter = 0

foreach ($project in $projectsToProcess) {
    $counter++
    Write-Progress -Activity "Collecting Metrics" -Status "$counter of $($projectsToProcess.Count) - $($project.name)" `
        -PercentComplete (($counter / $projectsToProcess.Count) * 100)

    try {
        $oldReport = [PSCustomObject]@{
            ProjectName           = $project.name
            Commits_6mo           = 0
            Builds_6mo            = 0
            'BuildSuccessRate_Pct'  = 0
            ActiveUsers           = 0
            RepoSize_MB           = 0
            PipelineMinutes       = 0
            ArtifactStorage       = 0
        }

        $newReport = [PSCustomObject]@{
            ProjectName           = $project.name
            Commits_6mo           = 0
            Builds_6mo            = 0
            'BuildSuccessRate_Pct'  = 0
            ActiveUsers           = 0
            RepoSize_MB           = 0
            PipelineMinutes       = 0
            ArtifactStorage       = 0
        }

        # === REPOS & COMMITS ===
        try {
            $repos = az repos list --project $project.id 2>$null | ConvertFrom-Json
            if ($repos) {
                $oldCommits = 0
                $newCommits = 0
                $oldContributors = @{}
                $newContributors = @{}
                $totalRepoSize = 0

                foreach ($repo in $repos) {
                    # Get current repo size
                    try {
                        $repoDetails = az devops invoke --area git --resource repositories `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters api-version=7.1 -o json 2>$null | ConvertFrom-Json
                        if ($repoDetails.size) { $totalRepoSize += $repoDetails.size }
                    } catch {}

                    # Get commits - OLD (6 months ago to 1 month ago)
                    try {
                        $oldFromDate = $sixMonthsAgo.ToString('MM/dd/yyyy')
                        $oldToDate = $sixMonthsAgo.AddMonths(1).ToString('MM/dd/yyyy')
                        $oldCommitsJson = az devops invoke --area git --resource commits `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters "searchCriteria.fromDate=$oldFromDate" "searchCriteria.toDate=$oldToDate" "api-version=7.1" `
                            -o json 2>$null | ConvertFrom-Json
                        
                        if ($oldCommitsJson.value) {
                            $oldCommits += $oldCommitsJson.value.Count
                            foreach ($commit in $oldCommitsJson.value) {
                                if ($commit.author.email) { $oldContributors[$commit.author.email] = $true }
                            }
                        }
                    } catch {}

                    # Get commits - NEW (last 30 days)
                    try {
                        $newFromDate = $today.AddDays(-30).ToString('MM/dd/yyyy')
                        $newToDate = $today.ToString('MM/dd/yyyy')
                        $newCommitsJson = az devops invoke --area git --resource commits `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters "searchCriteria.fromDate=$newFromDate" "searchCriteria.toDate=$newToDate" "api-version=7.1" `
                            -o json 2>$null | ConvertFrom-Json
                        
                        if ($newCommitsJson.value) {
                            $newCommits += $newCommitsJson.value.Count
                            foreach ($commit in $newCommitsJson.value) {
                                if ($commit.author.email) { $newContributors[$commit.author.email] = $true }
                            }
                        }
                    } catch {}
                }
                
                $oldReport.Commits_6mo = $oldCommits
                $newReport.Commits_6mo = $newCommits
                $oldReport.ActiveUsers = $oldContributors.Count
                $newReport.ActiveUsers = $newContributors.Count
                $newReport.RepoSize_MB = [math]::Round($totalRepoSize / 1MB, 2)
                $oldReport.RepoSize_MB = $newReport.RepoSize_MB  # Assume repo size similar 6mo ago
            }
        } catch {}

        # === PIPELINES & BUILDS ===
        try {
            $oldBuilds = 0
            $oldSucceeded = 0
            $oldMinutes = 0
            $newBuilds = 0
            $newSucceeded = 0
            $newMinutes = 0

            $builds = az pipelines runs list --project $project.id --top 1000 2>$null | ConvertFrom-Json
            if ($builds) {
                foreach ($build in $builds) {
                    if ($build.finishTime) {
                        $finishTime = [DateTime]$build.finishTime
                        
                        # OLD: 6 months ago to 1 month ago
                        if ($finishTime -ge $sixMonthsAgo -and $finishTime -lt $sixMonthsAgo.AddMonths(1)) {
                            $oldBuilds++
                            if ($build.result -eq 'succeeded') { $oldSucceeded++ }
                            if ($build.startTime) {
                                $duration = ($finishTime - [DateTime]$build.startTime).TotalMinutes
                                $oldMinutes += $duration
                            }
                        }
                        
                        # NEW: Last 30 days
                        if ($finishTime -ge $today.AddDays(-30)) {
                            $newBuilds++
                            if ($build.result -eq 'succeeded') { $newSucceeded++ }
                            if ($build.startTime) {
                                $duration = ($finishTime - [DateTime]$build.startTime).TotalMinutes
                                $newMinutes += $duration
                            }
                        }
                    }
                }
            }

            $oldReport.Builds_6mo = $oldBuilds
            $newReport.Builds_6mo = $newBuilds
            $oldReport.PipelineMinutes = [math]::Round($oldMinutes, 0)
            $newReport.PipelineMinutes = [math]::Round($newMinutes, 0)
            
            if ($oldBuilds -gt 0) {
                $oldReport.'BuildSuccessRate_Pct' = [math]::Round(($oldSucceeded / $oldBuilds) * 100, 1)
            }
            if ($newBuilds -gt 0) {
                $newReport.'BuildSuccessRate_Pct' = [math]::Round(($newSucceeded / $newBuilds) * 100, 1)
            }
        } catch {}

        $oldResults += $oldReport
        $newResults += $newReport

    } catch {
        Write-Host "  ERROR: $($project.name) - $($_.Exception.Message)"
        continue
    }
}

Write-Progress -Activity "Collecting Metrics" -Completed

# Export results
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
#TODO add this timestamp back and del then copy these 
# $previousPath = Join-Path $OutputFolder "metrics-previous-$timestamp.csv"
# $currentPath  = Join-Path $OutputFolder "metrics-current-$timestamp.csv"
$previousPath = Join-Path $OutputFolder "metrics-previous.csv"
$currentPath  = Join-Path $OutputFolder "metrics-current.csv"

$oldResults | Export-Csv -Path $previousPath -NoTypeInformation
$newResults | Export-Csv -Path $currentPath -NoTypeInformation
Write-Host "Previous metrics: $previousPath"
Write-Host "Current metrics:  $currentPath"

# Calculate growth/change between previous and current
Write-Host "Calculating growth metrics..."
$growthResults = foreach ($new in $newResults) {
    $old = $oldResults | Where-Object { $_.ProjectName -eq $new.ProjectName }
    if ($old) {
        [PSCustomObject]@{
            ProjectName = $new.ProjectName
            RepoSizeChange = if ([double]$old.RepoSize_MB -ne 0) { [Math]::Max(0, (([double]$new.RepoSize_MB - [double]$old.RepoSize_MB) / [double]$old.RepoSize_MB) * 100) } elseif ([double]$new.RepoSize_MB -gt 0) { 100 } else { $null }
            CommitsChange = if ([int]$old.Commits_6mo -ne 0) { [Math]::Max(0, (([int]$new.Commits_6mo - [int]$old.Commits_6mo) / [int]$old.Commits_6mo) * 100) } elseif ([int]$new.Commits_6mo -gt 0) { 100 } else { $null }
            BuildsChange = if ([int]$old.Builds_6mo -ne 0) { [Math]::Max(0, (([int]$new.Builds_6mo - [int]$old.Builds_6mo) / [int]$old.Builds_6mo) * 100) } elseif ([int]$new.Builds_6mo -gt 0) { 100 } else { $null }
            PipelineMinutesChange = if ([double]$old.PipelineMinutes -ne 0) { [Math]::Max(0, (([double]$new.PipelineMinutes - [double]$old.PipelineMinutes) / [double]$old.PipelineMinutes) * 100) } elseif ([double]$new.PipelineMinutes -gt 0) { 100 } else { $null }
            ArtifactStorageChange = if ([double]$old.ArtifactStorage -ne 0) { [Math]::Max(0, (([double]$new.ArtifactStorage - [double]$old.ArtifactStorage) / [double]$old.ArtifactStorage) * 100) } elseif ([double]$new.ArtifactStorage -gt 0) { 100 } else { $null }
            ActiveUsersChange = if ([int]$old.ActiveUsers -ne 0) { [Math]::Max(0, (([int]$new.ActiveUsers - [int]$old.ActiveUsers) / [int]$old.ActiveUsers) * 100) } elseif ([int]$new.ActiveUsers -gt 0) { 100 } else { $null }
            BuildSuccessRatePctChange = if ([double]$old.'BuildSuccessRate_Pct' -ne 0) { [Math]::Max(0, (([double]$new.'BuildSuccessRate_Pct' - [double]$old.'BuildSuccessRate_Pct') / [double]$old.'BuildSuccessRate_Pct') * 100) } elseif ([double]$new.'BuildSuccessRate_Pct' -gt 0) { 100 } else { $null }
        }
    }
}

$growthPath = Join-Path $OutputFolder "UsageGrowthReport.csv"
$growthResults | Export-Csv -Path $growthPath -NoTypeInformation
Write-Host "Growth metrics:   $growthPath"
$growthResults | Format-Table