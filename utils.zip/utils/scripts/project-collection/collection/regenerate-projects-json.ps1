# Regenerate projects.json from projects_details.json
# This script reads the detailed project metadata and outputs a list of project names.

$detailsPath = Join-Path $PSScriptRoot 'projects_details.json'
$outputPath = Join-Path $PSScriptRoot 'projects.json'

if (-not (Test-Path $detailsPath)) {
    Write-Error "projects_details.json not found."
    exit 1
}

$details = Get-Content $detailsPath | ConvertFrom-Json
$names = $details.value | ForEach-Object { $_.name }
$names | ConvertTo-Json -Depth 1 | Set-Content $outputPath
Write-Host "projects.json regenerated with $($names.Count) project names."
