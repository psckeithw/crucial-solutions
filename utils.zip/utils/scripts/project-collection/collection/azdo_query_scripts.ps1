# Azure DevOps - Find Pipelines Using Mac or Server 2019 Agents
# MULTI-PROJECT VERSION - BALANCED & LINT-FRIENDLY
# -------------------------------------------------------------------
# This script scans all projects in an Azure DevOps organization,
# discovers all macOS and Windows Server 2019 build agents,
# finds all pipelines using those agents, and exports a full report.
# -------------------------------------------------------------------

param(
    [switch]$DryRun  # Enables mock API responses for safe testing
)

$organization = "aha-bt"
$PatEnvVar = "AZDO_PAT"
$PromptIfMissing = $true

function ConvertFrom-SecureStringPlain {
    param([Security.SecureString]$Secure)
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Get-PatFromEnv {
    param([string]$Name)
    [Environment]::GetEnvironmentVariable($Name, "User") ??
    [Environment]::GetEnvironmentVariable($Name, "Machine") ??
    [Environment]::GetEnvironmentVariable($Name, "Process")
}

$pat = Get-PatFromEnv -Name $PatEnvVar
if ([string]::IsNullOrWhiteSpace($pat)) {
    if ($PromptIfMissing) {
        Write-Host "PAT not found in env var '$PatEnvVar'. Prompting..."
        $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
        $pat = ConvertFrom-SecureStringPlain $sec
    } else {
        throw "PAT not found in env var '$PatEnvVar'. Set it (e.g., `setx $PatEnvVar '<pat>'`) and re-run."
    }
}

# ------------------------------------------------------------
# Create authentication header for REST API calls
# ------------------------------------------------------------
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{
    Authorization  = "Basic $base64AuthInfo"
    "Content-Type" = "application/json"
}

$orgBaseUrl = "https://dev.azure.com/$organization/_apis"

# ------------------------------------------------------------
# Function: GET wrapper for REST API calls
# Supports real calls and DryRun simulated calls
# ------------------------------------------------------------
function Get-Api {
    param([string]$Uri)

    if (-not $DryRun) {
        return Invoke-RestMethod -Uri $Uri -Headers $headers -Method Get -ErrorAction Stop
    }

    Write-Host "Dry-run: GET $Uri" -ForegroundColor Yellow

    # Mock responses for testing logic
    if ($Uri -like '*runs*') {
        return @{ value = @( [PSCustomObject]@{ createdDate = (Get-Date).AddDays(-1); result = 'succeeded' } ) }
    }
    if ($Uri -like '*build/definitions*') {
        return [PSCustomObject]@{ queue = @{ pool = @{ id = 1 } } }
    }
    if ($Uri -like '*_apis/pipelines*') {
        return @{ value = @( [PSCustomObject]@{
            id = 100; name = 'DemoPipeline'; folder = '\\';
            _links = @{ web = @{ href = 'https://dev.azure.com/dummy' } }
        }) }
    }
    if ($Uri -like '*distributedtask/pools/*/agents*') {
        return @{ value = @( [PSCustomObject]@{
            id = 101; name = 'mac-agent-1'; osDescription = 'Darwin';
            status = 'online'; enabled = $true; version = '2.202.1'
        }) }
    }
    if ($Uri -like '*distributedtask/pools*') {
        return @{ value = @( [PSCustomObject]@{ id = 1; name = 'Default' }) }
    }
    if ($Uri -like '*_apis/projects*') {
        return @{ value = @( [PSCustomObject]@{ id = 'proj1'; name = 'DemoProject' }) }
    }

    return @{ value = @() }
}

Write-Host "=== Azure DevOps Agent and Pipeline Query (All Projects) ===" -ForegroundColor Cyan
Write-Host "Organization: $organization`n" -ForegroundColor White

# ------------------------------------------------------------
# Get all projects
# ------------------------------------------------------------
Write-Host "Fetching all projects..." -ForegroundColor Cyan
$projectsUrl = "$orgBaseUrl/projects?api-version=7.0"

try {
    $projects = (Get-Api $projectsUrl).value
    Write-Host "Found $($projects.Count) projects`n" -ForegroundColor Green
}
catch {
    Write-Error "Failed to fetch projects: $($_.Exception.Message)"
    exit 1
}

# ------------------------------------------------------------
# Get all agent pools
# ------------------------------------------------------------
Write-Host "Fetching agent pools..." -ForegroundColor Cyan
$poolsUrl = "$orgBaseUrl/distributedtask/pools?api-version=7.0"

try {
    $pools = (Get-Api $poolsUrl).value
    Write-Host "Found $($pools.Count) agent pools`n" -ForegroundColor Green
}
catch {
    Write-Error "Failed to fetch agent pools: $($_.Exception.Message)"
    exit 1
}

# ------------------------------------------------------------
# Discover agents by OS (macOS & Windows Server 2019)
# ------------------------------------------------------------
$macAgents = @()
$server2019Agents = @()

foreach ($pool in $pools) {
    Write-Host "Checking pool: $($pool.name) (ID: $($pool.id))" -ForegroundColor Yellow
    $agentsUrl = "$orgBaseUrl/distributedtask/pools/$($pool.id)/agents?includeCapabilities=true&api-version=7.0"

    try {
        $agents = (Get-Api $agentsUrl).value

        foreach ($agent in $agents) {

            $osDescription = $agent.osDescription

            # Detect macOS agents
            if ($osDescription -match "Darwin|macOS|Mac OS X|OSX") {
                $macAgents += [PSCustomObject]@{
                    PoolName  = $pool.name
                    PoolId    = $pool.id
                    AgentName = $agent.name
                    AgentId   = $agent.id
                    OS        = $osDescription
                    Status    = $agent.status
                    Enabled   = $agent.enabled
                    Version   = $agent.version
                }
                Write-Host "  Found macOS agent: $($agent.name)" -ForegroundColor Green
            }

            # Detect Windows Server 2019 agents
            if ($osDescription -match "Windows Server 2019|Microsoft Windows 10\.0\.17763|Windows.*17763") {
                $server2019Agents += [PSCustomObject]@{
                    PoolName  = $pool.name
                    PoolId    = $pool.id
                    AgentName = $agent.name
                    AgentId   = $agent.id
                    OS        = $osDescription
                    Status    = $agent.status
                    Enabled   = $agent.enabled
                    Version   = $agent.version
                }
                Write-Host "  Found Server 2019 agent: $($agent.name)" -ForegroundColor Green
            }
        }

    }
    catch {
        Write-Warning "Could not access agents in pool '${pool.name}': $($_.Exception.Message)"
    }
}

# ------------------------------------------------------------
# Show discovered agents
# ------------------------------------------------------------
Write-Host "`n=== macOS Agents Found: $($macAgents.Count) ===" -ForegroundColor Green
if ($macAgents.Count -gt 0) { $macAgents | Format-Table -AutoSize }

Write-Host "`n=== Windows Server 2019 Agents Found: $($server2019Agents.Count) ===" -ForegroundColor Green
if ($server2019Agents.Count -gt 0) { $server2019Agents | Format-Table -AutoSize }

# Exit if nothing found
if ($macAgents.Count -eq 0 -and $server2019Agents.Count -eq 0) {
    Write-Host "`nNo target agents found. Exiting." -ForegroundColor Yellow
    exit 0
}

$targetPoolIds = ($macAgents + $server2019Agents).PoolId | Select-Object -Unique

# ------------------------------------------------------------
# Scan all pipelines across all projects
# ------------------------------------------------------------
$allPipelinesUsingTargetAgents = @()
$projectCount = 0
$totalPipelines = 0

foreach ($project in $projects) {

    $projectCount++
    $projectName = $project.name
    $projectId = $project.id

    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "PROJECT $projectCount/$($projects.Count): ${projectName} (ID: ${projectId})" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan

    $projectBaseUrl = "https://dev.azure.com/$organization/$projectName/_apis"
    $pipelinesUrl = "$projectBaseUrl/pipelines?api-version=7.0"

    try {
        $pipelines = (Get-Api $pipelinesUrl).value
        $totalPipelines += $pipelines.Count
        Write-Host "Found $($pipelines.Count) pipelines in this project" -ForegroundColor Yellow

        if ($pipelines.Count -eq 0) { continue }

        foreach ($pipeline in $pipelines) {

            Write-Host "  Checking: $($pipeline.name)" -ForegroundColor Gray
            $pipelineId = $pipeline.id

            try {
                # Get build definition for pool information
                $buildDefUrl = "$projectBaseUrl/build/definitions/$pipelineId?api-version=7.0"
                $buildDef = Get-Api $buildDefUrl

                if ($buildDef.queue.pool.id) {

                    $poolId = $buildDef.queue.pool.id

                    if ($targetPoolIds -contains $poolId) {
                        $poolName = ($pools | Where-Object { $_.id -eq $poolId }).name
                        $agentType = if ($macAgents.PoolId -contains $poolId) { "macOS" }
                                     elseif ($server2019Agents.PoolId -contains $poolId) { "Windows Server 2019" }
                                     else { "Mixed/Unknown" }

                        # Get latest pipeline run
                        $latestRun = $null
                        $latestRunResult = $null
                        try {
                            $runsUrl = "$projectBaseUrl/pipelines/$pipelineId/runs?`$top=1&api-version=7.0"
                            $runs = (Get-Api $runsUrl).value
                            if ($runs.Count -gt 0) {
                                $latestRun = $runs[0].createdDate
                                $latestRunResult = $runs[0].result
                            }
                        }
                        catch {}

                        # Record the pipeline
                        $allPipelinesUsingTargetAgents += [PSCustomObject]@{
                            ProjectName   = $projectName
                            ProjectId     = $projectId
                            PipelineName  = $pipeline.name
                            PipelineId    = $pipeline.id
                            PoolName      = $poolName
                            PoolId        = $poolId
                            AgentType     = $agentType
                            LastRun       = $latestRun
                            LastRunResult = $latestRunResult
                            PipelineUrl   = ($pipeline._links.web.href -as [string])
                            FolderPath    = $pipeline.folder
                        }

                        Write-Host "    ✓ MATCH: Uses $agentType pool ($poolName)" -ForegroundColor Green
                    }
                }
            }
            catch {
                Write-Warning "    Could not process pipeline '${pipeline.name}': $($_.Exception.Message)"
            }
        }
    }
    catch {
        Write-Warning "Could not fetch pipelines for ${projectName}: $($_.Exception.Message)"
    }
}

# ------------------------------------------------------------
# Display Final Results
# ------------------------------------------------------------
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "FINAL RESULTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

Write-Host "`n=== Pipelines Using Target Agents: $($allPipelinesUsingTargetAgents.Count) ===" -ForegroundColor Green
if ($allPipelinesUsingTargetAgents.Count -gt 0) {
    $allPipelinesUsingTargetAgents | Format-Table -Property ProjectName, PipelineName, PoolName, AgentType, LastRun, LastRunResult -AutoSize -Wrap
}

# ------------------------------------------------------------
# Export Results
# ------------------------------------------------------------
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$exportPath = ".\AzDO_MultiProject_Export_$timestamp"

New-Item -ItemType Directory -Path $exportPath -Force | Out-Null
Write-Host "`nExporting results to: $exportPath" -ForegroundColor Cyan

if ($macAgents.Count -gt 0) {
    $macAgents | Export-Csv -Path "$exportPath\MacAgents.csv" -NoTypeInformation
}
if ($server2019Agents.Count -gt 0) {
    $server2019Agents | Export-Csv -Path "$exportPath\Server2019Agents.csv" -NoTypeInformation
}
if ($allPipelinesUsingTargetAgents.Count -gt 0) {

    # Export master list
    $allPipelinesUsingTargetAgents |
        Export-Csv -Path "$exportPath\PipelinesUsingTargetAgents_AllProjects.csv" -NoTypeInformation

    # Export per-project lists
    $projectGroups = $allPipelinesUsingTargetAgents | Group-Object -Property ProjectName
    foreach ($group in $projectGroups) {
        $safeProjectName = $group.Name -replace '[\\/:*?"<>|]', '_'
        $group.Group | Export-Csv -Path "$exportPath\Pipelines_$safeProjectName.csv" -NoTypeInformation
    }
}

# ------------------------------------------------------------
# Create Summary Report
# ------------------------------------------------------------
$summaryReport = @(
    "Azure DevOps Agent and Pipeline Analysis Report"
    "Generated: {0}"
    "Organization: {1}"
    ""
    "AGENT SUMMARY:"
    "- macOS Agents: {2}"
    "- Windows Server 2019 Agents: {3}"
    "- Total Target Agents: {4}"
    ""
    "PROJECT SUMMARY:"
    "- Total Projects Scanned: {5}"
    "- Total Pipelines Scanned: {6}"
    "- Pipelines Using Target Agents: {7}"
    ""
    "AFFECTED PROJECTS:"
    "{8}"
    ""
    "AGENT POOLS IN USE:"
    "{9}"
) -join "`n"


# Apply the formatter to substitute placeholders safely
$summaryReport = $summaryReport -f `
    (Get-Date -Format "yyyy-MM-dd HH:mm:ss"),
    $organization,
    $macAgents.Count,
    $server2019Agents.Count,
    ($macAgents.Count + $server2019Agents.Count),
    $projects.Count,
    $totalPipelines,
    $allPipelinesUsingTargetAgents.Count,
    ($allPipelinesUsingTargetAgents | Group-Object ProjectName |
        ForEach-Object { "- $($_.Name): $($_.Count) pipelines" } | Out-String),
    ($allPipelinesUsingTargetAgents | Group-Object PoolName |
        ForEach-Object { "- $($_.Name): $($_.Count) pipelines" } | Out-String)

$summaryReport | Out-File -FilePath "$exportPath\Summary_Report.txt" -Encoding UTF8

# ------------------------------------------------------------
# Final Summary Output
# ------------------------------------------------------------
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Projects Scanned: $($projects.Count)" -ForegroundColor White
Write-Host "Total Pipelines Scanned: $totalPipelines" -ForegroundColor White
Write-Host "macOS Agents: $($macAgents.Count)" -ForegroundColor White
Write-Host "Windows Server 2019 Agents: $($server2019Agents.Count)" -ForegroundColor White
Write-Host "Pipelines Using Target Agents: $($allPipelinesUsingTargetAgents.Count)" -ForegroundColor White
Write-Host "`nExport Location: $exportPath" -ForegroundColor Yellow
Write-Host "`nDone!" -ForegroundColor Green
