param(
    # Organization URL
    [string]$OrgUrl        = "https://dev.azure.com/aha-bt",

    # Output files (a short unique suffix is auto-appended to each)
    [string]$OutFile       = ".\AgentOS_Results_AllAgents.csv",
    [string]$UsageOutFile  = ".\Agent_Job_Usage.csv",

    # Window and options
    [int]   $DaysBack      = 90,       # 90-day window
    [bool]  $ResolveBuilds = $true,    # requires Build(Read) scope if $true

    # PAT source
    [string]$PatEnvVar     = "AZDO_PAT",
    [bool]  $PromptIfMissing = $true
)

$ErrorActionPreference = "Stop"

# --------------------- Unique filename helpers ---------------------
function Add-ShortEntropySuffix {
    param([Parameter(Mandatory)][string]$Path)
    $dir  = Split-Path -Parent $Path
    $name = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    $ext  = [System.IO.Path]::GetExtension($Path)
    $token = ([System.IO.Path]::GetRandomFileName() -replace '\W','').Substring(0,6)
    Join-Path $dir ($name + '_' + $token + $ext)
}
function New-UniquePath {
    param([Parameter(Mandatory)][string]$Path)
    do { $candidate = Add-ShortEntropySuffix -Path $Path }
    while (Test-Path -LiteralPath $candidate)
    $candidate
}

# --------------------- PAT (no hardcoding) ---------------------
function Get-PatFromEnv {
    param([string]$Name)
    $p = [Environment]::GetEnvironmentVariable($Name, 'Process')
    if ([string]::IsNullOrWhiteSpace($p)) { $p = [Environment]::GetEnvironmentVariable($Name, 'User') }
    if ([string]::IsNullOrWhiteSpace($p)) { $p = [Environment]::GetEnvironmentVariable($Name, 'Machine') }
    return $p
}
function ConvertFrom-SecureStringPlain {
    param([Security.SecureString]$Secure)
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}
$PAT = Get-PatFromEnv -Name $PatEnvVar
if ([string]::IsNullOrWhiteSpace($PAT)) {
    if ($PromptIfMissing) {
        Write-Host "PAT not found in env var '$PatEnvVar'. Prompting..."
        $sec = Read-Host -AsSecureString "Enter Azure DevOps PAT"
        $PAT = ConvertFrom-SecureStringPlain $sec
    } else {
        throw "PAT not found in env var '$PatEnvVar'. Set it (e.g., `setx $PatEnvVar '<pat>'`) and re-run."
    }
}

# --------------------- Auth header ---------------------
$base64Auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT"))
$headers = @{
    Authorization           = "Basic $base64Auth"
    Accept                  = "application/json"
    "X-TFS-FedAuthRedirect" = "Suppress"
}

# --------------------- HTTP helper ---------------------
function Invoke-Get {
    param([string]$Url, [int]$Retries = 3)
    for ($i=0; $i -lt $Retries; $i++) {
        try { return Invoke-RestMethod -Headers $headers -Method GET -Uri $Url -TimeoutSec 90 }
        catch {
            if ($i -eq $Retries-1) {
                $status=$null;$reason=$null;$body=$null
                try { $status=$_.Exception.Response.StatusCode.value__; $reason=$_.Exception.Response.StatusDescription } catch {}
                try { $sr=New-Object IO.StreamReader($_.Exception.Response.GetResponseStream()); $body=$sr.ReadToEnd() } catch {}
                throw "GET $Url failed: $status $reason`n$body"
            }
            Start-Sleep -Seconds (2 * $i + 1)
        }
    }
}

# --------------------- Projects (for name resolution) ---------------------
function Get-AllProjects {
    $projects = @()
    $skip = 0
    while ($true) {
        $url = "$OrgUrl/_apis/projects?stateFilter=All&`$top=100&`$skip=$skip&api-version=7.1"
        $paged = Invoke-Get $url
        if ($paged -and $paged.value) { $projects += $paged.value }
        if ($paged -and $paged.value -and $paged.value.Count -ge 100) { $skip += 100 } else { break }
    }
    return $projects
}

# --------------------- Window ---------------------
$since = (Get-Date).AddDays(-[math]::Abs($DaysBack))

# --------------------- 1) Pools ---------------------
Write-Host "Fetching agent pools..."
# Requires Agent Pools (Read) scope
# GET {org}/_apis/distributedtask/pools?api-version=7.1  (doc)  [1](https://www.coachdevops.com/2023/01/how-to-create-personal-access-token-use.html)
$pools = Invoke-Get "$OrgUrl/_apis/distributedtask/pools?api-version=7.1"

# Project dictionary
$projById = @{}
Get-AllProjects | ForEach-Object { $projById[$_.id] = $_.name }

# Outputs
$inventory = New-Object System.Collections.Generic.List[object]
$usage     = New-Object System.Collections.Generic.List[object]
$_lastUsedByAgent = @{}   # AgentId -> [datetime] last used

# --------------------- 2) Agents per pool ---------------------
foreach ($pool in $pools.value) {
    Write-Host "Scanning pool: $($pool.name)"

    # Agents: include capabilities + current/last request pointers  (doc)  [2](https://stackoverflow.com/questions/714877/setting-windows-powershell-environment-variables)
    $agentsUrl = "$OrgUrl/_apis/distributedtask/pools/$($pool.id)/agents?includeCapabilities=true&includeAssignedRequest=true&includeLastCompletedRequest=true&api-version=7.1"
    $agents    = Invoke-Get $agentsUrl

    foreach ($agent in $agents.value) {
        # Safe capability reads
        $osFamily  = $null; $osVersion = $null
        if ($agent.PSObject.Properties['systemCapabilities']) {
            $osFamily  = $agent.systemCapabilities['Agent.OS']
            $osVersion = $agent.systemCapabilities['Agent.OSVersion']
        }
        $lastReqId = $null
        if ($agent.PSObject.Properties['lastCompletedRequest'] -and
            $agent.lastCompletedRequest.PSObject.Properties['requestId']) {
            $lastReqId = $agent.lastCompletedRequest.requestId
        }
        $currReqId = $null
        if ($agent.PSObject.Properties['assignedRequest'] -and
            $agent.assignedRequest.PSObject.Properties['requestId']) {
            $currReqId = $agent.assignedRequest.requestId
        }

        $inventory.Add([pscustomobject]@{
            # Your original columns
            PoolName    = $pool.name
            AgentName   = $agent.name
            OS          = $agent.osDescription
            Status      = $agent.status
            Enabled     = $agent.enabled
            Version     = $agent.version
            LastOnline  = $agent.lastOnline
            # Extras
            IsHosted    = [bool]$pool.isHosted
            AgentId     = $agent.id
            PoolId      = $pool.id
            OSFamily    = $osFamily
            OSVersion   = $osVersion
            LastReqId   = $lastReqId
            CurrReqId   = $currReqId
            LastUsedUtc = $null   # filled later
        })
    }

    # --------------------- 3) Usage via jobrequests ---------------------
    # Practical feed to correlate pool/agent usage → runs (used in MS answers)  [3](https://www.azuredevopsguide.com/personal-access-tokens-in-azure-devops/)
    $jobsUrl = "$OrgUrl/_apis/distributedtask/pools/$($pool.id)/jobrequests?api-version=7.1"
    try { $jobs = Invoke-Get $jobsUrl } catch { Write-Warning "jobrequests not available for pool $($pool.name): $($_.Exception.Message)"; $jobs = @{ value = @() } }

    foreach ($j in $jobs.value | Where-Object { $_.queueTime -ge $since }) {

        # Null-safe extraction
        $projectId = $null
        if ($j.PSObject.Properties['project'] -and $j.project.PSObject.Properties['id']) { $projectId = $j.project.id }

        $defId   = $null; $defName = $null
        if ($j.PSObject.Properties['definition']) {
            if ($j.definition.PSObject.Properties['id'])   { $defId   = $j.definition.id }
            if ($j.definition.PSObject.Properties['name']) { $defName = $j.definition.name }
        }

        $runId = $null
        if ($j.PSObject.Properties['owner'] -and $j.owner.PSObject.Properties['id']) { $runId = $j.owner.id }

        $agentId = $null
        if ($j.PSObject.Properties['agent'] -and $j.agent.PSObject.Properties['id']) { $agentId = $j.agent.id }

        $project = $null
        if ($projectId) {
            if ($projById.ContainsKey($projectId)) { $project = $projById[$projectId] } else { $project = $projectId }
        }

        # Optional build enrichment (requires Build Read).  [4](https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops)
        $buildDef=$null; $buildNum=$null; $buildWeb=$null
        if ($ResolveBuilds -and $runId -and $project) {
            $projSeg = [uri]::EscapeDataString($project)
            $bUrl = "$OrgUrl/$projSeg/_apis/build/builds/$runId?api-version=7.1"
            try {
                $b = Invoke-Get $bUrl
                if ($b -and $b.PSObject.Properties['definition'] -and $b.definition.PSObject.Properties['name']) { $buildDef = $b.definition.name }
                if ($b -and $b.PSObject.Properties['buildNumber']) { $buildNum = $b.buildNumber }
                if ($b -and $b.PSObject.Properties['_links'] -and $b._links.PSObject.Properties['web'] -and $b._links.web.PSObject.Properties['href']) { $buildWeb = $b._links.web.href }
            } catch { }
        }

        # Best timestamp for "last used": prefer finish, else start, else queue
        $tsFinish = $null
        if ($j.PSObject.Properties['finishTime']) { $tsFinish = [datetime]$j.finishTime }
        elseif ($j.PSObject.Properties['startTime']) { $tsFinish = [datetime]$j.startTime }
        else { $tsFinish = [datetime]$j.queueTime }

        if ($agentId) {
            if (-not $_lastUsedByAgent.ContainsKey($agentId)) { $_lastUsedByAgent[$agentId] = $tsFinish }
            elseif ($tsFinish -gt $_lastUsedByAgent[$agentId]) { $_lastUsedByAgent[$agentId] = $tsFinish }
        }

        $usage.Add([pscustomobject]@{
            PoolId         = $pool.id
            PoolName       = $pool.name
            IsHosted       = [bool]$pool.isHosted
            AgentId        = $agentId
            ProjectId      = $projectId
            Project        = $project
            DefinitionId   = $defId
            Definition     = if ($buildDef) { $buildDef } else { $defName }
            RunId          = $runId
            BuildNumber    = $buildNum
            BuildLink      = $buildWeb
            QueueTime      = $j.queueTime
            StartTime      = $j.startTime
            FinishTime     = $j.finishTime
            Result         = $j.result
            ParallelismTag = $j.parallelismTag
        })
    }
}

# --------------------- 4) Inject LastUsedUtc into inventory ---------------------
for ($i = 0; $i -lt $inventory.Count; $i++) {
    $row = $inventory[$i]
    $lastUsed = $null
    if ($row.AgentId -and $_lastUsedByAgent.ContainsKey($row.AgentId)) { $lastUsed = $_lastUsedByAgent[$row.AgentId] }

    $inventory[$i] = [pscustomobject]@{
        PoolName    = $row.PoolName
        AgentName   = $row.AgentName
        OS          = $row.OS
        Status      = $row.Status
        Enabled     = $row.Enabled
        Version     = $row.Version
        LastOnline  = $row.LastOnline
        IsHosted    = $row.IsHosted
        AgentId     = $row.AgentId
        PoolId      = $row.PoolId
        OSFamily    = $row.OSFamily
        OSVersion   = $row.OSVersion
        LastReqId   = $row.LastReqId
        CurrReqId   = $row.CurrReqId
        LastUsedUtc = $lastUsed
    }
}

# --------------------- 5) Export with unique filenames ---------------------
$OutFileUnique   = New-UniquePath -Path $OutFile
$UsageFileUnique = New-UniquePath -Path $UsageOutFile

Write-Host "Exporting inventory → $OutFileUnique"
$inventory | Sort-Object PoolName, AgentName | Export-Csv -NoTypeInformation -Path $OutFileUnique

Write-Host "Exporting usage → $UsageFileUnique"
$usage     | Sort-Object PoolName, QueueTime | Export-Csv -NoTypeInformation -Path $UsageFileUnique

Write-Host "Done."