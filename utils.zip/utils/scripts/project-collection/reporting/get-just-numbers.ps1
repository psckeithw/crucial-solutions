# Azure DevOps Metrics Snapshot
# Pulls current and 6-month-old metrics for all monitored projects
# Outputs: *old.csv (6 months ago) and *new.csv (today)

param(
    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = "C:\code\Niche Sandbox\utils\scripts\project-collection\output"
)

# Projects to monitor
$MonitoredProjects = @(
    'Azure Cloud Remediation',
    'Azure Cloud Infrastructure',
    'BT-Finance',
    'CDO',
    'CN Redesign'
    'CampaignAnalytics',
    'Copyright Website',
    'Cybersec Team',
    'DataWarehouse-OSO',
    'Dig Ops Support',
    'Digital Multimedia',
    'Digital Program Operations',
    'Direct Response Monthly Campaigns',
    'ECC Sales DB Process Improvement Project',
    'Fit Challenge',
    'Front-End',
    'Fundraising Systems Development',
    'HC Redesign',
    'HR Systems',
    'Heartitude',
    'IPAD Heart Check Re-write',
    'Instructor Network',
    'Liive',
    'Living Guidelines Implementation',
    'MS Dynamics',
    'Niche Sandbox',
    'OSO DataStore',
    'OneHeart Datawarehouse',
    'Oracle Integration Cloud (OIC)',
    'PHD DOTNET',
    'ProfessionalHeartDaily',
    'Quality Initiatives',
    'Rewards Redemption',
    'Salesforce Program',
    'SalesforceCSP',
    'School Management Tool',
    'SharePoint',
    'Shared Requirements',
    'SingleSignOn',
    'Youth Market'
    'Social Events',
    'WordPress',
    'Youth Market'
)

# Date ranges
$today = Get-Date
$sixMonthsAgo = $today.AddMonths(-6)

Write-Host "Current date: $($today.ToString('yyyy-MM-dd'))"
Write-Host "6 months ago: $($sixMonthsAgo.ToString('yyyy-MM-dd'))"
Write-Host "Projects: $($MonitoredProjects.Count)"
Write-Host ""

# Ensure output folder exists
if (-not (Test-Path $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder | Out-Null
}

# Get all projects from Azure DevOps
$projectData = az devops project list 2>$null | ConvertFrom-Json
$projectsToProcess = @($projectData.value | Where-Object { $MonitoredProjects -contains $_.name })

Write-Host "Processing $($projectsToProcess.Count) projects.."

$oldResults = @()
$newResults = @()
$counter = 0



# Track all unique users across all projects (past and present)
$allPastUsers = @{}
$allCurrentUsers = @{}
# Track all unique project members (across all projects)
$allProjectMembers = @{}

foreach ($project in $projectsToProcess) {
    $counter++
    Write-Progress -Activity "Collecting Metrics" -Status "$counter of $($projectsToProcess.Count) - $($project.name)" `
        -PercentComplete (($counter / $projectsToProcess.Count) * 100)

    try {
        $oldReport = [PSCustomObject]@{
            ProjectName     = $project.name
            Commits_Past    = 0
            ActiveUsers     = 0
            RepoSize_MB     = 0
            PipelineMinutes = 0
            ArtifactStorage = 0
        }

        $newReport = [PSCustomObject]@{
            ProjectName     = $project.name
            Commits_Past    = 0
            ActiveUsers     = 0
            RepoSize_MB     = 0
            PipelineMinutes = 0
            ArtifactStorage = 0
        }

        # === PROJECT MEMBERS ===
        try {
            $members = az devops team list --project $project.id --output json 2>$null | ConvertFrom-Json
            if ($members.value) {
                foreach ($team in $members.value) {
                    $teamMembers = az devops team member list --project $project.id --team $team.id --output json 2>$null | ConvertFrom-Json
                    if ($teamMembers.value) {
                        foreach ($user in $teamMembers.value) {
                            if ($user.identity.uniqueName) {
                                $allProjectMembers[$user.identity.uniqueName] = $true
                            }
                        }
                    }
                }
            }
        }
        catch {}

        # === REPOS & COMMITS ===
        try {
            $repos = az repos list --project $project.id 2>$null | ConvertFrom-Json
            if ($repos) {
                $oldCommits = 0
                $newCommits = 0
                $oldContributors = @{}
                $newContributors = @{}
                $totalRepoSize = 0

                foreach ($repo in $repos) {
                    # Get current repo size
                    try {
                        $repoDetails = az devops invoke --area git --resource repositories `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters api-version=7.1 -o json 2>$null | ConvertFrom-Json
                        if ($repoDetails.size) { $totalRepoSize += $repoDetails.size }
                    }
                    catch {}

                    # Get commits - OLD (6 months ago to 1 month ago)
                    try {
                        $oldFromDate = $sixMonthsAgo.ToString('MM/dd/yyyy')
                        $oldToDate = $sixMonthsAgo.AddMonths(1).ToString('MM/dd/yyyy')
                        $oldCommitsJson = az devops invoke --area git --resource commits `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters "searchCriteria.fromDate=$oldFromDate" "searchCriteria.toDate=$oldToDate" "api-version=7.1" `
                            -o json 2>$null | ConvertFrom-Json
                        if ($oldCommitsJson.value) {
                            $oldCommits += $oldCommitsJson.value.Count
                            foreach ($commit in $oldCommitsJson.value) {
                                if ($commit.author.email) {
                                    $oldContributors[$commit.author.email] = $true
                                    $allPastUsers[$commit.author.email] = $true
                                }
                            }
                        }
                    }
                    catch {}

                    # Get commits - NEW (last 30 days)
                    try {
                        $newFromDate = $today.AddDays(-30).ToString('MM/dd/yyyy')
                        $newToDate = $today.ToString('MM/dd/yyyy')
                        $newCommitsJson = az devops invoke --area git --resource commits `
                            --route-parameters project="$($project.id)" repositoryId="$($repo.id)" `
                            --query-parameters "searchCriteria.fromDate=$newFromDate" "searchCriteria.toDate=$newToDate" "api-version=7.1" `
                            -o json 2>$null | ConvertFrom-Json
                        if ($newCommitsJson.value) {
                            $newCommits += $newCommitsJson.value.Count
                            foreach ($commit in $newCommitsJson.value) {
                                if ($commit.author.email) {
                                    $newContributors[$commit.author.email] = $true
                                    $allCurrentUsers[$commit.author.email] = $true
                                }
                            }
                        }
                    }
                    catch {}
                }
                
                $oldReport.Commits_Past = [Math]::Max(0, $oldCommits)
                $newReport.Commits_Past = [Math]::Max(0, $newCommits)
                $oldReport.ActiveUsers = [Math]::Max(0, $oldContributors.Count)
                $newReport.ActiveUsers = [Math]::Max(0, $newContributors.Count)
                $repoSizeMB = [math]::Round($totalRepoSize / 1MB, 2)
                $newReport.RepoSize_MB = [Math]::Max(0, $repoSizeMB)
                $oldReport.RepoSize_MB = [Math]::Max(0, $repoSizeMB)  # Assume repo size similar Previous
            }

        }
        catch {}

        # === PIPELINES & BUILDS ===
        try {
            $oldBuilds = 0
            $oldSucceeded = 0
            $oldMinutes = 0
            $newBuilds = 0
            $newSucceeded = 0
            $newMinutes = 0

            $builds = az pipelines runs list --project $project.id --top 1000 2>$null | ConvertFrom-Json
            if ($builds) {
                foreach ($build in $builds) {
                    if ($build.finishTime) {
                        $finishTime = [DateTime]$build.finishTime
                        
                        # OLD: 6 months ago to 1 month ago
                        if ($finishTime -ge $sixMonthsAgo -and $finishTime -lt $sixMonthsAgo.AddMonths(1)) {
                            $oldBuilds++
                            if ($build.result -eq 'succeeded') { $oldSucceeded++ }
                            if ($build.startTime) {
                                $duration = ($finishTime - [DateTime]$build.startTime).TotalMinutes
                                $oldMinutes += $duration
                            }
                        }
                        
                        # NEW: Last 30 days
                        if ($finishTime -ge $today.AddDays(-30)) {
                            $newBuilds++
                            if ($build.result -eq 'succeeded') { $newSucceeded++ }
                            if ($build.startTime) {
                                $duration = ($finishTime - [DateTime]$build.startTime).TotalMinutes
                                $newMinutes += $duration
                            }
                        }
                    }
                }
            }

            $oldReport.PipelineMinutes = [Math]::Max(0, [math]::Round($oldMinutes, 0))
            $newReport.PipelineMinutes = [Math]::Max(0, [math]::Round($newMinutes, 0))
        }
        catch {}

        $oldResults += $oldReport
        $newResults += $newReport

    }
    catch {
        Write-Host "ERROR: $($project.name) - $($_.Exception.Message)"
        continue
    }
}

Write-Progress -Activity "Collecting Metrics" -Completed

# Export results
# $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
#TODO add this timestamp back and del then copy these 
# $previousPath = Join-Path $OutputFolder "metrics-previous-$timestamp.csv"
# $currentPath  = Join-Path $OutputFolder "metrics-current-$timestamp.csv"
$previousPath = Join-Path $OutputFolder "metrics-previous.csv"
$currentPath = Join-Path $OutputFolder "metrics-current.csv"

$oldResults | Export-Csv -Path $previousPath -NoTypeInformation
$newResults | Export-Csv -Path $currentPath -NoTypeInformation
Write-Host "Previous metrics: $previousPath"
Write-Host "Current metrics:  $currentPath"

# Calculate total sums across all projects (negative values treated as zero for growth)
Write-Host "Calculating total metrics across all projects..."

$totalOldCommits = [Math]::Max(0, ($oldResults | ForEach-Object { if ($null -eq $_.Commits_Past -or $_.Commits_Past -lt 0) { 0 } else { [int]$_.Commits_Past } } | Measure-Object -Sum).Sum)
$totalNewCommits = [Math]::Max(0, ($newResults | ForEach-Object { if ($null -eq $_.Commits_Past -or $_.Commits_Past -lt 0) { 0 } else { [int]$_.Commits_Past } } | Measure-Object -Sum).Sum)


# Per-project active users (sum)
$totalOldActiveUsers = [Math]::Max(0, ($oldResults | ForEach-Object { if ($null -eq $_.ActiveUsers -or $_.ActiveUsers -lt 0) { 0 } else { [int]$_.ActiveUsers } } | Measure-Object -Sum).Sum)
$totalNewActiveUsers = [Math]::Max(0, ($newResults | ForEach-Object { if ($null -eq $_.ActiveUsers -or $_.ActiveUsers -lt 0) { 0 } else { [int]$_.ActiveUsers } } | Measure-Object -Sum).Sum)



# Unique users across all projects (collection-wide)
$uniquePastUsers = $allPastUsers.Keys.Count
$uniqueCurrentUsers = $allCurrentUsers.Keys.Count

# Get all collection users (organization-level)
$collectionUsers = @{}
try {
    $usersResult = az devops user list --output json 2>$null | ConvertFrom-Json
    if ($usersResult.members) {
        foreach ($user in $usersResult.members) {
            if ($user.user.principalName) {
                $collectionUsers[$user.user.principalName] = $true
            }
        }
    }
}
catch {}
$uniqueCollectionUsers = $collectionUsers.Keys.Count

$totalOldRepoSize = [Math]::Max(0, ($oldResults | ForEach-Object { if ($null -eq $_.RepoSize_MB -or $_.RepoSize_MB -lt 0) { 0 } else { [double]$_.RepoSize_MB } } | Measure-Object -Sum).Sum)
$totalNewRepoSize = [Math]::Max(0, ($newResults | ForEach-Object { if ($null -eq $_.RepoSize_MB -or $_.RepoSize_MB -lt 0) { 0 } else { [double]$_.RepoSize_MB } } | Measure-Object -Sum).Sum)

$totalOldPipelineMinutes = [Math]::Max(0, ($oldResults | ForEach-Object { if ($null -eq $_.PipelineMinutes -or $_.PipelineMinutes -lt 0) { 0 } else { [double]$_.PipelineMinutes } } | Measure-Object -Sum).Sum)
$totalNewPipelineMinutes = [Math]::Max(0, ($newResults | ForEach-Object { if ($null -eq $_.PipelineMinutes -or $_.PipelineMinutes -lt 0) { 0 } else { [double]$_.PipelineMinutes } } | Measure-Object -Sum).Sum)

$totalOldArtifactStorage = [Math]::Max(0, ($oldResults | ForEach-Object { if ($null -eq $_.ArtifactStorage -or $_.ArtifactStorage -lt 0) { 0 } else { [double]$_.ArtifactStorage } } | Measure-Object -Sum).Sum)
$totalNewArtifactStorage = [Math]::Max(0, ($newResults | ForEach-Object { if ($null -eq $_.ArtifactStorage -or $_.ArtifactStorage -lt 0) { 0 } else { [double]$_.ArtifactStorage } } | Measure-Object -Sum).Sum)

$totalResults = @(
    [PSCustomObject]@{
        Metric        = 'Commits'
        Total_Past    = $totalOldCommits
        Total_Current = $totalNewCommits
    },
    [PSCustomObject]@{
        Metric        = 'ActiveGitUsers'
        Total_Past    = $totalOldActiveUsers
        Total_Current = $totalNewActiveUsers
    },
    [PSCustomObject]@{
        Metric        = 'RepoSize_MB'
        Total_Past    = [math]::Round($totalOldRepoSize, 2)
        Total_Current = [math]::Round($totalNewRepoSize, 2)
    },
    [PSCustomObject]@{
        Metric        = 'PipelineMinutes'
        Total_Past    = [math]::Round($totalOldPipelineMinutes, 0)
        Total_Current = [math]::Round($totalNewPipelineMinutes, 0)
    },
    [PSCustomObject]@{
        Metric        = 'ArtifactStorage'
        Total_Past    = [math]::Round($totalOldArtifactStorage, 2)
        Total_Current = [math]::Round($totalNewArtifactStorage, 2)
    }
)

$totalPath = Join-Path $OutputFolder "TotalMetrics.csv"
$totalResults | Export-Csv -Path $totalPath -NoTypeInformation
Write-Host "Total metrics:    $totalPath"
Write-Host ""
Write-Host "TOTAL METRICS ACROSS ALL PROJECTS"
Write-Host "Commits (Previous): $totalOldCommits | Current: $totalNewCommits"
Write-Host "Active Git Users (Previous, per-project sum): $totalOldActiveUsers | Current: $totalNewActiveUsers"
Write-Host "Unique Git Users (collection-wide, Previous): $uniquePastUsers | Current: $uniqueCurrentUsers"
Write-Host "Repo Size MB (Previous): $([math]::Round($totalOldRepoSize, 2)) | Current: $([math]::Round($totalNewRepoSize, 2))"
Write-Host "Pipeline Minutes (Previous): $([math]::Round($totalOldPipelineMinutes, 0)) | Current: $([math]::Round($totalNewPipelineMinutes, 0))"
Write-Host "Artifact Storage (Previous): $([math]::Round($totalOldArtifactStorage, 2)) | Current: $([math]::Round($totalNewArtifactStorage, 2))"
Write-Host "Active Total Collection Users: $uniqueCollectionUsers"