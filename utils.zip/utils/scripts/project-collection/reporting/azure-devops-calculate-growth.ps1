# Azure DevOps Metrics Comparison
# Reads metrics-6mo-ago-*.csv and metrics-today-*.csv
# Calculates percentage changes and billable metrics
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
param(
    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = (Join-Path $PSScriptRoot "output")
)

Write-Host "Azure DevOps Metrics Comparison" -ForegroundColor Cyan

# Find the most recent old and new files
$oldFiles = Get-ChildItem -Path $OutputFolder -Filter "metrics-6mo-ago-*.csv" | Sort-Object LastWriteTime -Descending
$newFiles = Get-ChildItem -Path $OutputFolder -Filter "metrics-today-*.csv" | Sort-Object LastWriteTime -Descending

if (-not $oldFiles -or -not $newFiles) {
    Write-Host "ERROR: Could not find metrics CSV files in $OutputFolder" -ForegroundColor Red
    Write-Host "Make sure you've run azure-devops-metrics-snapshot.ps1 first" -ForegroundColor Yellow
    exit 1
}

$oldFile = $oldFiles[0].FullName
$newFile = $newFiles[0].FullName

Write-Host "Loading files:" -ForegroundColor Yellow
Write-Host "  Old: $([System.IO.Path]::GetFileName($oldFile))" -ForegroundColor Yellow
Write-Host "  New: $([System.IO.Path]::GetFileName($newFile))" -ForegroundColor Yellow

$oldData = Import-Csv $oldFile
$newData = Import-Csv $newFile

# Calculate growth percentages
$results = @()

foreach ($newProject in $newData) {
    $oldProject = $oldData | Where-Object { $_.ProjectName -eq $newProject.ProjectName }
    
    if ($oldProject) {
        $result = [PSCustomObject]@{
            ProjectName                  = $newProject.ProjectName
            Commits_Old                  = [int]$oldProject.Commits_6mo
            Commits_New                  = [int]$newProject.Commits_6mo
            Commits_Growth_%             = if ([int]$oldProject.Commits_6mo -ne 0) { 
                [math]::Round((([int]$newProject.Commits_6mo - [int]$oldProject.Commits_6mo) / [int]$oldProject.Commits_6mo) * 100, 2) 
            } else { 
                0 
            }
            Builds_Old                   = [int]$oldProject.Builds_6mo
            Builds_New                   = [int]$newProject.Builds_6mo
            Builds_Growth_%              = if ([int]$oldProject.Builds_6mo -ne 0) { 
                [math]::Round((([int]$newProject.Builds_6mo - [int]$oldProject.Builds_6mo) / [int]$oldProject.Builds_6mo) * 100, 2) 
            } else { 
                0 
            }
            SuccessRate_Old_%            = [double]$oldProject.'BuildSuccessRate_%'
            SuccessRate_New_%            = [double]$newProject.'BuildSuccessRate_%'
            SuccessRate_Change_%         = [math]::Round(([double]$newProject.'BuildSuccessRate_%' - [double]$oldProject.'BuildSuccessRate_%'), 2)
            ActiveUsers_Old              = [int]$oldProject.ActiveUsers
            ActiveUsers_New              = [int]$newProject.ActiveUsers
            ActiveUsers_Growth_%         = if ([int]$oldProject.ActiveUsers -ne 0) { 
                [math]::Round((([int]$newProject.ActiveUsers - [int]$oldProject.ActiveUsers) / [int]$oldProject.ActiveUsers) * 100, 2) 
            } else { 
                0 
            }
            RepoSize_MB_Old              = [double]$oldProject.RepoSize_MB
            RepoSize_MB_New              = [double]$newProject.RepoSize_MB
            RepoSize_Growth_%            = if ([double]$oldProject.RepoSize_MB -ne 0) { 
                [math]::Round((([double]$newProject.RepoSize_MB - [double]$oldProject.RepoSize_MB) / [double]$oldProject.RepoSize_MB) * 100, 2) 
            } else { 
                0 
            }
            PipelineMinutes_Old          = [double]$oldProject.PipelineMinutes
            PipelineMinutes_New          = [double]$newProject.PipelineMinutes
            PipelineMinutes_Growth_%     = if ([double]$oldProject.PipelineMinutes -ne 0) { 
                [math]::Round((([double]$newProject.PipelineMinutes - [double]$oldProject.PipelineMinutes) / [double]$oldProject.PipelineMinutes) * 100, 2) 
            } else { 
                0 
            }
        }
        
        $results += $result
    }
}

# Export comparison
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$comparisonPath = Join-Path $OutputFolder "growth-comparison-$timestamp.csv"
$results | Export-Csv -Path $comparisonPath -NoTypeInformation

# Display summary
Write-Host "=== GROWTH SUMMARY ===" -ForegroundColor Cyan
Write-Host "Top Growing Projects (by commits):" -ForegroundColor Yellow
$results | Sort-Object Commits_Growth_% -Descending | Select-Object -First 5 | 
    Format-Table ProjectName, Commits_Old, Commits_New, Commits_Growth_% -AutoSize

Write-Host "Top Growing Projects (by pipeline minutes):" -ForegroundColor Yellow
$results | Sort-Object PipelineMinutes_Growth_% -Descending | Select-Object -First 5 | 
    Format-Table ProjectName, PipelineMinutes_Old, PipelineMinutes_New, PipelineMinutes_Growth_% -AutoSize

Write-Host "Top Growing Projects (by active users):" -ForegroundColor Yellow
$results | Sort-Object ActiveUsers_Growth_% -Descending | Select-Object -First 5 | 
    Format-Table ProjectName, ActiveUsers_Old, ActiveUsers_New, ActiveUsers_Growth_% -AutoSize

Write-Host "Top Growing Projects (by repo size):" -ForegroundColor Yellow
$results | Sort-Object RepoSize_Growth_% -Descending | Select-Object -First 5 | 
    Format-Table ProjectName, RepoSize_MB_Old, RepoSize_MB_New, RepoSize_Growth_% -AutoSize

Write-Host "✓ Comparison complete" -ForegroundColor Green
Write-Host "  Results: $comparisonPath" -ForegroundColor Yellow

# Export full results for use
$results | Export-Csv -Path $comparisonPath -NoTypeInformation
