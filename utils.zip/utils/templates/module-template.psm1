#Requires -Version 7.0
<#
.SYNOPSIS
    Module name and brief description.
.DESCRIPTION
    Detailed description of what this module provides.
#>

#region Variables
$script:ModuleName = 'ModuleName'
#endregion

#region Functions

function Verb-Noun {
    <#
    .SYNOPSIS
        Short description of what this function does.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$Parameter1
    )

    # Function logic here
}

#endregion

#region Module Exports
Export-ModuleMember -Function @(
    'Verb-Noun'
)
#endregion
