$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{
    Authorization = "Basic $auth"
    'Content-Type' = 'application/json'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$testProject = "Supplier Collaboration System"

# Get IDs
$wiqlQuery = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = '$testProject'"
$url = "https://dev.azure.com/aha-bt/$([uri]::EscapeDataString($testProject))/_apis/wit/wiql?api-version=7.1"
$jsonBody = "{`n  `"query`": `"$wiqlQuery`"`n}"

$r = Invoke-RestMethod -Uri $url -Headers $headers -Method Post -Body $jsonBody -ContentType 'application/json'
$allIds = $r.workItems.id

Write-Host "Total IDs: $($allIds.Count)"

# Now test with chunk of 10 IDs using the FIXED format
$ids = $allIds | Select-Object -First 10

# FIXED format: comma-separated
$idsParam = "ids=" + ($ids -join ',')
$detailUrl = "https://dev.azure.com/aha-bt/$([uri]::EscapeDataString($testProject))/_apis/wit/workitems?$idsParam&`$fields=*"

Write-Host "Testing with fixed format (comma-separated)..."
$result = Invoke-RestMethod -Uri $detailUrl -Headers $headers

Write-Host "Requested: 10 IDs"
Write-Host "Got back: $($result.count) items"
Write-Host "SUCCESS: $($result.count -eq 10)"
