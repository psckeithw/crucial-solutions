#Requires -Version 7.0
<#
.SYNOPSIS
    Test Azure DevOps PAT authentication - consolidated script.

.DESCRIPTION
    Tests PAT connection to Azure DevOps. Resolves PAT from environment
    variables (Process → User → Machine) or prompts if -Prompt flag is used.

.PARAMETER Organization
    Azure DevOps organization name. Default: aha-bt

.PARAMETER Prompt
    Prompt for PAT if not found in environment variables.

.PARAMETER Verbose
    Show detailed output including full API response.

.EXAMPLE
    pwsh -File test-pat.ps1
    Quick test using AZDO_PAT environment variable.

.EXAMPLE
    pwsh -File test-pat.ps1 -Prompt
    Prompt for PAT if not in environment.

.EXAMPLE
    pwsh -File test-pat.ps1 -Organization myorg -Verbose
    Test different org with verbose output.

.NOTES
    Exit codes: 0 = success, 1 = failure
#>

[CmdletBinding()]
param(
    [Parameter()]
    [Alias('Org')]
    [string]$Organization = 'aha-bt',
    [Parameter()]
    [switch]$Prompt
)

#region Functions
function Write-Success { Write-Host "✓ $args" -ForegroundColor Green }
function Write-Fail { Write-Host "✗ $args" -ForegroundColor Red }
function Write-Info { Write-Host "  $args" -ForegroundColor Gray }
#endregion

Write-Host "=== Azure DevOps PAT Test ===" -ForegroundColor Cyan
Write-Host ""

#region Get PAT
$pat = $null
$patSource = $null

# Try Process scope first (current session)
$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
if ($pat) { $patSource = 'Process' }

# Try User scope
if (-not $pat) {
    $pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'User')
    if ($pat) { $patSource = 'User' }
}

# Try Machine scope
if (-not $pat) {
    $pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Machine')
    if ($pat) { $patSource = 'Machine' }
}

# Prompt if still not found and -Prompt flag is set
if (-not $pat -and $Prompt) {
    Write-Host "Enter your Azure DevOps PAT:" -ForegroundColor Yellow
    $sec = Read-Host -AsSecureString "PAT"
    $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    $pat = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    $patSource = 'Prompt'
}

# Still no PAT - error and exit
if (-not $pat) {
    Write-Fail "PAT not found in AZDO_PAT environment variable"
    Write-Info "Set it with: `$env:AZDO_PAT = '<your-pat>'"
    Write-Info "Or run with -Prompt to enter interactively"
    exit 1
}

# Clean and mask PAT
$pat = $pat.Trim().Trim('"')
$maskedPat = $pat.Substring(0, [Math]::Min(6, $pat.Length)) + '...<redacted>...' + $pat.Substring([Math]::Max(0, $pat.Length - 4))
Write-Host "PAT: $maskedPat (source: $patSource)" -ForegroundColor Yellow
#endregion

#region Test Connection
Write-Host ""
Write-Host "Testing connection to: dev.azure.com/$Organization" -ForegroundColor Yellow

# Build auth header
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{
    Authorization = "Basic $auth"
    'Content-Type' = 'application/json'
}

# Test 1: Connection data (validates PAT and identity)
$connectionUrl = "https://dev.azure.com/$Organization/_apis/connectionData?api-version=7.1-preview.1"
$userName = $null
$userId = $null

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $result = Invoke-RestMethod -Uri $connectionUrl -Headers $headers -Method Get -TimeoutSec 30
    
    $userName = $result.authenticatedUser.providerDisplayName
    $userId = $result.authenticatedUser.id
    
    Write-Success "Connected as: $userName"
    if ($Verbose) {
        Write-Info "User ID: $userId"
    }
}
catch {
    Write-Fail "Connection failed: $($_.Exception.Message)"
    if ($_.Exception.Response) {
        $status = [int]$_.Exception.Response.StatusCode.Value__
        Write-Info "HTTP Status: $status"
        if ($status -eq 401) {
            Write-Info "PAT may be expired or invalid"
        }
    }
    exit 1
}

# Test 2: List projects (validates vso.project scope)
$projectsUrl = "https://dev.azure.com/$Organization/_apis/projects?api-version=7.1"
$projectCount = 0

try {
    $result = Invoke-RestMethod -Uri $projectsUrl -Headers $headers -Method Get -TimeoutSec 60
    $projectCount = $result.count
    Write-Success "Organization: $Organization ($projectCount projects)"
    
    if ($Verbose -and $result.value) {
        Write-Host ""
        Write-Host "  Projects:" -ForegroundColor Gray
        $result.value | Select-Object -First 5 | ForEach-Object {
            Write-Info "  - $($_.name)"
        }
        if ($projectCount -gt 5) {
            Write-Info "  ... and $($projectCount - 5) more"
        }
    }
}
catch {
    Write-Fail "Project list failed: $($_.Exception.Message)"
    Write-Info "PAT may lack 'vso.project' scope"
    # Don't exit - connection worked, just missing scope
}
#endregion

#region Summary
Write-Host ""
Write-Host "=== Result ===" -ForegroundColor Cyan
Write-Success "PAT is valid"
Write-Info "User: $userName"
Write-Info "Org:  $Organization ($projectCount projects)"
#endregion

# Clear PAT from memory
$pat = $null
exit 0