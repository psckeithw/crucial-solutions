# Update script references
$renames = @(
    @{old="get-just-numbers.ps1"; new="get-just-numbers.ps1"},
    @{old="snapshot-get.ps1"; new="snapshot-get.ps1"}
)

foreach ($r in $renames) {
    Get-ChildItem -Path . -Recurse -File -Exclude ".git","node_modules" | Where-Object { 
        $_.Extension -match '\.(ps1|psm1|psd1|md|yml|yaml|json|htm|html|xml|txt|ini|conf|config)$' 
    } | ForEach-Object {
        $content = Get-Content $_.FullName -Raw -ErrorAction SilentlyContinue
        if ($content -and $content -match [regex]::Escape($r.old)) {
            $updated = $content -replace [regex]::Escape($r.old), $r.new
            Set-Content -Path $_.FullName -Value $updated -NoNewline
            Write-Host "Updated: $($_.FullName)" -ForegroundColor Green
        }
    }
}

Write-Host "`nDone!" -ForegroundColor Cyan
