#Requires -Version 7.0
<#
.SYNOPSIS
    Cleans up generated artifacts in test-output folder.

.DESCRIPTION
    This utility removes generated artifacts from the test-output folder while
    preserving intentionally tracked files like test-output/list_projects.ps1.

    It removes:
    - Per-project export folders and their contents
    - _manifests folder and contents
    - _state folder and contents
    - _logs folder and contents
    - Summary CSV/JSON files

    It preserves:
    - test-output/list_projects.ps1 (intentionally tracked)
    - test-output/ (root folder itself)
    - Any other files at the root of test-output that are not generated

.PARAMETER OutputRoot
    Root folder to clean. Default: C:\code\Niche Sandbox\dev\Niche Sandbox\test-output

.PARAMETER WhatIf
    Shows what would be deleted without actually deleting.

.PARAMETER Confirm
    Prompts for confirmation before deleting.

.EXAMPLE
    # Dry run to see what would be deleted
    pwsh -File "utils\scripts\project-collection\clean-up\clean-test-output.ps1" -WhatIf

.EXAMPLE
    # Actually clean up the test-output folder
    pwsh -File "utils\scripts\project-collection\clean-up\clean-test-output.ps1"

.EXAMPLE
    # Clean a specific output root
    pwsh -File "utils\scripts\project-collection\clean-up\clean-test-output.ps1" -OutputRoot "C:\Custom\Output"

.NOTES
    This script is safe to run multiple times.
    It uses -LiteralPath to handle paths with spaces correctly.
#>

[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
param(
    [Parameter()]
    [string]$OutputRoot = 'C:\code\Niche Sandbox\dev\Niche Sandbox\test-output'
)

# Files/folders to ALWAYS preserve (never delete)
$PreservedItems = @(
    'list_projects.ps1'  # Intentionally tracked in source control
)

# Folders that are generated and can be safely removed
$GeneratedFolders = @(
    '_manifests',
    '_state',
    '_logs'
)

$script:DeletedCount = 0
$script:SkippedCount = 0
$script:PreservedCount = 0

function Remove-ItemSafe {
    param(
        [Parameter(Mandatory)]
        [string]$Path,

        [switch]$Recurse
    )

    if ($PSCmdlet.ShouldProcess($Path, 'Delete')) {
        try {
            if ($Recurse) {
                Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            }
            else {
                Remove-Item -LiteralPath $Path -Force -ErrorAction Stop
            }
            $script:DeletedCount++
            Write-Host "  [DELETED] $Path" -ForegroundColor Red
        }
        catch {
            Write-Host "  [ERROR] Failed to delete $Path : $($_.Exception.Message)" -ForegroundColor Yellow
            $script:SkippedCount++
        }
    }
    else {
        $script:Skipped++
        Write-Host "  [WOULD DELETE] $Path" -ForegroundColor Cyan
    }
}

Write-Host "=== Clean-TestOutput Utility ===" -ForegroundColor Cyan
Write-Host "Output root: $OutputRoot" -ForegroundColor White
Write-Host ""

# Validate output root exists
if (-not (Test-Path -LiteralPath $OutputRoot)) {
    Write-Host "Output root does not exist: $OutputRoot" -ForegroundColor Yellow
    exit 0
}

# Get all items in output root
$items = Get-ChildItem -LiteralPath $OutputRoot -Force

Write-Host "Scanning $OutputRoot..." -ForegroundColor White
Write-Host ""

$projectFolders = @()
$generatedItems = @()
$preservedItems = @()

foreach ($item in $items) {
    $itemName = $item.Name

    # Check if this is a preserved item
    if ($itemName -in $PreservedItems) {
        $preservedItems += $item
        continue
    }

    # Check if this is a generated folder
    if ($item.PSIsContainer -and $itemName -in $GeneratedFolders) {
        $generatedItems += $item
        continue
    }

    # Check if this is a summary file (generated)
    if (-not $item.PSIsContainer) {
        if ($itemName -match '^ExportAndDelete-AdoProjects-Summary-' -or 
            $itemName -match '\.log$') {
            $generatedItems += $item
            continue
        }
    }

    # Check if this looks like a project folder (contains workitems.csv or metadata)
    if ($item.PSIsContainer) {
        $hasWorkitems = Test-Path -LiteralPath (Join-Path $item.FullName 'workitems.csv')
        $hasMetadata = Test-Path -LiteralPath (Join-Path $item.FullName 'metadata')
        
        if ($hasWorkitems -or $hasMetadata) {
            $projectFolders += $item
            continue
        }
    }

    # Everything else is preserved (unknown or intentionally tracked)
    $preservedItems += $item
}

# Report what will be deleted
if ($projectFolders.Count -gt 0) {
    Write-Host "Project folders to remove ($($projectFolders.Count)):" -ForegroundColor Yellow
    foreach ($folder in $projectFolders) {
        Write-Host "  - $($folder.Name)" -ForegroundColor Gray
    }
    Write-Host ""
}

if ($generatedItems.Count -gt 0) {
    Write-Host "Generated folders/files to remove ($($generatedItems.Count)):" -ForegroundColor Yellow
    foreach ($item in $generatedItems) {
        Write-Host "  - $($item.Name)" -ForegroundColor Gray
    }
    Write-Host ""
}

# Report preserved items
Write-Host "Preserved items ($($preservedItems.Count)):" -ForegroundColor Green
foreach ($item in $preservedItems) {
    Write-Host "  - $($item.Name)" -ForegroundColor Gray
}
Write-Host ""

# Actually delete items
if ($generatedItems.Count -gt 0 -or $projectFolders.Count -gt 0) {
    Write-Host "Removing generated folders..." -ForegroundColor White
    
    foreach ($item in $generatedItems) {
        Remove-ItemSafe -Path $item.FullName -Recurse
    }

    foreach ($folder in $projectFolders) {
        Remove-ItemSafe -Path $folder.FullName -Recurse
    }

    Write-Host ""
    Write-Host "=== Summary ===" -ForegroundColor Cyan
    Write-Host "Deleted: $script:DeletedCount items" -ForegroundColor Red
    Write-Host "Skipped: $script:SkippedCount items" -ForegroundColor Yellow
    Write-Host "Preserved: $($preservedItems.Count) items" -ForegroundColor Green
    
    # Count remaining items
    $remaining = Get-ChildItem -LiteralPath $OutputRoot -Force
    Write-Host "Remaining items in $OutputRoot : $($remaining.Count)" -ForegroundColor White
}
else {
    Write-Host "No items to clean up." -ForegroundColor Green
}

Write-Host ""
Write-Host "Done!" -ForegroundColor Cyan
