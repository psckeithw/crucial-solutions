# Debug script to get ACL details for a specific project
$modulePath = Join-Path $PSScriptRoot 'utils\modules\AzDO-Helpers.psm1'
Import-Module -Name $modulePath -Force

$pat = Get-AdoPat
$headers = Get-AdoHeaders -Pat $pat

$projectNamespaceId = '52d39943-cb85-4d7f-8fa8-c6baac873819'
$org = 'aha-bt'
$projectName = 'PHD Data Quality'

# Get project ID
$projectUrl = "https://dev.azure.com/$org/_apis/projects/" + [uri]::EscapeDataString($projectName) + "?api-version=7.1"
$projectInfo = Invoke-RestMethod -Uri $projectUrl -Headers $headers -Method Get
$projectId = $projectInfo.id

Write-Host "Project: $projectName" -ForegroundColor Cyan
Write-Host "Project ID: $projectId" -ForegroundColor Cyan

# First, let's get ALL ACLs for the project namespace without filtering
$allAclsUrl = "https://dev.azure.com/$org/_apis/accesscontrollists/$projectNamespaceId`?api-version=7.1"
Write-Host "`nFetching ALL ACLs..." -ForegroundColor Yellow
$allAcls = Invoke-RestMethod -Uri $allAclsUrl -Headers $headers -Method Get
Write-Host "Total ACL entries: $($allAcls.value.Count)" -ForegroundColor Yellow

# Now filter for our project token
$projectToken = "vstfs://Classification/TeamProject/$projectId"
Write-Host "`nLooking for tokens containing: $projectToken" -ForegroundColor Yellow

$foundTokens = @()
foreach ($acl in $allAcls.value) {
    if ($acl.token -like "*$projectId*") {
        $foundTokens += $acl.token
    }
}

Write-Host "Found $($foundTokens.Count) matching tokens" -ForegroundColor Yellow
$foundTokens | ForEach-Object { Write-Host "  $_" }

# Now get ACLs for one of these tokens
if ($foundTokens.Count -gt 0) {
    $targetToken = $foundTokens[0]
    $encodedToken = [uri]::EscapeDataString($targetToken)
    $aclUrl = "https://dev.azure.com/$org/_apis/accesscontrollists/$projectNamespaceId`?api-version=7.1&token=$encodedToken&includeExtendedInfo=true"
    
    Write-Host "`nFetching ACLs for token: $targetToken" -ForegroundColor Yellow
    $projectAcls = Invoke-RestMethod -Uri $aclUrl -Headers $headers -Method Get
    
    $adminBits = 1
    $adminBits2 = 2
    
    Write-Host "Found $($projectAcls.value.Count) ACL entries" -ForegroundColor Yellow
    
    foreach ($acl in $projectAcls.value) {
        if ($acl.acesDictionary) {
            foreach ($prop in $acl.acesDictionary.PSObject.Properties) {
                $ace = $prop.Value
                $descriptor = $prop.Name
                
                $hasFullControl = ($ace.allow -band $adminBits) -ne 0
                $hasAdminister = ($ace.allow -band $adminBits2) -ne 0
                
                if ($hasFullControl -or $hasAdminister) {
                    Write-Host "Admin: $descriptor" -ForegroundColor Green
                    
                    # Try to extract username
                    if ($descriptor -match 'ClaimsIdentity;[^\\]+\\(.*)') {
                        $userName = $matches[1]
                        Write-Host "  Username: $userName" -ForegroundColor Cyan
                    }
                }
            }
        }
    }
}
