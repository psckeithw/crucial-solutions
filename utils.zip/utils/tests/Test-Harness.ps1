#Requires -Version 7.0
<#
.SYNOPSIS
    Test harness that runs all PowerShell scripts defined in JS config files.
.DESCRIPTION
    Reads JS config files (dashboard-config.js), extracts PowerShell script definitions,
    authenticates once, then tests each script by running it with appropriate parameters.
    Reports success/failure for each script.
.PARAMETER ConfigFile
    Path to JS config file (defaults to dashboard-config.js in summaries folder).
.PARAMETER ScriptsFolder
    Base folder where scripts are located.
.PARAMETER Org
    Azure DevOps organization (overrides config).
.PARAMETER PatEnvVar
    Environment variable containing PAT (defaults to AZDO_PAT).
.PARAMETER TestMode
    If set, only validates script existence and syntax without executing.
.PARAMETER ProjectName
    Optional project name to pass to scripts that require it.
.EXAMPLE
    .\Test-Harness.ps1
.EXAMPLE
    .\Test-Harness.ps1 -TestMode
.EXAMPLE
    .\Test-Harness.ps1 -ProjectName "MyTestProject"
#>
[CmdletBinding()]
param(
    [Parameter()]
    [string]$ConfigFile = $null,

    [Parameter()]
    [string]$ScriptsFolder = $null,

    [Parameter()]
    [string]$Org = 'aha-bt',

    [Parameter()]
    [string]$PatEnvVar = 'AZDO_PAT',

    [Parameter()]
    [switch]$TestMode,

    [Parameter()]
    [string]$ProjectName = ''
)

#region Configuration
$ErrorActionPreference = 'Continue'
$Script:Results = @()
$Script:AuthHeaders = $null

# Base paths
$BasePath = 'C:\code\Niche Sandbox\dev\Niche Sandbox\utils'
if (-not $ConfigFile) {
    $ConfigFile = Join-Path $BasePath 'docs\summaries\dashboard-config.js'
}
if (-not $ScriptsFolder) {
    $ScriptsFolder = Join-Path $BasePath 'scripts'
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  PowerShell Script Test Harness" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Config File: $ConfigFile" -ForegroundColor Gray
Write-Host "Scripts Folder: $ScriptsFolder" -ForegroundColor Gray
Write-Host "Organization: $Org" -ForegroundColor Gray
Write-Host "Test Mode: $TestMode" -ForegroundColor Gray
Write-Host ""
#endregion

#region Helper Functions

function Get-CmdletFromScript {
    <#
    .SYNOPSIS
        Extracts cmdlet names from a PowerShell script file.
    #>
    param([string]$ScriptPath)

    if (-not (Test-Path $ScriptPath)) {
        return @()
    }

    $content = Get-Content $ScriptPath -Raw -ErrorAction SilentlyContinue
    if (-not $content) { return @() }

    # Find all cmdlet/function calls (verb-noun pattern)
    $cmdlets = @()
    
    # Match standard PowerShell cmdlets (Verb-Noun pattern)
    $matches = [regex]::Matches($content, '\b([A-Z][a-z]+-[A-Z][a-zA-Z]+)\b')
    foreach ($match in $matches) {
        $cmdlet = $match.Groups[1].Value
        if ($cmdlet -notin $cmdlets) {
            $cmdlets += $cmdlet
        }
    }

    # Also find custom functions defined in the script
    $functionMatches = [regex]::Matches($content, '(?:function|filter)\s+([A-Za-z0-9-]+)', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    foreach ($match in $functionMatches) {
        $funcName = $match.Groups[1].Value
        if ($funcName -notin $cmdlets) {
            $cmdlets += $funcName
        }
    }

    return $cmdlets | Sort-Object -Unique
}

function Test-ScriptSyntax {
    <#
    .SYNOPSIS
        Validates PowerShell script syntax without executing.
    #>
    param([string]$ScriptPath)

    try {
        $null = [System.Management.Automation.PSParser]::Tokenize((Get-Content $ScriptPath -Raw), [ref]$null)
        return @{ Success = $true; Error = $null }
    }
    catch {
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Invoke-ScriptWithAuth {
    <#
    .SYNOPSIS
        Executes a script with pre-authenticated session.
    #>
    param(
        [string]$ScriptPath,
        [hashtable]$Params,
        [string]$Description
    )

    $result = @{
        Script = $ScriptPath
        Description = $Description
        Success = $false
        Output = ''
        Error = $null
        Duration = 0
        Cmdlets = @()
    }

    # Get cmdlets used in script
    $result.Cmdlets = Get-CmdletFromScript -ScriptPath $ScriptPath

    # If TestMode, only validate syntax
    if ($TestMode) {
        $syntaxCheck = Test-ScriptSyntax -ScriptPath $ScriptPath
        $result.Success = $syntaxCheck.Success
        $result.Error = $syntaxCheck.Error
        if ($syntaxCheck.Success) {
            $result.Output = "[TEST MODE] Syntax valid, script would execute with params: $($Params.Keys -join ', ')"
        }
        return $result
    }

    # Execute the script
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    
    try {
        # Build argument string
        $argString = @()
        foreach ($key in $Params.Keys) {
            $value = $Params[$key]
            if ($value -is [switch] -and $value.IsPresent) {
                $argString += $key
            }
            elseif ($value -is [string] -and $value -ne '') {
                $argString += "$key `"$value`""
            }
            elseif ($value -is [int] -or $value -is [bool]) {
                $argString += "$key $value"
            }
        }

        $scriptDir = Split-Path $ScriptPath -Parent
        $scriptName = Split-Path $ScriptPath -Leaf
        
        # Run with splat for better parameter handling
        $paramHashtable = @{}
        foreach ($key in $Params.Keys) {
            $paramHashtable[$key] = $Params[$key]
        }
        
        # Set org if not already in params
        if (-not $paramHashtable.ContainsKey('Org')) {
            $paramHashtable['Org'] = $Org
        }

        # Capture output
        $output = & $scriptDir\$scriptName @paramHashtable 2>&1 | Out-String
        
        $stopwatch.Stop()
        $result.Duration = $stopwatch.ElapsedMilliseconds
        $result.Success = $LASTEXITCODE -eq 0 -or $null -eq $LASTEXITCODE
        $result.Output = $output
        
        if (-not $result.Success -and $output) {
            $result.Error = "Script exited with code: $LASTEXITCODE"
        }
    }
    catch {
        $stopwatch.Stop()
        $result.Duration = $stopwatch.ElapsedMilliseconds
        $result.Error = $_.Exception.Message
        $result.Output = $_.Exception.StackTrace
    }

    return $result
}

function Parse-JsConfig {
    <#
    .SYNOPSIS
        Parses JS config file to extract script definitions.
    #>
    param([string]$FilePath)

    if (-not (Test-Path $FilePath)) {
        Write-Warning "Config file not found: $FilePath"
        return @()
    }

    $content = Get-Content $FilePath -Raw
    
    $scripts = @()
    
    # Find each script block using a more precise regex that captures the entire script object
    # Pattern: { id: "...", label: "...", group: "...", file: "...", desc: "...", params: [...] }
    $scriptPattern = '(?s)\{\s*id:\s*"([^"]+)",\s*label:\s*"([^"]+)",\s*group:\s*"([^"]+)",\s*file:\s*"([^"]+\.ps1)",\s*desc:\s*"([^"]+)"'
    $matches = [regex]::Matches($content, $scriptPattern)
    
    foreach ($match in $matches) {
        $script = @{
            Id = $match.Groups[1].Value
            Label = $match.Groups[2].Value
            Group = $match.Groups[3].Value
            File = $match.Groups[4].Value
            Desc = $match.Groups[5].Value
            Params = @()
        }
        
        $scripts += $script
    }
    
    return $scripts
}

#endregion

#region Authentication

Write-Host "=== AUTHENTICATION ===" -ForegroundColor Yellow

# Import AzDO-Helpers module
$modulePath = Join-Path $BasePath 'modules\AzDO-Helpers.psm1'
if (Test-Path $modulePath) {
    Import-Module $modulePath -Force
    Write-Host "Loaded AzDO-Helpers module" -ForegroundColor Green
} else {
    Write-Warning "AzDO-Helpers module not found at: $modulePath"
}

# Get PAT and authenticate
try {
    $pat = Get-AdoPat -EnvVarName $PatEnvVar -PromptIfMissing
    $Script:AuthHeaders = Get-AdoHeaders -Pat $pat
    $Script:Pat = $pat  # Store PAT to pass to scripts
    Write-Host "Authentication successful!" -ForegroundColor Green
}
catch {
    Write-Error "Failed to authenticate: $_"
    exit 1
}

Write-Host ""

#endregion

#region Parse Config and Find Scripts

Write-Host "=== PARSING CONFIG ===" -ForegroundColor Yellow

$jsScripts = Parse-JsConfig -FilePath $ConfigFile

if ($jsScripts.Count -eq 0) {
    Write-Warning "No scripts found in config file"
    exit 1
}

Write-Host "Found $($jsScripts.Count) script definitions in config" -ForegroundColor Cyan
Write-Host ""

# Resolve full paths
foreach ($script in $jsScripts) {
    # The JS config already has paths relative to scripts folder
    # e.g., "scripts\project-collection\clean-up\collection\get-collection-audit.ps1"
    $scriptPath = $script.File -replace '^scripts[/\\]', ''
    $fullPath = Join-Path $ScriptsFolder $scriptPath
    $script.FullPath = $fullPath
    $script.Exists = Test-Path $fullPath
}

#endregion

#region Execute Scripts

Write-Host "=== EXECUTING SCRIPTS ===" -ForegroundColor Yellow
Write-Host ""

$groupedScripts = $jsScripts | Group-Object -Property Group

foreach ($group in $groupedScripts) {
    Write-Host "--- $($group.Name) ---" -ForegroundColor Magenta
    
    foreach ($script in $group.Group) {
        Write-Host "  Testing: $($script.Label)" -ForegroundColor White -NoNewline
        
        # Build parameters - don't pass PAT as parameter, set env var instead
        $params = @{
            Org = $Org
        }
        
        # Set PAT in environment variable for scripts that read from $env:
        if ($Script:Pat) {
            $env:AZDO_PAT = $Script:Pat
        }
        
        # Add project name if specified and script accepts it
        if ($ProjectName) {
            $params['Projects'] = $ProjectName
        }
        
        # Check if script exists
        if (-not $script.Exists) {
            Write-Host " [NOT FOUND]" -ForegroundColor Red
            $Script:Results += @{
                Id = $script.Id
                Label = $script.Label
                Group = $script.Group
                Success = $false
                Error = "Script file not found: $($script.FullPath)"
                Cmdlets = @()
                Duration = 0
            }
            continue
        }
        
        # Execute script
        $result = Invoke-ScriptWithAuth -ScriptPath $script.FullPath -Params $params -Description $script.Desc
        
        if ($result.Success) {
            Write-Host " [PASS]" -ForegroundColor Green
        }
        else {
            Write-Host " [FAIL]" -ForegroundColor Red
            if ($result.Error) {
                Write-Host "    Error: $($result.Error)" -ForegroundColor Yellow
            }
        }
        
        $Script:Results += @{
            Id = $script.Id
            Label = $script.Label
            Group = $script.Group
            Success = $result.Success
            Error = $result.Error
            Output = $result.Output
            Cmdlets = $result.Cmdlets
            Duration = $result.Duration
        }
    }
    
    Write-Host ""
}

#endregion

#region Summary Report

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  TEST SUMMARY" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$total = $Script:Results.Count
$passed = ($Script:Results | Where-Object { $_.Success }).Count
$failed = $total - $passed

Write-Host "Total Scripts: $total" -ForegroundColor White
Write-Host "Passed: $passed" -ForegroundColor Green
Write-Host "Failed: $failed" -ForegroundColor Red
Write-Host ""

# Group by result
$Script:Results | Group-Object -Property Success | ForEach-Object {
    $isSuccess = $_.Name -eq 'True'
    $color = if ($isSuccess) { 'Green' } else { 'Red' }
    $label = if ($isSuccess) { 'SUCCESSFUL' } else { 'FAILED' }
    
    Write-Host "--- $label ---" -ForegroundColor $color
    foreach ($r in $_.Group) {
        $status = if ($r.Success) { '[OK]' } else { '[FAIL]' }
        $color = if ($r.Success) { 'Green' } else { 'Red' }
        Write-Host "  $status $($r.Label)" -ForegroundColor $color
        if (-not $r.Success -and $r.Error) {
            Write-Host "       $($r.Error)" -ForegroundColor Yellow
        }
    }
    Write-Host ""
}

# Export results to JSON
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$outputPath = Join-Path $BasePath "tests\TestHarness-Results-$timestamp.json"
$Script:Results | ConvertTo-Json -Depth 5 | Out-File $outputPath
Write-Host "Results exported to: $outputPath" -ForegroundColor Cyan

# Show cmdlet summary
Write-Host "=== CMDLET INVENTORY ===" -ForegroundColor Cyan
$allCmdlets = @()
foreach ($r in $Script:Results) {
    $allCmdlets += $r.Cmdlets
}
$script:cmdletCounts = $allCmdlets | Group-Object | Sort-Object Count -Descending
Write-Host "Total unique cmdlets used: $($script:cmdletCounts.Count)" -ForegroundColor White
foreach ($item in $script:cmdletCounts | Select-Object -First 20) {
    Write-Host "  $($item.Name): $($item.Count)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "=== COMPLETE ===" -ForegroundColor Green

#endregion
