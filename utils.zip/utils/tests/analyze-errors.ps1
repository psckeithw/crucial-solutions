$json = Get-Content 'C:\code\Niche Sandbox\dev\Niche Sandbox\test-output\ExportAndDelete-AdoProjects-Summary-20260218-112029.json' -Raw | ConvertFrom-Json
foreach ($project in $json) {
    Write-Host "=== $($project.ProjectName) ==="
    Write-Host "  WorkItemTypesInProject: $($project.WorkItemTypesInProject)"
    Write-Host "  ExportedWorkItemTypes: $($project.ExportedWorkItemTypes)"
    Write-Host "  NotExportedTypes: $($project.NotExportedTypes)"
    Write-Host ""
}
