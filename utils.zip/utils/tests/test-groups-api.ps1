$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{Authorization = "Basic $auth" }

$projectName = "Professional Volunteer Search"

# Get project ID
$proj = Invoke-RestMethod -Uri "https://dev.azure.com/aha-bt/_apis/projects/$([uri]::EscapeDataString($projectName))?api-version=7.1" -Headers $headers
$projectId = $proj.id
Write-Host "Project: $projectName"
Write-Host "Project ID: $projectId"

# Try security groups API with project scope
Write-Host "`n=== Security Groups API with project scope ===" -ForegroundColor Cyan
try {
    $secGroupsUrl = "https://dev.azure.com/aha-bt/_apis/securitygroups?api-version=7.1&scope=$projectId"
    $secGroups = Invoke-RestMethod -Uri $secGroupsUrl -Headers $headers -Method Get
    Write-Host "Found $($secGroups.value.Count) security groups"
    
    foreach ($group in $secGroups.value) {
        Write-Host "  - $($group.displayName)"
    }
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}

# Try with collection scope
Write-Host "`n=== Security Groups API with collection scope ===" -ForegroundColor Cyan
try {
    $secGroupsUrl = "https://dev.azure.com/aha-bt/_apis/securitygroups?api-version=7.1"
    $secGroups = Invoke-RestMethod -Uri $secGroupsUrl -Headers $headers -Method Get
    Write-Host "Found $($secGroups.value.Count) security groups"
    
    # Look for project-specific groups
    foreach ($group in $secGroups.value) {
        if ($group.displayName -match $projectName) {
            Write-Host "  [MATCH] $($group.displayName)"
            Write-Host "    Descriptor: $($group.descriptor)"
            
            # Try to get members
            try {
                $membersUrl = "https://dev.azure.com/aha-bt/_apis/securitygroups/$($group.descriptor)/members?api-version=7.1"
                $members = Invoke-RestMethod -Uri $membersUrl -Headers $headers -Method Get
                Write-Host "    Found $($members.value.Count) members"
                foreach ($member in $members.value) {
                    Write-Host "      - $($member.displayName) <$($member.mailAddress)>"
                }
            }
            catch {
                Write-Host "    Error getting members: $($_.Exception.Message)"
            }
        }
    }
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}

# Try looking at the explicit project-level API
Write-Host "`n=== Project-level explicit API ===" -ForegroundColor Cyan
try {
    # Try the explicit webapi approach
    $webApiUrl = "https://dev.azure.com/aha-bt/$projectId/_api/_projectpermissions/GetProjectPermissions?api-version=7.1"
    $perms = Invoke-RestMethod -Uri $webApiUrl -Headers $headers -Method Get
    Write-Host "Got project permissions response"
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}
