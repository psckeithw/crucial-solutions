$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{Authorization = "Basic $auth" }

# Try getProjectProperties
$props = Invoke-RestMethod -Uri 'https://dev.azure.com/aha-bt/_apis/projects/d8cb7321-047c-4b6b-8bcb-463e189a4893/properties?api-version=7.1-preview' -Headers $headers
$props | ConvertTo-Json -Depth 5
