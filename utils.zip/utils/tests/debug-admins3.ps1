# Debug script - try getting project administrators through group membership

$modulePath = Join-Path $PSScriptRoot 'utils\modules\AzDO-Helpers.psm1'
Import-Module -Name $modulePath -Force

$pat = Get-AdoPat
$headers = Get-AdoHeaders -Pat $pat

$org = 'aha-bt'
$projectName = 'PHD Data Quality'

# Get project ID
$projectUrl = "https://dev.azure.com/$org/_apis/projects/" + [uri]::EscapeDataString($projectName) + "?api-version=7.1"
$projectInfo = Invoke-RestMethod -Uri $projectUrl -Headers $headers -Method Get
$projectId = $projectInfo.id

Write-Host "Project: $projectName" -ForegroundColor Cyan
Write-Host "Project ID: $projectId" -ForegroundColor Cyan

# Try to get all groups that have access to this project
Write-Host "`n=== Getting all groups in the org ===" -ForegroundColor Yellow

$groupsUrl = "https://dev.azure.com/$org/_apis/graph/groups?api-version=7.1"
$allGroups = Invoke-RestMethod -Uri $groupsUrl -Headers $headers -Method Get

Write-Host "Found $($allGroups.value.Count) groups"

# Look for project-level groups or admin groups
$relevantGroups = @()
foreach ($group in $allGroups.value) {
    # Look for groups related to this project or administrators
    if ($group.displayName -like "*$projectName*" -or $group.displayName -like "*Admin*") {
        $relevantGroups += $group
        Write-Host "  Relevant: $($group.displayName) - $($group.principalName)" -ForegroundColor Green
    }
}

# Try to get the project's Team Foundation Group
Write-Host "`n=== Getting project team group ===" -ForegroundColor Yellow

# The project usually has a default team group
$teamGroupUrl = "https://dev.azure.com/$org/_apis/projects/$projectId/teams"
try {
    $teams = Invoke-RestMethod -Uri $teamGroupUrl -Headers $headers -Method Get
    Write-Host "Found $($teams.value.Count) teams"
    foreach ($team in $teams.value) {
        Write-Host "  Team: $($team.name)"
        
        # Try to get team members
        $membersUrl = "https://dev.azure.com/$org/_apis/projects/$projectId/teams/$($team.id)/members?api-version=7.1"
        try {
            $members = Invoke-RestMethod -Uri $membersUrl -Headers $headers -Method Get
            Write-Host "    Found $($members.value.Count) members"
            foreach ($member in $members.value) {
                Write-Host "      $($member.identity.displayName) <$($member.identity.uniqueName)>" -ForegroundColor Green
            }
        }
        catch {
            Write-Host "    Error getting members: $($_.Exception.Message)"
        }
    }
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}

# Try the explicit "get project administrators" approach using webApi
Write-Host "`n=== Trying explicit admin lookup ===" -ForegroundColor Yellow

# Try getting permissions for the "Project Administrators" group
$projectAdminGroups = @()
foreach ($group in $allGroups.value) {
    if ($group.displayName -eq "Project Administrators" -or $group.displayName -like "*$projectName*Project Administrators*") {
        $projectAdminGroups += $group
    }
}

Write-Host "Found $($projectAdminGroups.Count) Project Administrators groups"

foreach ($group in $projectAdminGroups) {
    Write-Host "Group: $($group.displayName)" -ForegroundColor Cyan
    Write-Host "  Descriptor: $($group.descriptor)"
    
    # Try to get members of this group
    $membersUrl = "https://dev.azure.com/$org/_apis/graph/groups/$($group.descriptor)/members?api-version=7.1"
    try {
        $members = Invoke-RestMethod -Uri $membersUrl -Headers $headers -Method Get
        Write-Host "  Found $($members.value.Count) members"
        foreach ($member in $members.value) {
            Write-Host "    $($member.displayName) <$($member.mailAddress)>" -ForegroundColor Green
        }
    }
    catch {
        Write-Host "  Error: $($_.Exception.Message)"
    }
}
