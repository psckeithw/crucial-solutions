$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{
    Authorization = "Basic $auth"
    'Content-Type' = 'application/json'
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$testProject = "Supplier Collaboration System"

# Get IDs
$wiqlQuery = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = '$testProject'"
$url = "https://dev.azure.com/aha-bt/$([uri]::EscapeDataString($testProject))/_apis/wit/wiql?api-version=7.1"
$jsonBody = "{`n  `"query`": `"$wiqlQuery`"`n}"

$r = Invoke-RestMethod -Uri $url -Headers $headers -Method Post -Body $jsonBody -ContentType 'application/json'
$allIds = $r.workItems.id

Write-Host "Total IDs in project: $($allIds.Count)"
Write-Host ""

# Test 1: Original URL format (multiple ids=)
$ids = $allIds | Select-Object -First 5
$oldFormat = ($ids | ForEach-Object { "ids=$_" }) -join '&'
$oldUrl = "https://dev.azure.com/aha-bt/$([uri]::EscapeDataString($testProject))/_apis/wit/workitems?$oldFormat&`$fields=*"
Write-Host "Old format (ids=x&ids=y):"
Write-Host $oldUrl.Substring(0, [Math]::Min(150, $oldUrl.Length))
$oldResult = Invoke-RestMethod -Uri $oldUrl -Headers $headers
Write-Host "Result: $($oldResult.count) items"
Write-Host ""

# Test 2: Comma-separated format
$commaFormat = "ids=" + ($ids -join ',')
$newUrl = "https://dev.azure.com/aha-bt/$([uri]::EscapeDataString($testProject))/_apis/wit/workitems?$commaFormat&`$fields=*"
Write-Host "New format (ids=x,y):"
Write-Host $newUrl.Substring(0, [Math]::Min(150, $newUrl.Length))
$newResult = Invoke-RestMethod -Uri $newUrl -Headers $headers
Write-Host "Result: $($newResult.count) items"
