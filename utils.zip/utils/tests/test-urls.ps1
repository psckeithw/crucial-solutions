#Requires -Version 7.0
$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{
    Authorization = "Basic $auth"
    'Content-Type' = 'application/json'
}

Write-Host 'Testing dev.azure.com format...' -ForegroundColor Cyan
$url = 'https://dev.azure.com/aha-bt/_apis/connectionData?api-version=7.1-preview.1'
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $result = Invoke-RestMethod -Uri $url -Headers $headers -TimeoutSec 30
    Write-Host "SUCCESS! Connected as: $($result.authenticatedUser.name)" -ForegroundColor Green
} catch {
    Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ''
Write-Host 'Testing visualstudio.com format...' -ForegroundColor Cyan
$url2 = 'https://aha-bt.visualstudio.com/_apis/connectionData?api-version=7.1-preview.1'
try {
    $result2 = Invoke-RestMethod -Uri $url2 -Headers $headers -TimeoutSec 30
    Write-Host "SUCCESS! Connected as: $($result2.authenticatedUser.name)" -ForegroundColor Green
} catch {
    Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
}
