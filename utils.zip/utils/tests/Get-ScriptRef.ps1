# File: Get-ScriptRef.ps1
param([string]$OldName)
# Exclude standard noise; focus only on source and config
$Exclude = @('.git', 'bin', 'obj', 'node_modules', 'packages', 'dist')
Get-ChildItem -Path . -Recurse -File -Exclude $Exclude | ForEach-Object {
    $Matches = Select-String -Path $_.FullName -Pattern "\b$([regex]::Escape($OldName))\b" -CaseSensitive:$false
    if ($Matches) {
        $Matches | Select-Object Path, LineNumber, Line
    }
}