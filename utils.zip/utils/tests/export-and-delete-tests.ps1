#Requires -Version 7.0
<#
.SYNOPSIS
    Focused regression tests for export-and-delete-ado-projects.ps1

.DESCRIPTION
    These tests validate core functionality:
    - Auth preflight behavior
    - PAT source precedence (Process > User > Machine)
    - WIQL export behavior for project names with spaces

.EXAMPLE
    pwsh -File "utils/tests/export-and-delete-tests.ps1"
#>

$ErrorActionPreference = 'Continue'
$script:TestResults = @()
$script:FailedCount = 0
$script:PassedCount = 0

function Test-Failure {
    param([string]$Message)
    $script:TestResults += "[FAIL] $Message"
    $script:FailedCount++
    Write-Host "[FAIL] $Message" -ForegroundColor Red
}

function Test-Success {
    param([string]$Message)
    $script:TestResults += "[PASS] $Message"
    $script:PassedCount++
    Write-Host "[PASS] $Message" -ForegroundColor Green
}

Write-Host "=== ExportAndDelete Regression Tests ===" -ForegroundColor Cyan
Write-Host ""

# Import the AzDO Helpers module
$modulePath = Join-Path $PSScriptRoot '..\modules\AzDO-Helpers.psm1'
if (Test-Path -LiteralPath $modulePath) {
    Import-Module -Name $modulePath -Force
}
else {
    Write-Host "Warning: AzDO-Helpers.psm1 not found at: $modulePath" -ForegroundColor Yellow
}

#region Test 1: PAT Precedence (Process > User > Machine)
Write-Host "Test 1: PAT source precedence (Process > User > Machine)" -ForegroundColor Cyan

# This test verifies the PAT resolution order in Get-AdoPat
# The expected order is: Process -> User -> Machine

# Test 1a: Verify Get-AdoPat function exists
if (Get-Command -Name Get-AdoPat -ErrorAction SilentlyContinue) {
    Test-Success "Get-AdoPat function exists in module"
}
else {
    Test-Failure "Get-AdoPat function not found in module"
}

# Test 1b: Check the function's source code to verify order
$getAdoPatSource = (Get-Command Get-AdoPat).ScriptBlock.ToString()

# Check that Process scope is checked first
if ($getAdoPatSource -match "\[Environment\]::GetEnvironmentVariable\([^)]+,\s*['""]Process['""]\)") {
    # Check it's before User scope
    $processPos = $getAdoPatSource.IndexOf("'Process'")
    $userPos = $getAdoPatSource.IndexOf("'User'")
    $machinePos = $getAdoPatSource.IndexOf("'Machine'")
    
    if ($processPos -ne -1 -and $processPos -lt $userPos -and $processPos -lt $machinePos) {
        Test-Success "PAT precedence: Process checked before User and Machine"
    }
    else {
        Test-Failure "PAT precedence order is not correct (Process should be first)"
    }
}
else {
    Test-Failure "Could not verify PAT precedence order in source code"
}

#endregion

#region Test 2: Auth Preflight Function
Write-Host ""
Write-Host "Test 2: Auth preflight behavior" -ForegroundColor Cyan

# Test 2a: Verify Test-AdoAuthentication function exists in main script
$scriptPath = Join-Path $PSScriptRoot '..\scripts\project-collection\export\export-and-delete-ado-projects.ps1'
if (Test-Path -LiteralPath $scriptPath) {
    $scriptContent = Get-Content -LiteralPath $scriptPath -Raw
    
    if ($scriptContent -match 'function Test-AdoAuthentication') {
        Test-Success "Test-AdoAuthentication function exists in ExportAndDelete script"
    }
    else {
        Test-Failure "Test-AdoAuthentication function not found in ExportAndDelete script"
    }
    
    # Test 2b: Check that auth preflight is called early
    if ($scriptContent -match 'Test-AdoAuthentication.*Org.*Headers') {
        Test-Success "Auth preflight is called with Org and Headers"
    }
    else {
        Test-Failure "Auth preflight not called with correct parameters"
    }
    
    # Test 2c: Check for clear error messages on auth failure
    if ($scriptContent -match 'authentication failed' -or $scriptContent -match '401 Unauthorized' -or $scriptContent -match 'expired') {
        Test-Success "Auth failure provides clear error messages"
    }
    else {
        Test-Failure "Auth failure error messages could be improved"
    }
}
else {
    Test-Failure "export-and-delete-ado-projects.ps1 not found"
}

#endregion

#region Test 3: Project Names with Spaces
Write-Host ""
Write-Host "Test 3: WIQL export path for project names with spaces" -ForegroundColor Cyan

# Test 3a: Verify URL encoding for project names
if ($scriptContent -match '\[uri\]::EscapeDataString') {
    Test-Success "Project names are URL-encoded for API calls"
}
else {
    Test-Failure "Project names may not be properly URL-encoded"
}

# Test 3b: Verify path handling uses -LiteralPath for spaces
if ($scriptContent -match 'Join-Path.*-LiteralPath' -or $scriptContent -match 'Test-Path.*-LiteralPath') {
    Test-Success "LiteralPath is used for path operations (handles spaces)"
}
else {
    Test-Failure "LiteralPath not consistently used for paths with spaces"
}

# Test 3c: Check that workitems.csv path handles spaces correctly
$projectFolder = Join-Path 'test-output' 'Niche Sandbox'
$csvPath = Join-Path $projectFolder 'workitems.csv'
$expectedPath = 'test-output\Niche Sandbox\workitems.csv'

if ($csvPath -match 'Niche Sandbox' -or $csvPath -eq $expectedPath) {
    Test-Success "Output path correctly handles project names with spaces"
}
else {
    Test-Failure "Output path may not handle project names with spaces correctly"
}

# Test 3d: Verify Get-WorkItemIdsViaWiql function
if ($scriptContent -match 'function Get-WorkItemIdsViaWiql') {
    Test-Success "Get-WorkItemIdsViaWiql function exists"
    
    # Check it uses encoded project name in URL
    if ($scriptContent -match 'Get-WorkItemIdsViaWiql.*EscapeDataString') {
        Test-Success "WIQL query uses URL-encoded project name"
    }
}
else {
    Test-Failure "Get-WorkItemIdsViaWiql function not found"
}

#endregion

#region Test 4: Error Handling and Masking
Write-Host ""
Write-Host "Test 4: Error handling and sensitive data masking" -ForegroundColor Cyan

# Test 4a: Check for structured error function
if ($scriptContent -match 'function Write-StructuredError') {
    Test-Success "Structured error function exists"
}
else {
    Test-Failure "Structured error function not found"
}

# Test 4b: Check for PAT masking in errors
if ($scriptContent -match 'mask|replace.*\[a-zA-Z0-9\]' -or $scriptContent -match '\*\*\*MASKED\*\*\*') {
    Test-Success "PAT masking is implemented"
}
else {
    Test-Failure "PAT masking not found in error handling"
}

# Test 4c: Check that PAT is cleared from memory
if ($scriptContent -match '\$plainPat\s*=\s*\$null' -or $scriptContent -match 'finally.*plainPat.*null') {
    Test-Success "PAT is cleared from memory after use"
}
else {
    Test-Failure "PAT may not be properly cleared from memory"
}

#endregion

#region Test 5: Run Summary Columns
Write-Host ""
Write-Host "Test 5: Run summary output" -ForegroundColor Cyan

# Test 5a: Check for summary CSV/JSON generation
if ($scriptContent -match 'Export-Csv.*Summary' -and $scriptContent -match 'ConvertTo-Json.*Summary') {
    Test-Success "Summary CSV and JSON are generated"
}
else {
    Test-Failure "Summary output not found"
}

# Test 5b: Check for required summary columns
$requiredColumns = @('ProjectName', 'ProjectId', 'Status', 'ExistingWorkItemCount', 'ExportedWorkItemCount', 'DeleteRequested', 'DeleteStatus')
$missingColumns = @()

foreach ($col in $requiredColumns) {
    if (-not ($scriptContent -match $col)) {
        $missingColumns += $col
    }
}

if ($missingColumns.Count -eq 0) {
    Test-Success "All required summary columns are present"
}
else {
    Test-Failure "Missing summary columns: $($missingColumns -join ', ')"
}

# Test 5c: Check for ErrorMessage column in run summary (new feature)
if ($scriptContent -match 'ErrorMessage\s*=\s*\$errorMessage') {
    Test-Success "ErrorMessage column added to run summary for better diagnostics"
}
else {
    Test-Failure "ErrorMessage column not found in run summary"
}

#endregion

#region Test 6: Delete Safety Gates
Write-Host ""
Write-Host "Test 6: Delete safety gates" -ForegroundColor Cyan

# Test 6a: Verify ExportOnly prevents deletion
# The pattern is: $script:EnableDelete = (-not $ExportOnly) -and $ConfirmDelete -and $Force
if ($scriptContent -match 'not \$ExportOnly.*EnableDelete' -or $scriptContent -match 'EnableDelete.*-not.*ExportOnly') {
    Test-Success "ExportOnly switch prevents deletion"
}
else {
    Test-Failure "ExportOnly may not properly prevent deletion"
}

# Test 6b: Verify both ConfirmDelete and Force required
if ($scriptContent -match 'ConfirmDelete.*Force' -or $scriptContent -match '\$EnableDelete.*ConfirmDelete.*Force') {
    Test-Success "Both ConfirmDelete and Force required for deletion"
}
else {
    Test-Failure "Delete gates may not require both switches"
}

# Test 6c: Check ShouldProcess usage
if ($scriptContent -match 'ShouldProcess.*Delete') {
    Test-Success "ShouldProcess is used for delete confirmation"
}
else {
    Test-Failure "ShouldProcess not found for delete operations"
}

#endregion

#region Summary
Write-Host ""
Write-Host "=== Test Summary ===" -ForegroundColor Cyan
Write-Host "Passed: $script:PassedCount" -ForegroundColor Green
Write-Host "Failed: $script:FailedCount" -ForegroundColor Red
Write-Host ""

if ($script:FailedCount -gt 0) {
    Write-Host "Some tests failed. Review the output above." -ForegroundColor Yellow
    exit 1
}
else {
    Write-Host "All tests passed!" -ForegroundColor Green
    exit 0
}
#endregion
