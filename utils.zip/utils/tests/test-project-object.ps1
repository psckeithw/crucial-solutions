$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{Authorization = "Basic $auth" }

# Get full project object with all properties
$proj = Invoke-RestMethod -Uri 'https://dev.azure.com/aha-bt/_apis/projects/Professional%20Volunteer%20Search?api-version=7.1' -Headers $headers
$proj | ConvertTo-Json -Depth 10
