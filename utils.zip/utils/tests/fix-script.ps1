$file = 'c:\code\Niche Sandbox\dev\Niche Sandbox\utils\scripts\project-collection\export\export-and-delete-ado-projects.ps1'
$content = Get-Content -Path $file -Raw

$old = '$idsString = ($WorkItemIds | ForEach-Object { "ids=$_" }) -join ''&'''
$new = @'
$idsString = "ids=" + ($WorkItemIds -join ',')
'@

$content = $content -replace [regex]::Escape($old), $new
$content | Set-Content -Path $file -NoNewline -Encoding UTF8
Write-Host "Done - replaced"
