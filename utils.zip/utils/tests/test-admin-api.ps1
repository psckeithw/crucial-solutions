$pat = [Environment]::GetEnvironmentVariable('AZDO_PAT', 'Process')
$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$headers = @{Authorization = "Basic $auth" }

$projectName = "Professional Volunteer Search"
$projectNamespaceId = '52d39943-cb85-4d7f-8fa8-c6baac873819'

# Get project ID
$proj = Invoke-RestMethod -Uri "https://dev.azure.com/aha-bt/_apis/projects/$([uri]::EscapeDataString($projectName))?api-version=7.1" -Headers $headers
$projectId = $proj.id
Write-Host "Project: $projectName"
Write-Host "Project ID: $projectId"

# Get ACLs with the $PROJECT token format
$token = "`$PROJECT:vstfs:///Classification/TeamProject/$projectId"
$encodedToken = [uri]::EscapeDataString($token)
$aclUrl = "https://dev.azure.com/aha-bt/_apis/accesscontrollists/$projectNamespaceId`?api-version=7.1&token=$encodedToken&includeExtendedInfo=true"

Write-Host "`nFetching ACLs..."
$projectAcls = Invoke-RestMethod -Uri $aclUrl -Headers $headers -Method Get

$adminBits = 1
$adminBits2 = 2
$allAdminDescriptors = @()

Write-Host "`nLooking for Full Control or Administer permissions..."
foreach ($acl in $projectAcls.value) {
    if ($acl.acesDictionary) {
        foreach ($prop in $acl.acesDictionary.PSObject.Properties) {
            $ace = $prop.Value
            $descriptor = $prop.Name
            
            $hasFullControl = ($ace.allow -band $adminBits) -ne 0
            $hasAdminister = ($ace.allow -band $adminBits2) -ne 0
            
            if ($hasFullControl -or $hasAdminister) {
                $allAdminDescriptors += $descriptor
                Write-Host "Admin descriptor: $descriptor"
                
                # Try to resolve it
                if ($descriptor -match 'ClaimsIdentity;[^\\]+\\(.*)') {
                    $userName = $matches[1]
                    Write-Host "  -> Extracted: $userName"
                }
                elseif ($descriptor -match '^Microsoft\.TeamFoundation\.Identity;S-1-9-(.+)') {
                    try {
                        $lookupUrl = "https://dev.azure.com/aha-bt/_apis/graph/subjects?api-version=7.1&subjectDescriptors=$([uri]::EscapeDataString($descriptor))"
                        $subjectInfo = Invoke-RestMethod -Uri $lookupUrl -Headers $headers -Method Get
                        if ($subjectInfo -and $subjectInfo.value) {
                            foreach ($subj in $subjectInfo.value) {
                                Write-Host "  -> Resolved: $($subj.displayName) <$($subj.mailAddress)>"
                            }
                        }
                    }
                    catch {
                        Write-Host "  -> Could not resolve"
                    }
                }
            }
        }
    }
}

Write-Host "`nTotal admin descriptors: $($allAdminDescriptors.Count)"
