# Debug script - try different approaches to get project admins

$modulePath = Join-Path $PSScriptRoot 'utils\modules\AzDO-Helpers.psm1'
Import-Module -Name $modulePath -Force

$pat = Get-AdoPat
$headers = Get-AdoHeaders -Pat $pat

$org = 'aha-bt'
$projectName = 'PHD Data Quality'

# Get project ID
$projectUrl = "https://dev.azure.com/$org/_apis/projects/" + [uri]::EscapeDataString($projectName) + "?api-version=7.1"
$projectInfo = Invoke-RestMethod -Uri $projectUrl -Headers $headers -Method Get
$projectId = $projectInfo.id

Write-Host "Project: $projectName" -ForegroundColor Cyan
Write-Host "Project ID: $projectId" -ForegroundColor Cyan

# Approach 1: Try the explicit "administrators" endpoint
Write-Host "`n=== Approach 1: Security namespaces API ===" -ForegroundColor Yellow
$securityNamespaceUrl = "https://dev.azure.com/$org/_apis/securitynamespaces?api-version=7.1"
$namespaces = Invoke-RestMethod -Uri $securityNamespaceUrl -Headers $headers -Method Get

# Find the project namespace
$projectNs = $namespaces.value | Where-Object { $_.namespaceId -eq '52d39943-cb85-4d7f-8fa8-c6baac873819' }
Write-Host "Project namespace: $($projectNs.name)"

# Get permissions for the project
$token = "$projectId"
$permissionsUrl = "https://dev.azure.com/$org/_apis/securitynamespaces/52d39943-cb85-4d7f-8fa8-c6baac873819?api-version=7.1&localizedBitwiseAndCheck=false"
$permissions = Invoke-RestMethod -Uri $permissionsUrl -Headers $headers -Method Get

# Look at all actions
Write-Host "Available actions:"
foreach ($action in $permissions.actions | Select-Object -First 20) {
    Write-Host "  $($action.name) (bit: $($action.bit))"
}

# Approach 2: Try the "get permissions" API
Write-Host "`n=== Approach 2: Direct ACL query ===" -ForegroundColor Yellow
$projectNamespaceId = '52d39943-cb85-4d7f-8fa8-c6baac873819'

# Get ACLs for the project
$projectToken = "`$PROJECT:vstfs:///Classification/TeamProject/$projectId"
$encodedToken = [uri]::EscapeDataString($projectToken)
$aclUrl = "https://dev.azure.com/$org/_apis/accesscontrollists/$projectNamespaceId`?api-version=7.1&token=$encodedToken&includeExtendedInfo=true"

Write-Host "ACL URL: $aclUrl"

$acls = Invoke-RestMethod -Uri $aclUrl -Headers $headers -Method Get
Write-Host "Found $($acls.value.Count) ACL entries"

# Print all descriptors with their permissions
Write-Host "`nAll entries with permissions:"
foreach ($acl in $acls.value) {
    if ($acl.acesDictionary) {
        foreach ($prop in $acl.acesDictionary.PSObject.Properties) {
            $descriptor = $prop.Name
            $ace = $prop.Value
            Write-Host "Descriptor: $descriptor"
            Write-Host "  Allow: $($ace.allow), Deny: $($ace.deny)"
            
            # Check if this is a user we can resolve
            if ($descriptor -match 'S-1-9-') {
                # Try to resolve
                try {
                    $lookupUrl = "https://dev.azure.com/$org/_apis/graph/subjects?api-version=7.1&subjectDescriptors=$([uri]::EscapeDataString($descriptor))"
                    $subject = Invoke-RestMethod -Uri $lookupUrl -Headers $headers -Method Get
                    if ($subject.value) {
                        Write-Host "  RESOLVED: $($subject.value[0].displayName) <$($subject.value[0].mailAddress)>" -ForegroundColor Green
                    }
                }
                catch {
                    Write-Host "  Could not resolve" -ForegroundColor Red
                }
            }
        }
    }
}

# Approach 3: Try the explicit project administrators API
Write-Host "`n=== Approach 3: Project Admin API ===" -ForegroundColor Yellow

# Try to get security groups and users
$groupsUrl = "https://dev.azure.com/$org/_apis/securitygroups?api-version=7.1&scope=$projectId"
try {
    $groups = Invoke-RestMethod -Uri $groupsUrl -Headers $headers -Method Get
    Write-Host "Found $($groups.value.Count) groups"
    foreach ($group in $groups.value | Select-Object -First 5) {
        Write-Host "  $($group.displayName)"
    }
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}

# Try to get project-level users
$usersUrl = "https://dev.azure.com/$org/_apis/graph/users?api-version=7.1&scope=$projectId"
try {
    $users = Invoke-RestMethod -Uri $usersUrl -Headers $headers -Method Get
    Write-Host "Found $($users.value.Count) users"
    foreach ($user in $users.value | Select-Object -First 5) {
        Write-Host "  $($user.displayName) <$($user.mailAddress)>"
    }
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
}
