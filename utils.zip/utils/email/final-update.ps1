
try {
    # Define the string of new data
    $newDataString = '"Brenda May" <Brenda.May@heart.org>; "Brooke Kampe" <Brooke.Kampe@heart.org>; "David Fung" <David.Fung@heart.org>; "Isade Salcedo-Torres" <Isade Salcedo-Torres>; "Jillian Candaffio" <Jillian.Candaffio@heart.org>; "JoAnne Pineda" <JoAnne.Pineda@heart.org>; "Jody Mattson" <jody.mattson@heart.org>; "Joe Williams" <Joe Williams>; "Josh Onia" <Josh.Onia@heart.org>; "Kami Sutton-Hieronymus" <kami.sutton@heart.org>; "Kanitha Dunkins Karanja" <Kanitha.Dunkins@heart.org>; "Katie Southard" <Katie.Southard@heart.org>; "Kristen Waller" <Kristen.Waller@heart.org>; "Liz Adams" <Liz Adams>; "Luis Teixeira" <Luis Teixeira>; "Max Gritzuk" <Max Gritzuk>; "Melanie Turner" <Melanie.Turner@heart.org>; "Morgan Moore" <Morgan.Moore@heart.org>; "Mukesh Wani" <mukesh.wani@heart.org>; "Nichole Collia" <Nichole.Collia@heart.org>; "Sam Bender" <Sam Bender>; "Samantha Johnson" <samantha.johnson@heart.org>; "Sarah Bowden" <Sarah Bowden>; "Shelley Davis" <Shelley.Davis@heart.org>; "Chelsea" <Leemon@heart.org>; "Joe Williams" <Joe Williams>; "Liz Adams" <Liz Adams>; "Luis Teixeira" <Luis Teixeira>; "Sam Bender" <Sam Bender>'

    # Create a hash map to store the new name-email pairs
    $newEmailMap = @{}
    $entries = $newDataString.Split(';')
    foreach ($entry in $entries) {
        $match = [regex]::Match($entry, '"([^"]+)"\s*<([^>]+)>')
        if ($match.Success) {
            $name = $match.Groups[1].Value.Trim()
            $email = $match.Groups[2].Value.Trim()
            # Only add valid emails to the map
            if ($email -like '*@*') {
                $newEmailMap[$name] = $email
            }
        }
    }

    # Import the existing CSV file
    $data = Import-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv"

    # Update the data
    foreach ($row in $data) {
        if ([string]::IsNullOrWhiteSpace($row.Email) -and $newEmailMap.ContainsKey($row.Name)) {
            $row.Email = $newEmailMap[$row.Name]
        }
    }

    # Export the updated data back to the CSV file
    $data | Export-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv" -NoTypeInformation

    Write-Output "Final update complete. The file matched_emails.csv has been updated with the provided emails."
}
catch {
    Write-Error "An error occurred during the final update: $_"
}
