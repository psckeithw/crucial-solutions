<#
  Scan Inbox (+subfolders), subject contains "smartsheet", BODY only.
  Extract:
    1) Distinct person names (simple heuristic: 2–4 capitalized words)
    2) Any tokens matching numbers.xxxx.numbers → \b\d+\.[A-Za-z]{4}\.\d+\b
  Outputs two CSVs in the user's Downloads folder.

  Usage:
    - Open Windows PowerShell
    - Paste this entire script and press Enter
#>

# ---------------------------
# Helper: Resolve Downloads
# ---------------------------
function Get-DownloadsPath {
  try {
    $shell = New-Object -ComObject Shell.Application
    $downloads = $shell.Namespace('shell:Downloads').Self.Path
    if ($downloads) { return $downloads }
  } catch { }
  # Fallback
  return Join-Path $env:USERPROFILE 'Downloads'
}

# ---------------------------
# Config
# ---------------------------
$SubjectFilterPattern = '(?i)smartsheet'                  # subject contains "smartsheet", case-insensitive
$TokenRegex           = '\b\d+\.[A-Za-z]{4}\.\d+\b'      # numbers.xxxx.numbers
$NameRegex            = '(?<!\S)([A-Z][A-Za-z\-\u2011\u2013\u2014''\(\)]+(?:\s[A-Z][A-Za-z\-\u2011\u2013\u2014''\(\)]+){0,3})(?!\S)'
$IncludeSubfolders    = $true

# Blacklist: sender-member combinations to exclude
$Blacklist = @(
  @{Sender='Bethany Slawnikowski'; Member='Ed Ernest'},
  @{Sender='Bethany Slawnikowski'; Member='Keith Watson'},
  @{Sender='Bethany Slawnikowski'; Member='Mary Ellen Joseph'}
)

# Output paths
$OutDir = Get-DownloadsPath
$CombinedCsv = Join-Path $OutDir 'members_budgetcodes.csv'
$LogPath     = Join-Path $OutDir 'scan_smartsheet_inbox.log'

# ---------------------------
# Initialize Outlook COM
# ---------------------------
Add-Type -AssemblyName "Microsoft.Office.Interop.Outlook" | Out-Null
$ol = $null
$ns = $null
try {
  $ol = New-Object -ComObject Outlook.Application
  $ns = $ol.GetNamespace("MAPI")
} catch {
  Write-Host "ERROR: Unable to start Outlook COM. Make sure Outlook is installed and configured."
  throw
}

# ---------------------------
# Collect folders (Inbox + subfolders)
# ---------------------------
$olFolderInbox = 6
$inbox = $ns.GetDefaultFolder($olFolderInbox)
$foldersToScan = New-Object System.Collections.Generic.List[Object]
$foldersToScan.Add($inbox)

if ($IncludeSubfolders) {
  $queue = New-Object System.Collections.Queue
  $queue.Enqueue($inbox)
  while ($queue.Count -gt 0) {
    $f = $queue.Dequeue()
    foreach ($sf in $f.Folders) {
      $foldersToScan.Add($sf)
      $queue.Enqueue($sf)
    }
  }
}

# ---------------------------
# Prep data structures
# ---------------------------
$NameRe   = [regex]::new($NameRegex)
$TokenRe  = [regex]::new($TokenRegex)
$namesSet = New-Object System.Collections.Generic.HashSet[string] ([StringComparer]::OrdinalIgnoreCase)
$rows     = New-Object System.Collections.Generic.List[Object]
$scanned  = 0
$matched  = 0

# ---------------------------
# Helper: Parse header lists from body
# ---------------------------
function Get-HeaderValue {
  param(
    [string[]]$Lines,
    [string]$HeaderName
  )

  for ($i = 0; $i -lt $Lines.Count; $i++) {
    $line = $Lines[$i]
    if ($line -match "(?i)^\s*$HeaderName\s*:\s*(.*)$") {
      $value = $Matches[1].Trim()
      $j = $i + 1
      while ($j -lt $Lines.Count) {
        $next = $Lines[$j]
        if ([string]::IsNullOrWhiteSpace($next)) { break }
        if ($next -match '(?i)^\s*(From|To|Sent|Subject|Cc|Bcc)\s*:') { break }
        if ($next -match '^\s+') {
          $value = ($value + ' ' + $next.Trim()).Trim()
          $j++
          continue
        }
        break
      }
      if (-not [string]::IsNullOrWhiteSpace($value)) { return $value }
    }
  }
  return $null
}

function Parse-HeaderList {
  param(
    [string]$HeaderValue
  )

  if ([string]::IsNullOrWhiteSpace($HeaderValue)) { return @() }
  $clean = $HeaderValue -replace '<[^>]+>', ''
  $clean = $clean -replace '[<>]', ''
  $parts = $clean -split '\s*;\s*|\s*,\s*'
  $trimChars = [char[]]@(' ', '"', "'")
  $parts | ForEach-Object { $_.Trim($trimChars) } | Where-Object { $_ -and $_.Length -gt 1 }
}

function Convert-HtmlToText {
  param(
    [string]$Html
  )

  if ([string]::IsNullOrWhiteSpace($Html)) { return '' }
  $text = $Html -replace '(?is)<br\s*/?>', "`n"
  $text = $text -replace '(?is)</p>', "`n"
  $text = $text -replace '(?is)<[^>]+>', ' '
  $text = $text -replace '&nbsp;', ' '
  return $text
}

# ---------------------------
# Logging
# ---------------------------
"$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Start scan. Output directory: $OutDir" | Out-File -FilePath $LogPath -Encoding UTF8

# ---------------------------
# Scan messages
# ---------------------------
foreach ($folder in $foldersToScan) {
  foreach ($item in $folder.Items) {
    try {
      if ($null -eq $item) { continue }
      # Only MailItem (olMail = 43)
      if ($item.Class -ne 43) { continue }
      $scanned++

      $subject = $item.Subject
      if ($subject -and ($subject -match $SubjectFilterPattern)) {
        $matched++

        # BODY ONLY
        $body = ($item.Body | Out-String)
        if ([string]::IsNullOrWhiteSpace($body)) {
          $body = Convert-HtmlToText -Html $item.HTMLBody
        }
        if ([string]::IsNullOrWhiteSpace($body)) {
          continue
        }

        # Parse header lines from BODY (From/To)
        $lines = $body -split "`r?`n"
        $fromHeader = Get-HeaderValue -Lines $lines -HeaderName 'From'
        $toHeader   = Get-HeaderValue -Lines $lines -HeaderName 'To'

        $senderCandidate = if ($fromHeader) { (Parse-HeaderList -HeaderValue $fromHeader)[0] } else { $null }
        if ($senderCandidate -and $senderCandidate.Length -gt 2 -and $senderCandidate -match $NameRegex) {
          $senderName = $senderCandidate
        } else {
          $senderName = $item.SenderName
        }
        if ($toHeader) {
          $localNames = Parse-HeaderList -HeaderValue $toHeader | Select-Object -Unique
        } else {
          $localNames = Parse-HeaderList -HeaderValue $item.To | Select-Object -Unique
        }

        if ($localNames.Count -eq 0) {
          $recipients = @()
          foreach ($r in $item.Recipients) {
            if ($r -and $r.Name) { $recipients += $r.Name }
          }
          $localNames = $recipients | Select-Object -Unique
        }

        $localNames = $localNames | Where-Object { $_ -and $_.Trim() } | ForEach-Object { $_.Trim() }
        if ($senderName) {
          $localNames = $localNames | Where-Object { $_ -and ($_ -ne $senderName) }
        }
        $localNames = $localNames | Select-Object -Unique

        foreach ($n in $localNames) {
          if ($n -match $NameRegex) { [void]$namesSet.Add($n) }
        }

        # Extract tokens from BODY matching numbers.xxxx.numbers
        $tokens = $TokenRe.Matches($body) | ForEach-Object { $_.Value } | Select-Object -Unique

        # Build rows (always include members even if tokens are missing)
        if ($localNames.Count -gt 0) {
          if ($tokens.Count -gt 0) {
            foreach ($t in $tokens) {
              foreach ($n in $localNames) {
                $isBlacklisted = $false
                foreach ($bl in $Blacklist) {
                  if ($senderName -eq $bl.Sender -and $n -eq $bl.Member) {
                    $isBlacklisted = $true
                    break
                  }
                }
                if (-not $isBlacklisted) {
                  $rows.Add([pscustomobject]@{
                    Sender     = $senderName
                    Members    = $n
                    BudgetCode = $t
                  })
                }
              }
            }
          } else {
            foreach ($n in $localNames) {
              $isBlacklisted = $false
              foreach ($bl in $Blacklist) {
                if ($senderName -eq $bl.Sender -and $n -eq $bl.Member) {
                  $isBlacklisted = $true
                  break
                }
              }
              if (-not $isBlacklisted) {
                $rows.Add([pscustomobject]@{
                  Sender     = $senderName
                  Members    = $n
                  BudgetCode = ''
                })
              }
            }
          }
        }
      }
    } catch {
      # Swallow and continue
      $_.Exception.Message | Out-File -FilePath $LogPath -Append -Encoding UTF8
      continue
    }
  }
}

# ---------------------------
# Write CSV
# ---------------------------
try {
  $rows | Sort-Object Sender,Members,BudgetCode | Export-Csv -Path $CombinedCsv -NoTypeInformation -Encoding UTF8 -Delimiter ';'
} catch {
  Write-Host "ERROR: Writing CSVs failed: $($_.Exception.Message)"
  throw
}

# ---------------------------
# Summary
# ---------------------------
$summary = @"
Scan complete.

Scanned messages: $scanned
Subject-matched ("smartsheet"): $matched
Distinct names: $($namesSet.Count)
Rows: $($rows.Count)

Outputs:
 - $CombinedCsv
Log: $LogPath
"@

$summary | Tee-Object -FilePath $LogPath -Append | Write-Host