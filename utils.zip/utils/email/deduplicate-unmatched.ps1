
# Function to create a character frequency signature from a string
function Get-CharSignature {
    param (
        [string]$inputString
    )
    # Clean the string: keep only letters, convert to lowercase
    $cleanedString = ($inputString -replace '[^a-zA-Z]', '').ToLower()
    
    # Create a sorted character array to represent the signature
    $charArray = $cleanedString.ToCharArray()
    [array]::Sort($charArray)
    return -join $charArray
}

# Function to normalize an email prefix
function Normalize-Email {
    param (
        [string]$email
    )
    # Get the part before @
    $emailPrefix = ($email.Split('@')[0])
    
    # Remove 't-' and 'consultant'
    $cleanedPrefix = $emailPrefix -replace '^t-', '' `
                                 -replace 'consultant', ''
    
    return Get-CharSignature -inputString $cleanedPrefix
}

# Main script execution
try {
    # Import the CSV file
    $data = Import-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv"

    # Separate the data: matched/unmatched names, and unmatched emails
    $existingData = $data | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) }
    $unmatchedEmails = $data | Where-Object { [string]::IsNullOrWhiteSpace($_.Name) -and -not [string]::IsNullOrWhiteSpace($_.Email) }

    $deduplicatedEmails = @()
    $seenSignatures = New-Object 'System.Collections.Generic.HashSet[string]'

    # Process and deduplicate the unmatched emails
    foreach ($item in $unmatchedEmails) {
        $signature = Normalize-Email -email $item.Email
        if ($seenSignatures.Add($signature)) {
            $deduplicatedEmails += $item
        }
    }

    # Combine the existing data with the deduplicated unmatched emails
    $finalResults = @()
    $finalResults += $existingData
    $finalResults += $deduplicatedEmails

    # Export the results back to the CSV file
    $finalResults | Export-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv" -NoTypeInformation

    Write-Output "Deduplication of unmatched emails is complete. The file matched_emails.csv has been updated."
}
catch {
    Write-Error "An error occurred during deduplication: $_"
}
