
try {
    # Import the CSV file
    $data = Import-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv"

    # Sort the data by the 'Name' column
    $sortedData = $data | Sort-Object -Property Name

    # Export the sorted results back to the CSV file
    $sortedData | Export-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv" -NoTypeInformation

    Write-Output "Sorting complete. The file matched_emails.csv has been updated."
}
catch {
    Write-Error "An error occurred during sorting: $_"
}
