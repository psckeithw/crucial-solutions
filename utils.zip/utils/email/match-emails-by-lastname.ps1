
# Function to extract the last name from a full name
function Get-LastName {
    param (
        [string]$fullName
    )
    if ([string]::IsNullOrWhiteSpace($fullName)) {
        return ""
    }
    $parts = $fullName.Trim().Split(' ')
    return $parts[-1].ToLower()
}

# Function to extract the last name from an email prefix
function Get-LastNameFromEmail {
    param (
        [string]$email
    )
    if ([string]::IsNullOrWhiteSpace($email)) {
        return ""
    }
    $emailPrefix = ($email.Split('@')[0]).ToLower()
    $emailPrefix = $emailPrefix -replace '^t-', '' -replace '\.consultant', ''
    $nameParts = $emailPrefix.Split('.')
    return $nameParts[-1]
}

# Main script execution
try {
    # Import the CSV file
    $data = Import-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv"

    # Separate the data
    $matched = $data | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) -and -not [string]::IsNullOrWhiteSpace($_.Email) }
    $unmatchedNames = $data | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) -and [string]::IsNullOrWhiteSpace($_.Email) }
    $unmatchedEmails = $data | Where-Object { [string]::IsNullOrWhiteSpace($_.Name) -and -not [string]::IsNullOrWhiteSpace($_.Email) }

    $unmatchedEmailList = [System.Collections.Generic.List[string]]::new()
    $unmatchedEmails | ForEach-Object { $unmatchedEmailList.Add($_.Email) }

    $newlyMatched = @()
    $stillUnmatchedNames = @()

    # Try to match based on last name
    foreach ($item in $unmatchedNames) {
        $lastName = Get-LastName -fullName $item.Name
        $foundMatch = $false
        if (-not [string]::IsNullOrWhiteSpace($lastName)) {
            $matchingEmail = $null
            foreach ($email in $unmatchedEmailList) {
                $emailLastName = Get-LastNameFromEmail -email $email
                if ($lastName -eq $emailLastName) {
                    $matchingEmail = $email
                    break
                }
            }

            if ($matchingEmail) {
                $newlyMatched += [pscustomobject]@{
                    Name  = $item.Name
                    Email = $matchingEmail
                }
                $unmatchedEmailList.Remove($matchingEmail)
                $foundMatch = $true
            }
        }
        
        if (-not $foundMatch) {
            $stillUnmatchedNames += $item
        }
    }

    # Combine all results
    $finalResults = @()
    $finalResults += $matched
    $finalResults += $newlyMatched
    
    # Add back names that are still unmatched
    foreach ($item in $stillUnmatchedNames) {
        $finalResults += [pscustomobject]@{
            Name  = $item.Name
            Email = ""
        }
    }

    # Add remaining unmatched emails
    foreach ($email in $unmatchedEmailList) {
        $finalResults += [pscustomobject]@{
            Name  = ""
            Email = $email
        }
    }

    # Export the results back to the CSV file
    $finalResults | Export-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv" -NoTypeInformation

    Write-Output "Secondary matching complete. The file matched_emails.csv has been updated."
}
catch {
    Write-Error "An error occurred during secondary matching: $_"
}
