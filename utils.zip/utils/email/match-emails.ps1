
# Function to create a character frequency signature from a string
function Get-CharSignature {
    param (
        [string]$inputString
    )
    # Clean the string: keep only letters, convert to lowercase
    $cleanedString = ($inputString -replace '[^a-zA-Z]', '').ToLower()
    
    # Create a sorted character array to represent the signature
    $charArray = $cleanedString.ToCharArray()
    [array]::Sort($charArray)
    return -join $charArray
}

# Function to normalize a name string
function Normalize-Name {
    param (
        [string]$name
    )
    # Remove parenthetical parts, suffixes, and middle initials
    $cleanedName = $name -replace '\s*\(.*\)\s*', '' `
                         -replace '\s+(Jr|Sr|I{1,3}|IV|V)$', '' `
                         -replace '\s+[A-Z]\.\s*', ' '
    
    return Get-CharSignature -inputString $cleanedName
}

# Function to normalize an email prefix
function Normalize-Email {
    param (
        [string]$email
    )
    # Get the part before @
    $emailPrefix = ($email.Split('@')[0])
    
    # Remove 't-' and 'consultant'
    $cleanedPrefix = $emailPrefix -replace '^t-', '' `
                                 -replace 'consultant', ''
    
    return Get-CharSignature -inputString $cleanedPrefix
}

# Main script execution
try {
    # Import the CSV file
    $data = Import-Csv -Path "c:\Users\Keith.Watson\Downloads\emails_original.csv"

    # Create lists to hold names and emails with their signatures
    $names = @()
    $emails = @()

    # Process each row of the CSV
    foreach ($row in $data) {
        if (-not [string]::IsNullOrWhiteSpace($row.Name)) {
            $names += [pscustomobject]@{
                Original = $row.Name
                Signature = Normalize-Name -name $row.Name
            }
        }
        if (-not [string]::IsNullOrWhiteSpace($row.Email)) {
            $emails += [pscustomobject]@{
                Original = $row.Email
                Signature = Normalize-Email -email $row.Email
            }
        }
    }

    # Create a hash table for emails for quick lookups
    $emailMap = @{}
    foreach ($email in $emails) {
        if (-not $emailMap.ContainsKey($email.Signature)) {
            $emailMap[$email.Signature] = [System.Collections.Generic.List[string]]::new()
        }
        $emailMap[$email.Signature].Add($email.Original)
    }

    $results = @()
    $unmatchedEmails = [System.Collections.Generic.List[string]]::new()
    $emails | ForEach-Object { $unmatchedEmails.Add($_.Original) }

    # Match names to emails
    foreach ($name in $names) {
        $matchedEmail = $null
        if ($emailMap.ContainsKey($name.Signature) -and $emailMap[$name.Signature].Count -gt 0) {
            $matchedEmail = $emailMap[$name.Signature][0]
            $emailMap[$name.Signature].RemoveAt(0)
            $unmatchedEmails.Remove($matchedEmail)
        }
        
        $results += [pscustomobject]@{
            Name = $name.Original
            Email = $matchedEmail
        }
    }

    # Add remaining unmatched emails to the end of the results
    foreach ($unmatched in $unmatchedEmails) {
        $results += [pscustomobject]@{
            Name = ""
            Email = $unmatched
        }
    }

    # Export the results to a new CSV file
    $results | Export-Csv -Path "matched_emails.csv" -NoTypeInformation

    Write-Output "Processing complete. The matched data has been saved to matched_emails.csv"
}
catch {
    Write-Error "An error occurred: $_"
}
