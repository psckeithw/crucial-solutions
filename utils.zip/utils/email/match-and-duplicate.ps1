
# Function to create a character frequency signature from a string
function Get-CharSignature {
    param (
        [string]$inputString
    )
    # Clean the string: keep only letters, convert to lowercase
    $cleanedString = ($inputString -replace '[^a-zA-Z]', '').ToLower()
    
    # Create a sorted character array to represent the signature
    $charArray = $cleanedString.ToCharArray()
    [array]::Sort($charArray)
    return -join $charArray
}

# Function to normalize a name string
function Normalize-Name {
    param (
        [string]$name
    )
    # Remove parenthetical parts, suffixes, and middle initials
    $cleanedName = $name -replace '\s*\(.*\)\s*', '' `
                         -replace '\s+(Jr|Sr|I{1,3}|IV|V)$', '' `
                         -replace '\s+[A-Z]\.\s*', ' '
    
    return Get-CharSignature -inputString $cleanedName
}

# Function to normalize an email prefix
function Normalize-Email {
    param (
        [string]$email
    )
    # Get the part before @
    $emailPrefix = ($email.Split('@')[0])
    
    # Remove 't-' and 'consultant'
    $cleanedPrefix = $emailPrefix -replace '^t-', '' `
                                 -replace 'consultant', ''
    
    return Get-CharSignature -inputString $cleanedPrefix
}

# Main script execution
try {
    # Import the original CSV file to start fresh
    $data = Import-Csv -Path "c:\Users\Keith.Watson\Downloads\emails_original.csv"

    # Create lists to hold names and emails with their signatures
    $names = @()
    $emails = @()

    # Process each row of the CSV
    foreach ($row in $data) {
        if (-not [string]::IsNullOrWhiteSpace($row.Name)) {
            $names += [pscustomobject]@{
                Original = $row.Name
                Signature = Normalize-Name -name $row.Name
            }
        }
        if (-not [string]::IsNullOrWhiteSpace($row.Email)) {
            $emails += [pscustomobject]@{
                Original = $row.Email
                Signature = Normalize-Email -email $row.Email
            }
        }
    }

    # Create a hash table for emails for quick lookups
    $emailMap = @{}
    foreach ($email in $emails) {
        if (-not $emailMap.ContainsKey($email.Signature)) {
            $emailMap[$email.Signature] = [System.Collections.Generic.List[string]]::new()
        }
        $emailMap[$email.Signature].Add($email.Original)
    }

    $results = @()
    $unmatchedEmails = [System.Collections.Generic.List[string]]::new()
    $emails | ForEach-Object { $unmatchedEmails.Add($_.Original) }

    # --- Initial Matching ---
    foreach ($name in $names) {
        $matchedEmail = $null
        if ($emailMap.ContainsKey($name.Signature) -and $emailMap[$name.Signature].Count -gt 0) {
            $matchedEmail = $emailMap[$name.Signature][0]
            $emailMap[$name.Signature].RemoveAt(0)
            $unmatchedEmails.Remove($matchedEmail)
        }
        
        $results += [pscustomobject]@{
            Name = $name.Original
            Email = $matchedEmail
        }
    }

    # --- Duplicate Name Matching ---
    # Create a map of matched names to their emails
    $nameToEmailMap = @{}
    $results | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Email) } | ForEach-Object {
        if (-not $nameToEmailMap.ContainsKey($_.Name)) {
            $nameToEmailMap[$_.Name] = $_.Email
        }
    }

    # Second pass to fill in emails for duplicate names
    for ($i = 0; $i -lt $results.Count; $i++) {
        $result = $results[$i]
        if ([string]::IsNullOrWhiteSpace($result.Email) -and $nameToEmailMap.ContainsKey($result.Name)) {
            $results[$i].Email = $nameToEmailMap[$result.Name]
        }
    }

    # --- Final Cleanup ---
    # Rebuild the list of unmatched emails based on the updated results
    $allUsedEmails = $results.Email | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
    $finalUnmatchedEmails = $emails.Original | Where-Object { $_ -notin $allUsedEmails }

    # Remove placeholder rows for unmatched emails from the main results
    $finalResults = $results | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) }

    # Add the truly unmatched emails at the end
    foreach ($unmatched in $finalUnmatchedEmails) {
        $finalResults += [pscustomobject]@{
            Name = ""
            Email = $unmatched
        }
    }

    # Export the results to a new CSV file
    $finalResults | Export-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv" -NoTypeInformation

    Write-Output "Processing complete with duplicate name matching. The file matched_emails.csv has been updated."
}
catch {
    Write-Error "An error occurred: $_"
}
