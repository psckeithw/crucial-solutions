
try {
    # Import the CSV file
    $data = Import-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails.csv"

    # Separate matched data from orphaned emails
    $matchedData = $data | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Name) }
    $orphanedEmails = $data | Where-Object { [string]::IsNullOrWhiteSpace($_.Name) -and -not [string]::IsNullOrWhiteSpace($_.Email) } | Select-Object -ExpandProperty Email | Sort-Object

    $results = @()
    $maxRows = [Math]::Max($matchedData.Count, $orphanedEmails.Count)

    for ($i = 0; $i -lt $maxRows; $i++) {
        $name = if ($i -lt $matchedData.Count) { $matchedData[$i].Name } else { "" }
        $email = if ($i -lt $matchedData.Count) { $matchedData[$i].Email } else { "" }
        $orphaned = if ($i -lt $orphanedEmails.Count) { $orphanedEmails[$i] } else { "" }

        $results += [pscustomobject]@{
            Name = $name
            Email = $email
            "Orphaned Emails" = $orphaned
        }
    }

    # Export the results back to the CSV file
    $results | Export-Csv -Path "c:\code\Niche Sandbox\dev\Niche Sandbox\matched_emails_with_orphans.csv" -NoTypeInformation

    Write-Output "Processing complete. The file matched_emails_with_orphans.csv has been created."
}
catch {
    Write-Error "An error occurred: $_"
}
