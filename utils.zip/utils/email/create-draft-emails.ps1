#Requires -Version 7.0
<#
.SYNOPSIS
    Creates Outlook draft emails for Azure DevOps project decommission notifications.
.DESCRIPTION
    Reads the project-admins.json file and the JSON email template,
    then creates draft emails in Outlook for each project using Outlook COM automation.
    NOTE: This script ONLY reads from project-admins.json - it does NOT modify or regenerate it.
    The JSON should be updated externally before running this script.
.NOTES
    - Does NOT send emails - creates drafts only for manual review
    - Requires Outlook to be installed
    - Uses Outlook COM automation
    - If Outlook COM fails, exports .msg files instead
    - Does NOT modify project-admins.json - uses it as static input
#>

param(
    [Parameter()]
    [string]$JsonPath = "$PSScriptRoot\project-admins.json",

    [Parameter()]
[string]$TemplatePath = "$PSScriptRoot\..\scripts\project-collection\export\DecommissionEmailTemplate.json",

    [Parameter()]
    [switch]$UseMsgExport
)

# Check if JSON exists
if (-not (Test-Path -LiteralPath $JsonPath)) {
    Write-Error "JSON file not found: $JsonPath"
    exit 1
}

# Check if template exists
if (-not (Test-Path -LiteralPath $TemplatePath)) {
    Write-Error "Template file not found: $TemplatePath"
    exit 1
}

# Load JSON data
Write-Host "Loading project data from: $JsonPath" -ForegroundColor Cyan
$jsonData = Get-Content -Path $JsonPath -Raw | ConvertFrom-Json
$projects = $jsonData.projects

# Load JSON template
Write-Host "Loading email template from: $TemplatePath" -ForegroundColor Cyan
$template = Get-Content -Path $TemplatePath -Raw | ConvertFrom-Json

Write-Host "Found $($projects.Count) projects to process`n" -ForegroundColor Green

# Try to create Outlook COM object
$outlook = $null
$useOutlook = $false

if (-not $UseMsgExport) {
    try {
        # Try to get existing Outlook instance first
        $outlook = [System.Runtime.Interopservices.Marshal]::GetActiveObject('Outlook.Application')
        if ($outlook) {
            Write-Host "Connected to existing Outlook instance" -ForegroundColor Green
            $useOutlook = $true
        }
    }
    catch {
        # No existing instance, try to create new one
        try {
            $outlook = New-Object -ComObject Outlook.Application
            $namespace = $outlook.GetNamespace('MAPI')
            $namespace.Logon('', '', $false, $true)  # Explicit logon
            Write-Host "Created new Outlook instance" -ForegroundColor Green
            $useOutlook = $true
        }
        catch {
            Write-Warning "Could not connect to Outlook: $($_.Exception.Message)"
            Write-Host "Falling back to .msg file export..." -ForegroundColor Yellow
        }
    }
}

if (-not $useOutlook) {
    # Fallback: Export as .msg files
    $outputDir = Join-Path $PSScriptRoot "draft-emails"
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }
    Write-Host "Will export to .msg files in: $outputDir" -ForegroundColor Cyan
}

$createdCount = 0
$errorCount = 0

foreach ($project in $projects) {
    $projectName = $project.name
    $emails = $project.emails


    if ([string]::IsNullOrWhiteSpace($projectName)) {
        Write-Warning "Skipping row with empty project name"
        continue
    }

    $toField = if ($emails.Count -eq 0) { 'ADMIN GONE' } else { $emails -join '; ' }
    if ($emails.Count -eq 0) {
        Write-Warning "  No admin recipients found for $projectName - using 'ADMIN GONE' as To field"
    }

    Write-Host "Processing: $projectName" -ForegroundColor Yellow
    Write-Host "  Recipients: $toField" -ForegroundColor Gray

    # Replace {ProjectName} placeholder in template
    $subject = $template.subject -replace '\{ProjectName\}', $projectName
    
    # Replace placeholders in body
    $body = $template.body -replace '\{ProjectName\}', $projectName

    if ($useOutlook -and $outlook) {
        try {
            # Create new mail item
            $mailItem = $outlook.CreateItem(0) # olMailItem = 0
            
            # Set recipients (join with semicolons for multiple)
            $mailItem.To = $toField
            
            # Set subject
            $mailItem.Subject = $subject
            
            # Set body (plain text)
            $mailItem.Body = $body
            
            # Save to drafts folder
            $mailItem.Save()
            
            Write-Host "  Created draft for: $toField" -ForegroundColor Green
            $createdCount++
        }
        catch {
            Write-Warning "  Error creating draft for $projectName`: $($_.Exception.Message)"
            $errorCount++
        }
    }
    else {
        # Export as .msg file
        try {
            # Create Outlook instance temporarily for .msg export
            $tempOutlook = New-Object -ComObject Outlook.Application
            
            # Add a small delay to let Outlook initialize
            Start-Sleep -Milliseconds 500
            
            $mailItem = $tempOutlook.CreateItem(0)
            $mailItem.To = $toField
            $mailItem.Subject = $subject
            $mailItem.Body = $body
            
            # Save as .msg file using absolute path
            $safeFileName = $projectName -replace '[\\/:*?"<>|]', '_'
            $msgPath = Join-Path $outputDir "$safeFileName.msg"
            
            $mailItem.SaveAs($msgPath)
            
            Write-Host "  Exported .msg for: $toField" -ForegroundColor Green
            $createdCount++
            
            # Cleanup temp Outlook
            [System.Runtime.Interopservices.Marshal]::ReleaseComObject($mailItem) | Out-Null
            [System.Runtime.Interopservices.Marshal]::ReleaseComObject($tempOutlook) | Out-Null
        }
        catch {
            Write-Warning "  Error exporting .msg for $projectName`: $($_.Exception.Message)"
            $errorCount++
        }
    }
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Summary:" -ForegroundColor Cyan
if ($useOutlook) {
    Write-Host "  Draft emails created in Outlook: $createdCount" -ForegroundColor $(if ($createdCount -gt 0) { 'Green' } else { 'Yellow' })
}
else {
    Write-Host "  .msg files exported: $createdCount" -ForegroundColor $(if ($createdCount -gt 0) { 'Green' } else { 'Yellow' })
}
Write-Host "  Errors: $errorCount" -ForegroundColor $(if ($errorCount -gt 0) { 'Red' } else { 'Green' })
Write-Host "========================================" -ForegroundColor Cyan

if ($createdCount -gt 0) {
    if ($useOutlook) {
        Write-Host "`nDraft emails have been saved to your Outlook Drafts folder." -ForegroundColor Cyan
        Write-Host "Please review and send them manually." -ForegroundColor Cyan
    }
    else {
        Write-Host "`n.msg files have been saved to: $outputDir" -ForegroundColor Cyan
        Write-Host "You can drag these files into Outlook to create drafts." -ForegroundColor Cyan
    }
}

# Clean up COM object
if ($outlook) {
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($outlook) | Out-Null
}
